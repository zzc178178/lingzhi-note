function ld(e,t){for(var n=0;n<t.length;n++){const r=t[n];if(typeof r!="string"&&!Array.isArray(r)){for(const l in r)if(l!=="default"&&!(l in e)){const o=Object.getOwnPropertyDescriptor(r,l);o&&Object.defineProperty(e,l,o.get?o:{enumerable:!0,get:()=>r[l]})}}}return Object.freeze(Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}))}(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const l of document.querySelectorAll('link[rel="modulepreload"]'))r(l);new MutationObserver(l=>{for(const o of l)if(o.type==="childList")for(const i of o.addedNodes)i.tagName==="LINK"&&i.rel==="modulepreload"&&r(i)}).observe(document,{childList:!0,subtree:!0});function n(l){const o={};return l.integrity&&(o.integrity=l.integrity),l.referrerPolicy&&(o.referrerPolicy=l.referrerPolicy),l.crossOrigin==="use-credentials"?o.credentials="include":l.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function r(l){if(l.ep)return;l.ep=!0;const o=n(l);fetch(l.href,o)}})();function od(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var Es={exports:{}},dl={},Cs={exports:{}},R={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var rr=Symbol.for("react.element"),id=Symbol.for("react.portal"),ad=Symbol.for("react.fragment"),sd=Symbol.for("react.strict_mode"),ud=Symbol.for("react.profiler"),cd=Symbol.for("react.provider"),dd=Symbol.for("react.context"),fd=Symbol.for("react.forward_ref"),pd=Symbol.for("react.suspense"),md=Symbol.for("react.memo"),hd=Symbol.for("react.lazy"),la=Symbol.iterator;function gd(e){return e===null||typeof e!="object"?null:(e=la&&e[la]||e["@@iterator"],typeof e=="function"?e:null)}var Ns={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},_s=Object.assign,Ts={};function dn(e,t,n){this.props=e,this.context=t,this.refs=Ts,this.updater=n||Ns}dn.prototype.isReactComponent={};dn.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};dn.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function zs(){}zs.prototype=dn.prototype;function li(e,t,n){this.props=e,this.context=t,this.refs=Ts,this.updater=n||Ns}var oi=li.prototype=new zs;oi.constructor=li;_s(oi,dn.prototype);oi.isPureReactComponent=!0;var oa=Array.isArray,Ps=Object.prototype.hasOwnProperty,ii={current:null},Ls={key:!0,ref:!0,__self:!0,__source:!0};function js(e,t,n){var r,l={},o=null,i=null;if(t!=null)for(r in t.ref!==void 0&&(i=t.ref),t.key!==void 0&&(o=""+t.key),t)Ps.call(t,r)&&!Ls.hasOwnProperty(r)&&(l[r]=t[r]);var a=arguments.length-2;if(a===1)l.children=n;else if(1<a){for(var s=Array(a),u=0;u<a;u++)s[u]=arguments[u+2];l.children=s}if(e&&e.defaultProps)for(r in a=e.defaultProps,a)l[r]===void 0&&(l[r]=a[r]);return{$$typeof:rr,type:e,key:o,ref:i,props:l,_owner:ii.current}}function vd(e,t){return{$$typeof:rr,type:e.type,key:t,ref:e.ref,props:e.props,_owner:e._owner}}function ai(e){return typeof e=="object"&&e!==null&&e.$$typeof===rr}function yd(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var ia=/\/+/g;function Ml(e,t){return typeof e=="object"&&e!==null&&e.key!=null?yd(""+e.key):t.toString(36)}function zr(e,t,n,r,l){var o=typeof e;(o==="undefined"||o==="boolean")&&(e=null);var i=!1;if(e===null)i=!0;else switch(o){case"string":case"number":i=!0;break;case"object":switch(e.$$typeof){case rr:case id:i=!0}}if(i)return i=e,l=l(i),e=r===""?"."+Ml(i,0):r,oa(l)?(n="",e!=null&&(n=e.replace(ia,"$&/")+"/"),zr(l,t,n,"",function(u){return u})):l!=null&&(ai(l)&&(l=vd(l,n+(!l.key||i&&i.key===l.key?"":(""+l.key).replace(ia,"$&/")+"/")+e)),t.push(l)),1;if(i=0,r=r===""?".":r+":",oa(e))for(var a=0;a<e.length;a++){o=e[a];var s=r+Ml(o,a);i+=zr(o,t,n,s,l)}else if(s=gd(e),typeof s=="function")for(e=s.call(e),a=0;!(o=e.next()).done;)o=o.value,s=r+Ml(o,a++),i+=zr(o,t,n,s,l);else if(o==="object")throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.");return i}function dr(e,t,n){if(e==null)return e;var r=[],l=0;return zr(e,r,"","",function(o){return t.call(n,o,l++)}),r}function xd(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(n){(e._status===0||e._status===-1)&&(e._status=1,e._result=n)},function(n){(e._status===0||e._status===-1)&&(e._status=2,e._result=n)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var ue={current:null},Pr={transition:null},wd={ReactCurrentDispatcher:ue,ReactCurrentBatchConfig:Pr,ReactCurrentOwner:ii};function Rs(){throw Error("act(...) is not supported in production builds of React.")}R.Children={map:dr,forEach:function(e,t,n){dr(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return dr(e,function(){t++}),t},toArray:function(e){return dr(e,function(t){return t})||[]},only:function(e){if(!ai(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};R.Component=dn;R.Fragment=ad;R.Profiler=ud;R.PureComponent=li;R.StrictMode=sd;R.Suspense=pd;R.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=wd;R.act=Rs;R.cloneElement=function(e,t,n){if(e==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+e+".");var r=_s({},e.props),l=e.key,o=e.ref,i=e._owner;if(t!=null){if(t.ref!==void 0&&(o=t.ref,i=ii.current),t.key!==void 0&&(l=""+t.key),e.type&&e.type.defaultProps)var a=e.type.defaultProps;for(s in t)Ps.call(t,s)&&!Ls.hasOwnProperty(s)&&(r[s]=t[s]===void 0&&a!==void 0?a[s]:t[s])}var s=arguments.length-2;if(s===1)r.children=n;else if(1<s){a=Array(s);for(var u=0;u<s;u++)a[u]=arguments[u+2];r.children=a}return{$$typeof:rr,type:e.type,key:l,ref:o,props:r,_owner:i}};R.createContext=function(e){return e={$$typeof:dd,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},e.Provider={$$typeof:cd,_context:e},e.Consumer=e};R.createElement=js;R.createFactory=function(e){var t=js.bind(null,e);return t.type=e,t};R.createRef=function(){return{current:null}};R.forwardRef=function(e){return{$$typeof:fd,render:e}};R.isValidElement=ai;R.lazy=function(e){return{$$typeof:hd,_payload:{_status:-1,_result:e},_init:xd}};R.memo=function(e,t){return{$$typeof:md,type:e,compare:t===void 0?null:t}};R.startTransition=function(e){var t=Pr.transition;Pr.transition={};try{e()}finally{Pr.transition=t}};R.unstable_act=Rs;R.useCallback=function(e,t){return ue.current.useCallback(e,t)};R.useContext=function(e){return ue.current.useContext(e)};R.useDebugValue=function(){};R.useDeferredValue=function(e){return ue.current.useDeferredValue(e)};R.useEffect=function(e,t){return ue.current.useEffect(e,t)};R.useId=function(){return ue.current.useId()};R.useImperativeHandle=function(e,t,n){return ue.current.useImperativeHandle(e,t,n)};R.useInsertionEffect=function(e,t){return ue.current.useInsertionEffect(e,t)};R.useLayoutEffect=function(e,t){return ue.current.useLayoutEffect(e,t)};R.useMemo=function(e,t){return ue.current.useMemo(e,t)};R.useReducer=function(e,t,n){return ue.current.useReducer(e,t,n)};R.useRef=function(e){return ue.current.useRef(e)};R.useState=function(e){return ue.current.useState(e)};R.useSyncExternalStore=function(e,t,n){return ue.current.useSyncExternalStore(e,t,n)};R.useTransition=function(){return ue.current.useTransition()};R.version="18.3.1";Cs.exports=R;var S=Cs.exports;const bs=od(S),kd=ld({__proto__:null,default:bs},[S]);/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Sd=S,Ed=Symbol.for("react.element"),Cd=Symbol.for("react.fragment"),Nd=Object.prototype.hasOwnProperty,_d=Sd.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,Td={key:!0,ref:!0,__self:!0,__source:!0};function Is(e,t,n){var r,l={},o=null,i=null;n!==void 0&&(o=""+n),t.key!==void 0&&(o=""+t.key),t.ref!==void 0&&(i=t.ref);for(r in t)Nd.call(t,r)&&!Td.hasOwnProperty(r)&&(l[r]=t[r]);if(e&&e.defaultProps)for(r in t=e.defaultProps,t)l[r]===void 0&&(l[r]=t[r]);return{$$typeof:Ed,type:e,key:o,ref:i,props:l,_owner:_d.current}}dl.Fragment=Cd;dl.jsx=Is;dl.jsxs=Is;Es.exports=dl;var y=Es.exports,so={},Ms={exports:{}},we={},Os={exports:{}},As={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */(function(e){function t(_,L){var j=_.length;_.push(L);e:for(;0<j;){var W=j-1>>>1,J=_[W];if(0<l(J,L))_[W]=L,_[j]=J,j=W;else break e}}function n(_){return _.length===0?null:_[0]}function r(_){if(_.length===0)return null;var L=_[0],j=_.pop();if(j!==L){_[0]=j;e:for(var W=0,J=_.length,ur=J>>>1;W<ur;){var yt=2*(W+1)-1,Il=_[yt],xt=yt+1,cr=_[xt];if(0>l(Il,j))xt<J&&0>l(cr,Il)?(_[W]=cr,_[xt]=j,W=xt):(_[W]=Il,_[yt]=j,W=yt);else if(xt<J&&0>l(cr,j))_[W]=cr,_[xt]=j,W=xt;else break e}}return L}function l(_,L){var j=_.sortIndex-L.sortIndex;return j!==0?j:_.id-L.id}if(typeof performance=="object"&&typeof performance.now=="function"){var o=performance;e.unstable_now=function(){return o.now()}}else{var i=Date,a=i.now();e.unstable_now=function(){return i.now()-a}}var s=[],u=[],m=1,f=null,h=3,g=!1,w=!1,v=!1,E=typeof setTimeout=="function"?setTimeout:null,d=typeof clearTimeout=="function"?clearTimeout:null,c=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function p(_){for(var L=n(u);L!==null;){if(L.callback===null)r(u);else if(L.startTime<=_)r(u),L.sortIndex=L.expirationTime,t(s,L);else break;L=n(u)}}function x(_){if(v=!1,p(_),!w)if(n(s)!==null)w=!0,Rl(C);else{var L=n(u);L!==null&&bl(x,L.startTime-_)}}function C(_,L){w=!1,v&&(v=!1,d(P),P=-1),g=!0;var j=h;try{for(p(L),f=n(s);f!==null&&(!(f.expirationTime>L)||_&&!ze());){var W=f.callback;if(typeof W=="function"){f.callback=null,h=f.priorityLevel;var J=W(f.expirationTime<=L);L=e.unstable_now(),typeof J=="function"?f.callback=J:f===n(s)&&r(s),p(L)}else r(s);f=n(s)}if(f!==null)var ur=!0;else{var yt=n(u);yt!==null&&bl(x,yt.startTime-L),ur=!1}return ur}finally{f=null,h=j,g=!1}}var T=!1,z=null,P=-1,V=5,b=-1;function ze(){return!(e.unstable_now()-b<V)}function mn(){if(z!==null){var _=e.unstable_now();b=_;var L=!0;try{L=z(!0,_)}finally{L?hn():(T=!1,z=null)}}else T=!1}var hn;if(typeof c=="function")hn=function(){c(mn)};else if(typeof MessageChannel<"u"){var ra=new MessageChannel,rd=ra.port2;ra.port1.onmessage=mn,hn=function(){rd.postMessage(null)}}else hn=function(){E(mn,0)};function Rl(_){z=_,T||(T=!0,hn())}function bl(_,L){P=E(function(){_(e.unstable_now())},L)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(_){_.callback=null},e.unstable_continueExecution=function(){w||g||(w=!0,Rl(C))},e.unstable_forceFrameRate=function(_){0>_||125<_?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):V=0<_?Math.floor(1e3/_):5},e.unstable_getCurrentPriorityLevel=function(){return h},e.unstable_getFirstCallbackNode=function(){return n(s)},e.unstable_next=function(_){switch(h){case 1:case 2:case 3:var L=3;break;default:L=h}var j=h;h=L;try{return _()}finally{h=j}},e.unstable_pauseExecution=function(){},e.unstable_requestPaint=function(){},e.unstable_runWithPriority=function(_,L){switch(_){case 1:case 2:case 3:case 4:case 5:break;default:_=3}var j=h;h=_;try{return L()}finally{h=j}},e.unstable_scheduleCallback=function(_,L,j){var W=e.unstable_now();switch(typeof j=="object"&&j!==null?(j=j.delay,j=typeof j=="number"&&0<j?W+j:W):j=W,_){case 1:var J=-1;break;case 2:J=250;break;case 5:J=1073741823;break;case 4:J=1e4;break;default:J=5e3}return J=j+J,_={id:m++,callback:L,priorityLevel:_,startTime:j,expirationTime:J,sortIndex:-1},j>W?(_.sortIndex=j,t(u,_),n(s)===null&&_===n(u)&&(v?(d(P),P=-1):v=!0,bl(x,j-W))):(_.sortIndex=J,t(s,_),w||g||(w=!0,Rl(C))),_},e.unstable_shouldYield=ze,e.unstable_wrapCallback=function(_){var L=h;return function(){var j=h;h=L;try{return _.apply(this,arguments)}finally{h=j}}}})(As);Os.exports=As;var zd=Os.exports;/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Pd=S,xe=zd;function k(e){for(var t="https://reactjs.org/docs/error-decoder.html?invariant="+e,n=1;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n]);return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var Ds=new Set,Dn={};function bt(e,t){rn(e,t),rn(e+"Capture",t)}function rn(e,t){for(Dn[e]=t,e=0;e<t.length;e++)Ds.add(t[e])}var Qe=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),uo=Object.prototype.hasOwnProperty,Ld=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,aa={},sa={};function jd(e){return uo.call(sa,e)?!0:uo.call(aa,e)?!1:Ld.test(e)?sa[e]=!0:(aa[e]=!0,!1)}function Rd(e,t,n,r){if(n!==null&&n.type===0)return!1;switch(typeof t){case"function":case"symbol":return!0;case"boolean":return r?!1:n!==null?!n.acceptsBooleans:(e=e.toLowerCase().slice(0,5),e!=="data-"&&e!=="aria-");default:return!1}}function bd(e,t,n,r){if(t===null||typeof t>"u"||Rd(e,t,n,r))return!0;if(r)return!1;if(n!==null)switch(n.type){case 3:return!t;case 4:return t===!1;case 5:return isNaN(t);case 6:return isNaN(t)||1>t}return!1}function ce(e,t,n,r,l,o,i){this.acceptsBooleans=t===2||t===3||t===4,this.attributeName=r,this.attributeNamespace=l,this.mustUseProperty=n,this.propertyName=e,this.type=t,this.sanitizeURL=o,this.removeEmptyString=i}var ne={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e){ne[e]=new ce(e,0,!1,e,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(e){var t=e[0];ne[t]=new ce(t,1,!1,e[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(e){ne[e]=new ce(e,2,!1,e.toLowerCase(),null,!1,!1)});["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(e){ne[e]=new ce(e,2,!1,e,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e){ne[e]=new ce(e,3,!1,e.toLowerCase(),null,!1,!1)});["checked","multiple","muted","selected"].forEach(function(e){ne[e]=new ce(e,3,!0,e,null,!1,!1)});["capture","download"].forEach(function(e){ne[e]=new ce(e,4,!1,e,null,!1,!1)});["cols","rows","size","span"].forEach(function(e){ne[e]=new ce(e,6,!1,e,null,!1,!1)});["rowSpan","start"].forEach(function(e){ne[e]=new ce(e,5,!1,e.toLowerCase(),null,!1,!1)});var si=/[\-:]([a-z])/g;function ui(e){return e[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e){var t=e.replace(si,ui);ne[t]=new ce(t,1,!1,e,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e){var t=e.replace(si,ui);ne[t]=new ce(t,1,!1,e,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(e){var t=e.replace(si,ui);ne[t]=new ce(t,1,!1,e,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(e){ne[e]=new ce(e,1,!1,e.toLowerCase(),null,!1,!1)});ne.xlinkHref=new ce("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(e){ne[e]=new ce(e,1,!1,e.toLowerCase(),null,!0,!0)});function ci(e,t,n,r){var l=ne.hasOwnProperty(t)?ne[t]:null;(l!==null?l.type!==0:r||!(2<t.length)||t[0]!=="o"&&t[0]!=="O"||t[1]!=="n"&&t[1]!=="N")&&(bd(t,n,l,r)&&(n=null),r||l===null?jd(t)&&(n===null?e.removeAttribute(t):e.setAttribute(t,""+n)):l.mustUseProperty?e[l.propertyName]=n===null?l.type===3?!1:"":n:(t=l.attributeName,r=l.attributeNamespace,n===null?e.removeAttribute(t):(l=l.type,n=l===3||l===4&&n===!0?"":""+n,r?e.setAttributeNS(r,t,n):e.setAttribute(t,n))))}var Ge=Pd.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,fr=Symbol.for("react.element"),Ft=Symbol.for("react.portal"),Ut=Symbol.for("react.fragment"),di=Symbol.for("react.strict_mode"),co=Symbol.for("react.profiler"),Fs=Symbol.for("react.provider"),Us=Symbol.for("react.context"),fi=Symbol.for("react.forward_ref"),fo=Symbol.for("react.suspense"),po=Symbol.for("react.suspense_list"),pi=Symbol.for("react.memo"),qe=Symbol.for("react.lazy"),$s=Symbol.for("react.offscreen"),ua=Symbol.iterator;function gn(e){return e===null||typeof e!="object"?null:(e=ua&&e[ua]||e["@@iterator"],typeof e=="function"?e:null)}var B=Object.assign,Ol;function Cn(e){if(Ol===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);Ol=t&&t[1]||""}return`
`+Ol+e}var Al=!1;function Dl(e,t){if(!e||Al)return"";Al=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(t)if(t=function(){throw Error()},Object.defineProperty(t.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(t,[])}catch(u){var r=u}Reflect.construct(e,[],t)}else{try{t.call()}catch(u){r=u}e.call(t.prototype)}else{try{throw Error()}catch(u){r=u}e()}}catch(u){if(u&&r&&typeof u.stack=="string"){for(var l=u.stack.split(`
`),o=r.stack.split(`
`),i=l.length-1,a=o.length-1;1<=i&&0<=a&&l[i]!==o[a];)a--;for(;1<=i&&0<=a;i--,a--)if(l[i]!==o[a]){if(i!==1||a!==1)do if(i--,a--,0>a||l[i]!==o[a]){var s=`
`+l[i].replace(" at new "," at ");return e.displayName&&s.includes("<anonymous>")&&(s=s.replace("<anonymous>",e.displayName)),s}while(1<=i&&0<=a);break}}}finally{Al=!1,Error.prepareStackTrace=n}return(e=e?e.displayName||e.name:"")?Cn(e):""}function Id(e){switch(e.tag){case 5:return Cn(e.type);case 16:return Cn("Lazy");case 13:return Cn("Suspense");case 19:return Cn("SuspenseList");case 0:case 2:case 15:return e=Dl(e.type,!1),e;case 11:return e=Dl(e.type.render,!1),e;case 1:return e=Dl(e.type,!0),e;default:return""}}function mo(e){if(e==null)return null;if(typeof e=="function")return e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case Ut:return"Fragment";case Ft:return"Portal";case co:return"Profiler";case di:return"StrictMode";case fo:return"Suspense";case po:return"SuspenseList"}if(typeof e=="object")switch(e.$$typeof){case Us:return(e.displayName||"Context")+".Consumer";case Fs:return(e._context.displayName||"Context")+".Provider";case fi:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case pi:return t=e.displayName||null,t!==null?t:mo(e.type)||"Memo";case qe:t=e._payload,e=e._init;try{return mo(e(t))}catch{}}return null}function Md(e){var t=e.type;switch(e.tag){case 24:return"Cache";case 9:return(t.displayName||"Context")+".Consumer";case 10:return(t._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return e=t.render,e=e.displayName||e.name||"",t.displayName||(e!==""?"ForwardRef("+e+")":"ForwardRef");case 7:return"Fragment";case 5:return t;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return mo(t);case 8:return t===di?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof t=="function")return t.displayName||t.name||null;if(typeof t=="string")return t}return null}function pt(e){switch(typeof e){case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Bs(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function Od(e){var t=Bs(e)?"checked":"value",n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t),r=""+e[t];if(!e.hasOwnProperty(t)&&typeof n<"u"&&typeof n.get=="function"&&typeof n.set=="function"){var l=n.get,o=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return l.call(this)},set:function(i){r=""+i,o.call(this,i)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(i){r=""+i},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function pr(e){e._valueTracker||(e._valueTracker=Od(e))}function Hs(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r="";return e&&(r=Bs(e)?e.checked?"true":"false":e.value),e=r,e!==n?(t.setValue(e),!0):!1}function Ur(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function ho(e,t){var n=t.checked;return B({},t,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:n??e._wrapperState.initialChecked})}function ca(e,t){var n=t.defaultValue==null?"":t.defaultValue,r=t.checked!=null?t.checked:t.defaultChecked;n=pt(t.value!=null?t.value:n),e._wrapperState={initialChecked:r,initialValue:n,controlled:t.type==="checkbox"||t.type==="radio"?t.checked!=null:t.value!=null}}function Vs(e,t){t=t.checked,t!=null&&ci(e,"checked",t,!1)}function go(e,t){Vs(e,t);var n=pt(t.value),r=t.type;if(n!=null)r==="number"?(n===0&&e.value===""||e.value!=n)&&(e.value=""+n):e.value!==""+n&&(e.value=""+n);else if(r==="submit"||r==="reset"){e.removeAttribute("value");return}t.hasOwnProperty("value")?vo(e,t.type,n):t.hasOwnProperty("defaultValue")&&vo(e,t.type,pt(t.defaultValue)),t.checked==null&&t.defaultChecked!=null&&(e.defaultChecked=!!t.defaultChecked)}function da(e,t,n){if(t.hasOwnProperty("value")||t.hasOwnProperty("defaultValue")){var r=t.type;if(!(r!=="submit"&&r!=="reset"||t.value!==void 0&&t.value!==null))return;t=""+e._wrapperState.initialValue,n||t===e.value||(e.value=t),e.defaultValue=t}n=e.name,n!==""&&(e.name=""),e.defaultChecked=!!e._wrapperState.initialChecked,n!==""&&(e.name=n)}function vo(e,t,n){(t!=="number"||Ur(e.ownerDocument)!==e)&&(n==null?e.defaultValue=""+e._wrapperState.initialValue:e.defaultValue!==""+n&&(e.defaultValue=""+n))}var Nn=Array.isArray;function Jt(e,t,n,r){if(e=e.options,t){t={};for(var l=0;l<n.length;l++)t["$"+n[l]]=!0;for(n=0;n<e.length;n++)l=t.hasOwnProperty("$"+e[n].value),e[n].selected!==l&&(e[n].selected=l),l&&r&&(e[n].defaultSelected=!0)}else{for(n=""+pt(n),t=null,l=0;l<e.length;l++){if(e[l].value===n){e[l].selected=!0,r&&(e[l].defaultSelected=!0);return}t!==null||e[l].disabled||(t=e[l])}t!==null&&(t.selected=!0)}}function yo(e,t){if(t.dangerouslySetInnerHTML!=null)throw Error(k(91));return B({},t,{value:void 0,defaultValue:void 0,children:""+e._wrapperState.initialValue})}function fa(e,t){var n=t.value;if(n==null){if(n=t.children,t=t.defaultValue,n!=null){if(t!=null)throw Error(k(92));if(Nn(n)){if(1<n.length)throw Error(k(93));n=n[0]}t=n}t==null&&(t=""),n=t}e._wrapperState={initialValue:pt(n)}}function Ws(e,t){var n=pt(t.value),r=pt(t.defaultValue);n!=null&&(n=""+n,n!==e.value&&(e.value=n),t.defaultValue==null&&e.defaultValue!==n&&(e.defaultValue=n)),r!=null&&(e.defaultValue=""+r)}function pa(e){var t=e.textContent;t===e._wrapperState.initialValue&&t!==""&&t!==null&&(e.value=t)}function Qs(e){switch(e){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function xo(e,t){return e==null||e==="http://www.w3.org/1999/xhtml"?Qs(t):e==="http://www.w3.org/2000/svg"&&t==="foreignObject"?"http://www.w3.org/1999/xhtml":e}var mr,Ks=function(e){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(t,n,r,l){MSApp.execUnsafeLocalFunction(function(){return e(t,n,r,l)})}:e}(function(e,t){if(e.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in e)e.innerHTML=t;else{for(mr=mr||document.createElement("div"),mr.innerHTML="<svg>"+t.valueOf().toString()+"</svg>",t=mr.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;t.firstChild;)e.appendChild(t.firstChild)}});function Fn(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var Pn={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},Ad=["Webkit","ms","Moz","O"];Object.keys(Pn).forEach(function(e){Ad.forEach(function(t){t=t+e.charAt(0).toUpperCase()+e.substring(1),Pn[t]=Pn[e]})});function Ys(e,t,n){return t==null||typeof t=="boolean"||t===""?"":n||typeof t!="number"||t===0||Pn.hasOwnProperty(e)&&Pn[e]?(""+t).trim():t+"px"}function Xs(e,t){e=e.style;for(var n in t)if(t.hasOwnProperty(n)){var r=n.indexOf("--")===0,l=Ys(n,t[n],r);n==="float"&&(n="cssFloat"),r?e.setProperty(n,l):e[n]=l}}var Dd=B({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function wo(e,t){if(t){if(Dd[e]&&(t.children!=null||t.dangerouslySetInnerHTML!=null))throw Error(k(137,e));if(t.dangerouslySetInnerHTML!=null){if(t.children!=null)throw Error(k(60));if(typeof t.dangerouslySetInnerHTML!="object"||!("__html"in t.dangerouslySetInnerHTML))throw Error(k(61))}if(t.style!=null&&typeof t.style!="object")throw Error(k(62))}}function ko(e,t){if(e.indexOf("-")===-1)return typeof t.is=="string";switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var So=null;function mi(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Eo=null,qt=null,Zt=null;function ma(e){if(e=ir(e)){if(typeof Eo!="function")throw Error(k(280));var t=e.stateNode;t&&(t=gl(t),Eo(e.stateNode,e.type,t))}}function Gs(e){qt?Zt?Zt.push(e):Zt=[e]:qt=e}function Js(){if(qt){var e=qt,t=Zt;if(Zt=qt=null,ma(e),t)for(e=0;e<t.length;e++)ma(t[e])}}function qs(e,t){return e(t)}function Zs(){}var Fl=!1;function eu(e,t,n){if(Fl)return e(t,n);Fl=!0;try{return qs(e,t,n)}finally{Fl=!1,(qt!==null||Zt!==null)&&(Zs(),Js())}}function Un(e,t){var n=e.stateNode;if(n===null)return null;var r=gl(n);if(r===null)return null;n=r[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(r=!r.disabled)||(e=e.type,r=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!r;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(k(231,t,typeof n));return n}var Co=!1;if(Qe)try{var vn={};Object.defineProperty(vn,"passive",{get:function(){Co=!0}}),window.addEventListener("test",vn,vn),window.removeEventListener("test",vn,vn)}catch{Co=!1}function Fd(e,t,n,r,l,o,i,a,s){var u=Array.prototype.slice.call(arguments,3);try{t.apply(n,u)}catch(m){this.onError(m)}}var Ln=!1,$r=null,Br=!1,No=null,Ud={onError:function(e){Ln=!0,$r=e}};function $d(e,t,n,r,l,o,i,a,s){Ln=!1,$r=null,Fd.apply(Ud,arguments)}function Bd(e,t,n,r,l,o,i,a,s){if($d.apply(this,arguments),Ln){if(Ln){var u=$r;Ln=!1,$r=null}else throw Error(k(198));Br||(Br=!0,No=u)}}function It(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function tu(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function ha(e){if(It(e)!==e)throw Error(k(188))}function Hd(e){var t=e.alternate;if(!t){if(t=It(e),t===null)throw Error(k(188));return t!==e?null:e}for(var n=e,r=t;;){var l=n.return;if(l===null)break;var o=l.alternate;if(o===null){if(r=l.return,r!==null){n=r;continue}break}if(l.child===o.child){for(o=l.child;o;){if(o===n)return ha(l),e;if(o===r)return ha(l),t;o=o.sibling}throw Error(k(188))}if(n.return!==r.return)n=l,r=o;else{for(var i=!1,a=l.child;a;){if(a===n){i=!0,n=l,r=o;break}if(a===r){i=!0,r=l,n=o;break}a=a.sibling}if(!i){for(a=o.child;a;){if(a===n){i=!0,n=o,r=l;break}if(a===r){i=!0,r=o,n=l;break}a=a.sibling}if(!i)throw Error(k(189))}}if(n.alternate!==r)throw Error(k(190))}if(n.tag!==3)throw Error(k(188));return n.stateNode.current===n?e:t}function nu(e){return e=Hd(e),e!==null?ru(e):null}function ru(e){if(e.tag===5||e.tag===6)return e;for(e=e.child;e!==null;){var t=ru(e);if(t!==null)return t;e=e.sibling}return null}var lu=xe.unstable_scheduleCallback,ga=xe.unstable_cancelCallback,Vd=xe.unstable_shouldYield,Wd=xe.unstable_requestPaint,Q=xe.unstable_now,Qd=xe.unstable_getCurrentPriorityLevel,hi=xe.unstable_ImmediatePriority,ou=xe.unstable_UserBlockingPriority,Hr=xe.unstable_NormalPriority,Kd=xe.unstable_LowPriority,iu=xe.unstable_IdlePriority,fl=null,Fe=null;function Yd(e){if(Fe&&typeof Fe.onCommitFiberRoot=="function")try{Fe.onCommitFiberRoot(fl,e,void 0,(e.current.flags&128)===128)}catch{}}var be=Math.clz32?Math.clz32:Jd,Xd=Math.log,Gd=Math.LN2;function Jd(e){return e>>>=0,e===0?32:31-(Xd(e)/Gd|0)|0}var hr=64,gr=4194304;function _n(e){switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return e&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return e}}function Vr(e,t){var n=e.pendingLanes;if(n===0)return 0;var r=0,l=e.suspendedLanes,o=e.pingedLanes,i=n&268435455;if(i!==0){var a=i&~l;a!==0?r=_n(a):(o&=i,o!==0&&(r=_n(o)))}else i=n&~l,i!==0?r=_n(i):o!==0&&(r=_n(o));if(r===0)return 0;if(t!==0&&t!==r&&!(t&l)&&(l=r&-r,o=t&-t,l>=o||l===16&&(o&4194240)!==0))return t;if(r&4&&(r|=n&16),t=e.entangledLanes,t!==0)for(e=e.entanglements,t&=r;0<t;)n=31-be(t),l=1<<n,r|=e[n],t&=~l;return r}function qd(e,t){switch(e){case 1:case 2:case 4:return t+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Zd(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,l=e.expirationTimes,o=e.pendingLanes;0<o;){var i=31-be(o),a=1<<i,s=l[i];s===-1?(!(a&n)||a&r)&&(l[i]=qd(a,t)):s<=t&&(e.expiredLanes|=a),o&=~a}}function _o(e){return e=e.pendingLanes&-1073741825,e!==0?e:e&1073741824?1073741824:0}function au(){var e=hr;return hr<<=1,!(hr&4194240)&&(hr=64),e}function Ul(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function lr(e,t,n){e.pendingLanes|=t,t!==536870912&&(e.suspendedLanes=0,e.pingedLanes=0),e=e.eventTimes,t=31-be(t),e[t]=n}function ef(e,t){var n=e.pendingLanes&~t;e.pendingLanes=t,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=t,e.mutableReadLanes&=t,e.entangledLanes&=t,t=e.entanglements;var r=e.eventTimes;for(e=e.expirationTimes;0<n;){var l=31-be(n),o=1<<l;t[l]=0,r[l]=-1,e[l]=-1,n&=~o}}function gi(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-be(n),l=1<<r;l&t|e[r]&t&&(e[r]|=t),n&=~l}}var M=0;function su(e){return e&=-e,1<e?4<e?e&268435455?16:536870912:4:1}var uu,vi,cu,du,fu,To=!1,vr=[],ot=null,it=null,at=null,$n=new Map,Bn=new Map,et=[],tf="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function va(e,t){switch(e){case"focusin":case"focusout":ot=null;break;case"dragenter":case"dragleave":it=null;break;case"mouseover":case"mouseout":at=null;break;case"pointerover":case"pointerout":$n.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":Bn.delete(t.pointerId)}}function yn(e,t,n,r,l,o){return e===null||e.nativeEvent!==o?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:o,targetContainers:[l]},t!==null&&(t=ir(t),t!==null&&vi(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,l!==null&&t.indexOf(l)===-1&&t.push(l),e)}function nf(e,t,n,r,l){switch(t){case"focusin":return ot=yn(ot,e,t,n,r,l),!0;case"dragenter":return it=yn(it,e,t,n,r,l),!0;case"mouseover":return at=yn(at,e,t,n,r,l),!0;case"pointerover":var o=l.pointerId;return $n.set(o,yn($n.get(o)||null,e,t,n,r,l)),!0;case"gotpointercapture":return o=l.pointerId,Bn.set(o,yn(Bn.get(o)||null,e,t,n,r,l)),!0}return!1}function pu(e){var t=St(e.target);if(t!==null){var n=It(t);if(n!==null){if(t=n.tag,t===13){if(t=tu(n),t!==null){e.blockedOn=t,fu(e.priority,function(){cu(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Lr(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=zo(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n);So=r,n.target.dispatchEvent(r),So=null}else return t=ir(n),t!==null&&vi(t),e.blockedOn=n,!1;t.shift()}return!0}function ya(e,t,n){Lr(e)&&n.delete(t)}function rf(){To=!1,ot!==null&&Lr(ot)&&(ot=null),it!==null&&Lr(it)&&(it=null),at!==null&&Lr(at)&&(at=null),$n.forEach(ya),Bn.forEach(ya)}function xn(e,t){e.blockedOn===t&&(e.blockedOn=null,To||(To=!0,xe.unstable_scheduleCallback(xe.unstable_NormalPriority,rf)))}function Hn(e){function t(l){return xn(l,e)}if(0<vr.length){xn(vr[0],e);for(var n=1;n<vr.length;n++){var r=vr[n];r.blockedOn===e&&(r.blockedOn=null)}}for(ot!==null&&xn(ot,e),it!==null&&xn(it,e),at!==null&&xn(at,e),$n.forEach(t),Bn.forEach(t),n=0;n<et.length;n++)r=et[n],r.blockedOn===e&&(r.blockedOn=null);for(;0<et.length&&(n=et[0],n.blockedOn===null);)pu(n),n.blockedOn===null&&et.shift()}var en=Ge.ReactCurrentBatchConfig,Wr=!0;function lf(e,t,n,r){var l=M,o=en.transition;en.transition=null;try{M=1,yi(e,t,n,r)}finally{M=l,en.transition=o}}function of(e,t,n,r){var l=M,o=en.transition;en.transition=null;try{M=4,yi(e,t,n,r)}finally{M=l,en.transition=o}}function yi(e,t,n,r){if(Wr){var l=zo(e,t,n,r);if(l===null)Gl(e,t,r,Qr,n),va(e,r);else if(nf(l,e,t,n,r))r.stopPropagation();else if(va(e,r),t&4&&-1<tf.indexOf(e)){for(;l!==null;){var o=ir(l);if(o!==null&&uu(o),o=zo(e,t,n,r),o===null&&Gl(e,t,r,Qr,n),o===l)break;l=o}l!==null&&r.stopPropagation()}else Gl(e,t,r,null,n)}}var Qr=null;function zo(e,t,n,r){if(Qr=null,e=mi(r),e=St(e),e!==null)if(t=It(e),t===null)e=null;else if(n=t.tag,n===13){if(e=tu(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null);return Qr=e,null}function mu(e){switch(e){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(Qd()){case hi:return 1;case ou:return 4;case Hr:case Kd:return 16;case iu:return 536870912;default:return 16}default:return 16}}var nt=null,xi=null,jr=null;function hu(){if(jr)return jr;var e,t=xi,n=t.length,r,l="value"in nt?nt.value:nt.textContent,o=l.length;for(e=0;e<n&&t[e]===l[e];e++);var i=n-e;for(r=1;r<=i&&t[n-r]===l[o-r];r++);return jr=l.slice(e,1<r?1-r:void 0)}function Rr(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function yr(){return!0}function xa(){return!1}function ke(e){function t(n,r,l,o,i){this._reactName=n,this._targetInst=l,this.type=r,this.nativeEvent=o,this.target=i,this.currentTarget=null;for(var a in e)e.hasOwnProperty(a)&&(n=e[a],this[a]=n?n(o):o[a]);return this.isDefaultPrevented=(o.defaultPrevented!=null?o.defaultPrevented:o.returnValue===!1)?yr:xa,this.isPropagationStopped=xa,this}return B(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=yr)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=yr)},persist:function(){},isPersistent:yr}),t}var fn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},wi=ke(fn),or=B({},fn,{view:0,detail:0}),af=ke(or),$l,Bl,wn,pl=B({},or,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:ki,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==wn&&(wn&&e.type==="mousemove"?($l=e.screenX-wn.screenX,Bl=e.screenY-wn.screenY):Bl=$l=0,wn=e),$l)},movementY:function(e){return"movementY"in e?e.movementY:Bl}}),wa=ke(pl),sf=B({},pl,{dataTransfer:0}),uf=ke(sf),cf=B({},or,{relatedTarget:0}),Hl=ke(cf),df=B({},fn,{animationName:0,elapsedTime:0,pseudoElement:0}),ff=ke(df),pf=B({},fn,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),mf=ke(pf),hf=B({},fn,{data:0}),ka=ke(hf),gf={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},vf={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},yf={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function xf(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=yf[e])?!!t[e]:!1}function ki(){return xf}var wf=B({},or,{key:function(e){if(e.key){var t=gf[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=Rr(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?vf[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:ki,charCode:function(e){return e.type==="keypress"?Rr(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?Rr(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),kf=ke(wf),Sf=B({},pl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Sa=ke(Sf),Ef=B({},or,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:ki}),Cf=ke(Ef),Nf=B({},fn,{propertyName:0,elapsedTime:0,pseudoElement:0}),_f=ke(Nf),Tf=B({},pl,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),zf=ke(Tf),Pf=[9,13,27,32],Si=Qe&&"CompositionEvent"in window,jn=null;Qe&&"documentMode"in document&&(jn=document.documentMode);var Lf=Qe&&"TextEvent"in window&&!jn,gu=Qe&&(!Si||jn&&8<jn&&11>=jn),Ea=" ",Ca=!1;function vu(e,t){switch(e){case"keyup":return Pf.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function yu(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var $t=!1;function jf(e,t){switch(e){case"compositionend":return yu(t);case"keypress":return t.which!==32?null:(Ca=!0,Ea);case"textInput":return e=t.data,e===Ea&&Ca?null:e;default:return null}}function Rf(e,t){if($t)return e==="compositionend"||!Si&&vu(e,t)?(e=hu(),jr=xi=nt=null,$t=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return gu&&t.locale!=="ko"?null:t.data;default:return null}}var bf={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Na(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!bf[e.type]:t==="textarea"}function xu(e,t,n,r){Gs(r),t=Kr(t,"onChange"),0<t.length&&(n=new wi("onChange","change",null,n,r),e.push({event:n,listeners:t}))}var Rn=null,Vn=null;function If(e){Lu(e,0)}function ml(e){var t=Vt(e);if(Hs(t))return e}function Mf(e,t){if(e==="change")return t}var wu=!1;if(Qe){var Vl;if(Qe){var Wl="oninput"in document;if(!Wl){var _a=document.createElement("div");_a.setAttribute("oninput","return;"),Wl=typeof _a.oninput=="function"}Vl=Wl}else Vl=!1;wu=Vl&&(!document.documentMode||9<document.documentMode)}function Ta(){Rn&&(Rn.detachEvent("onpropertychange",ku),Vn=Rn=null)}function ku(e){if(e.propertyName==="value"&&ml(Vn)){var t=[];xu(t,Vn,e,mi(e)),eu(If,t)}}function Of(e,t,n){e==="focusin"?(Ta(),Rn=t,Vn=n,Rn.attachEvent("onpropertychange",ku)):e==="focusout"&&Ta()}function Af(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return ml(Vn)}function Df(e,t){if(e==="click")return ml(t)}function Ff(e,t){if(e==="input"||e==="change")return ml(t)}function Uf(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var Me=typeof Object.is=="function"?Object.is:Uf;function Wn(e,t){if(Me(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var l=n[r];if(!uo.call(t,l)||!Me(e[l],t[l]))return!1}return!0}function za(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Pa(e,t){var n=za(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=za(n)}}function Su(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Su(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Eu(){for(var e=window,t=Ur();t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=Ur(e.document)}return t}function Ei(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}function $f(e){var t=Eu(),n=e.focusedElem,r=e.selectionRange;if(t!==n&&n&&n.ownerDocument&&Su(n.ownerDocument.documentElement,n)){if(r!==null&&Ei(n)){if(t=r.start,e=r.end,e===void 0&&(e=t),"selectionStart"in n)n.selectionStart=t,n.selectionEnd=Math.min(e,n.value.length);else if(e=(t=n.ownerDocument||document)&&t.defaultView||window,e.getSelection){e=e.getSelection();var l=n.textContent.length,o=Math.min(r.start,l);r=r.end===void 0?o:Math.min(r.end,l),!e.extend&&o>r&&(l=r,r=o,o=l),l=Pa(n,o);var i=Pa(n,r);l&&i&&(e.rangeCount!==1||e.anchorNode!==l.node||e.anchorOffset!==l.offset||e.focusNode!==i.node||e.focusOffset!==i.offset)&&(t=t.createRange(),t.setStart(l.node,l.offset),e.removeAllRanges(),o>r?(e.addRange(t),e.extend(i.node,i.offset)):(t.setEnd(i.node,i.offset),e.addRange(t)))}}for(t=[],e=n;e=e.parentNode;)e.nodeType===1&&t.push({element:e,left:e.scrollLeft,top:e.scrollTop});for(typeof n.focus=="function"&&n.focus(),n=0;n<t.length;n++)e=t[n],e.element.scrollLeft=e.left,e.element.scrollTop=e.top}}var Bf=Qe&&"documentMode"in document&&11>=document.documentMode,Bt=null,Po=null,bn=null,Lo=!1;function La(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Lo||Bt==null||Bt!==Ur(r)||(r=Bt,"selectionStart"in r&&Ei(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),bn&&Wn(bn,r)||(bn=r,r=Kr(Po,"onSelect"),0<r.length&&(t=new wi("onSelect","select",null,t,n),e.push({event:t,listeners:r}),t.target=Bt)))}function xr(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var Ht={animationend:xr("Animation","AnimationEnd"),animationiteration:xr("Animation","AnimationIteration"),animationstart:xr("Animation","AnimationStart"),transitionend:xr("Transition","TransitionEnd")},Ql={},Cu={};Qe&&(Cu=document.createElement("div").style,"AnimationEvent"in window||(delete Ht.animationend.animation,delete Ht.animationiteration.animation,delete Ht.animationstart.animation),"TransitionEvent"in window||delete Ht.transitionend.transition);function hl(e){if(Ql[e])return Ql[e];if(!Ht[e])return e;var t=Ht[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in Cu)return Ql[e]=t[n];return e}var Nu=hl("animationend"),_u=hl("animationiteration"),Tu=hl("animationstart"),zu=hl("transitionend"),Pu=new Map,ja="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function ht(e,t){Pu.set(e,t),bt(t,[e])}for(var Kl=0;Kl<ja.length;Kl++){var Yl=ja[Kl],Hf=Yl.toLowerCase(),Vf=Yl[0].toUpperCase()+Yl.slice(1);ht(Hf,"on"+Vf)}ht(Nu,"onAnimationEnd");ht(_u,"onAnimationIteration");ht(Tu,"onAnimationStart");ht("dblclick","onDoubleClick");ht("focusin","onFocus");ht("focusout","onBlur");ht(zu,"onTransitionEnd");rn("onMouseEnter",["mouseout","mouseover"]);rn("onMouseLeave",["mouseout","mouseover"]);rn("onPointerEnter",["pointerout","pointerover"]);rn("onPointerLeave",["pointerout","pointerover"]);bt("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));bt("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));bt("onBeforeInput",["compositionend","keypress","textInput","paste"]);bt("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));bt("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));bt("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Tn="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Wf=new Set("cancel close invalid load scroll toggle".split(" ").concat(Tn));function Ra(e,t,n){var r=e.type||"unknown-event";e.currentTarget=n,Bd(r,t,void 0,e),e.currentTarget=null}function Lu(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var r=e[n],l=r.event;r=r.listeners;e:{var o=void 0;if(t)for(var i=r.length-1;0<=i;i--){var a=r[i],s=a.instance,u=a.currentTarget;if(a=a.listener,s!==o&&l.isPropagationStopped())break e;Ra(l,a,u),o=s}else for(i=0;i<r.length;i++){if(a=r[i],s=a.instance,u=a.currentTarget,a=a.listener,s!==o&&l.isPropagationStopped())break e;Ra(l,a,u),o=s}}}if(Br)throw e=No,Br=!1,No=null,e}function A(e,t){var n=t[Mo];n===void 0&&(n=t[Mo]=new Set);var r=e+"__bubble";n.has(r)||(ju(t,e,2,!1),n.add(r))}function Xl(e,t,n){var r=0;t&&(r|=4),ju(n,e,r,t)}var wr="_reactListening"+Math.random().toString(36).slice(2);function Qn(e){if(!e[wr]){e[wr]=!0,Ds.forEach(function(n){n!=="selectionchange"&&(Wf.has(n)||Xl(n,!1,e),Xl(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[wr]||(t[wr]=!0,Xl("selectionchange",!1,t))}}function ju(e,t,n,r){switch(mu(t)){case 1:var l=lf;break;case 4:l=of;break;default:l=yi}n=l.bind(null,t,n,e),l=void 0,!Co||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(l=!0),r?l!==void 0?e.addEventListener(t,n,{capture:!0,passive:l}):e.addEventListener(t,n,!0):l!==void 0?e.addEventListener(t,n,{passive:l}):e.addEventListener(t,n,!1)}function Gl(e,t,n,r,l){var o=r;if(!(t&1)&&!(t&2)&&r!==null)e:for(;;){if(r===null)return;var i=r.tag;if(i===3||i===4){var a=r.stateNode.containerInfo;if(a===l||a.nodeType===8&&a.parentNode===l)break;if(i===4)for(i=r.return;i!==null;){var s=i.tag;if((s===3||s===4)&&(s=i.stateNode.containerInfo,s===l||s.nodeType===8&&s.parentNode===l))return;i=i.return}for(;a!==null;){if(i=St(a),i===null)return;if(s=i.tag,s===5||s===6){r=o=i;continue e}a=a.parentNode}}r=r.return}eu(function(){var u=o,m=mi(n),f=[];e:{var h=Pu.get(e);if(h!==void 0){var g=wi,w=e;switch(e){case"keypress":if(Rr(n)===0)break e;case"keydown":case"keyup":g=kf;break;case"focusin":w="focus",g=Hl;break;case"focusout":w="blur",g=Hl;break;case"beforeblur":case"afterblur":g=Hl;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":g=wa;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":g=uf;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":g=Cf;break;case Nu:case _u:case Tu:g=ff;break;case zu:g=_f;break;case"scroll":g=af;break;case"wheel":g=zf;break;case"copy":case"cut":case"paste":g=mf;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":g=Sa}var v=(t&4)!==0,E=!v&&e==="scroll",d=v?h!==null?h+"Capture":null:h;v=[];for(var c=u,p;c!==null;){p=c;var x=p.stateNode;if(p.tag===5&&x!==null&&(p=x,d!==null&&(x=Un(c,d),x!=null&&v.push(Kn(c,x,p)))),E)break;c=c.return}0<v.length&&(h=new g(h,w,null,n,m),f.push({event:h,listeners:v}))}}if(!(t&7)){e:{if(h=e==="mouseover"||e==="pointerover",g=e==="mouseout"||e==="pointerout",h&&n!==So&&(w=n.relatedTarget||n.fromElement)&&(St(w)||w[Ke]))break e;if((g||h)&&(h=m.window===m?m:(h=m.ownerDocument)?h.defaultView||h.parentWindow:window,g?(w=n.relatedTarget||n.toElement,g=u,w=w?St(w):null,w!==null&&(E=It(w),w!==E||w.tag!==5&&w.tag!==6)&&(w=null)):(g=null,w=u),g!==w)){if(v=wa,x="onMouseLeave",d="onMouseEnter",c="mouse",(e==="pointerout"||e==="pointerover")&&(v=Sa,x="onPointerLeave",d="onPointerEnter",c="pointer"),E=g==null?h:Vt(g),p=w==null?h:Vt(w),h=new v(x,c+"leave",g,n,m),h.target=E,h.relatedTarget=p,x=null,St(m)===u&&(v=new v(d,c+"enter",w,n,m),v.target=p,v.relatedTarget=E,x=v),E=x,g&&w)t:{for(v=g,d=w,c=0,p=v;p;p=At(p))c++;for(p=0,x=d;x;x=At(x))p++;for(;0<c-p;)v=At(v),c--;for(;0<p-c;)d=At(d),p--;for(;c--;){if(v===d||d!==null&&v===d.alternate)break t;v=At(v),d=At(d)}v=null}else v=null;g!==null&&ba(f,h,g,v,!1),w!==null&&E!==null&&ba(f,E,w,v,!0)}}e:{if(h=u?Vt(u):window,g=h.nodeName&&h.nodeName.toLowerCase(),g==="select"||g==="input"&&h.type==="file")var C=Mf;else if(Na(h))if(wu)C=Ff;else{C=Af;var T=Of}else(g=h.nodeName)&&g.toLowerCase()==="input"&&(h.type==="checkbox"||h.type==="radio")&&(C=Df);if(C&&(C=C(e,u))){xu(f,C,n,m);break e}T&&T(e,h,u),e==="focusout"&&(T=h._wrapperState)&&T.controlled&&h.type==="number"&&vo(h,"number",h.value)}switch(T=u?Vt(u):window,e){case"focusin":(Na(T)||T.contentEditable==="true")&&(Bt=T,Po=u,bn=null);break;case"focusout":bn=Po=Bt=null;break;case"mousedown":Lo=!0;break;case"contextmenu":case"mouseup":case"dragend":Lo=!1,La(f,n,m);break;case"selectionchange":if(Bf)break;case"keydown":case"keyup":La(f,n,m)}var z;if(Si)e:{switch(e){case"compositionstart":var P="onCompositionStart";break e;case"compositionend":P="onCompositionEnd";break e;case"compositionupdate":P="onCompositionUpdate";break e}P=void 0}else $t?vu(e,n)&&(P="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(P="onCompositionStart");P&&(gu&&n.locale!=="ko"&&($t||P!=="onCompositionStart"?P==="onCompositionEnd"&&$t&&(z=hu()):(nt=m,xi="value"in nt?nt.value:nt.textContent,$t=!0)),T=Kr(u,P),0<T.length&&(P=new ka(P,e,null,n,m),f.push({event:P,listeners:T}),z?P.data=z:(z=yu(n),z!==null&&(P.data=z)))),(z=Lf?jf(e,n):Rf(e,n))&&(u=Kr(u,"onBeforeInput"),0<u.length&&(m=new ka("onBeforeInput","beforeinput",null,n,m),f.push({event:m,listeners:u}),m.data=z))}Lu(f,t)})}function Kn(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Kr(e,t){for(var n=t+"Capture",r=[];e!==null;){var l=e,o=l.stateNode;l.tag===5&&o!==null&&(l=o,o=Un(e,n),o!=null&&r.unshift(Kn(e,o,l)),o=Un(e,t),o!=null&&r.push(Kn(e,o,l))),e=e.return}return r}function At(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5);return e||null}function ba(e,t,n,r,l){for(var o=t._reactName,i=[];n!==null&&n!==r;){var a=n,s=a.alternate,u=a.stateNode;if(s!==null&&s===r)break;a.tag===5&&u!==null&&(a=u,l?(s=Un(n,o),s!=null&&i.unshift(Kn(n,s,a))):l||(s=Un(n,o),s!=null&&i.push(Kn(n,s,a)))),n=n.return}i.length!==0&&e.push({event:t,listeners:i})}var Qf=/\r\n?/g,Kf=/\u0000|\uFFFD/g;function Ia(e){return(typeof e=="string"?e:""+e).replace(Qf,`
`).replace(Kf,"")}function kr(e,t,n){if(t=Ia(t),Ia(e)!==t&&n)throw Error(k(425))}function Yr(){}var jo=null,Ro=null;function bo(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Io=typeof setTimeout=="function"?setTimeout:void 0,Yf=typeof clearTimeout=="function"?clearTimeout:void 0,Ma=typeof Promise=="function"?Promise:void 0,Xf=typeof queueMicrotask=="function"?queueMicrotask:typeof Ma<"u"?function(e){return Ma.resolve(null).then(e).catch(Gf)}:Io;function Gf(e){setTimeout(function(){throw e})}function Jl(e,t){var n=t,r=0;do{var l=n.nextSibling;if(e.removeChild(n),l&&l.nodeType===8)if(n=l.data,n==="/$"){if(r===0){e.removeChild(l),Hn(t);return}r--}else n!=="$"&&n!=="$?"&&n!=="$!"||r++;n=l}while(n);Hn(t)}function st(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?")break;if(t==="/$")return null}}return e}function Oa(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"){if(t===0)return e;t--}else n==="/$"&&t++}e=e.previousSibling}return null}var pn=Math.random().toString(36).slice(2),De="__reactFiber$"+pn,Yn="__reactProps$"+pn,Ke="__reactContainer$"+pn,Mo="__reactEvents$"+pn,Jf="__reactListeners$"+pn,qf="__reactHandles$"+pn;function St(e){var t=e[De];if(t)return t;for(var n=e.parentNode;n;){if(t=n[Ke]||n[De]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=Oa(e);e!==null;){if(n=e[De])return n;e=Oa(e)}return t}e=n,n=e.parentNode}return null}function ir(e){return e=e[De]||e[Ke],!e||e.tag!==5&&e.tag!==6&&e.tag!==13&&e.tag!==3?null:e}function Vt(e){if(e.tag===5||e.tag===6)return e.stateNode;throw Error(k(33))}function gl(e){return e[Yn]||null}var Oo=[],Wt=-1;function gt(e){return{current:e}}function D(e){0>Wt||(e.current=Oo[Wt],Oo[Wt]=null,Wt--)}function O(e,t){Wt++,Oo[Wt]=e.current,e.current=t}var mt={},ie=gt(mt),pe=gt(!1),zt=mt;function ln(e,t){var n=e.type.contextTypes;if(!n)return mt;var r=e.stateNode;if(r&&r.__reactInternalMemoizedUnmaskedChildContext===t)return r.__reactInternalMemoizedMaskedChildContext;var l={},o;for(o in n)l[o]=t[o];return r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=t,e.__reactInternalMemoizedMaskedChildContext=l),l}function me(e){return e=e.childContextTypes,e!=null}function Xr(){D(pe),D(ie)}function Aa(e,t,n){if(ie.current!==mt)throw Error(k(168));O(ie,t),O(pe,n)}function Ru(e,t,n){var r=e.stateNode;if(t=t.childContextTypes,typeof r.getChildContext!="function")return n;r=r.getChildContext();for(var l in r)if(!(l in t))throw Error(k(108,Md(e)||"Unknown",l));return B({},n,r)}function Gr(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||mt,zt=ie.current,O(ie,e),O(pe,pe.current),!0}function Da(e,t,n){var r=e.stateNode;if(!r)throw Error(k(169));n?(e=Ru(e,t,zt),r.__reactInternalMemoizedMergedChildContext=e,D(pe),D(ie),O(ie,e)):D(pe),O(pe,n)}var Be=null,vl=!1,ql=!1;function bu(e){Be===null?Be=[e]:Be.push(e)}function Zf(e){vl=!0,bu(e)}function vt(){if(!ql&&Be!==null){ql=!0;var e=0,t=M;try{var n=Be;for(M=1;e<n.length;e++){var r=n[e];do r=r(!0);while(r!==null)}Be=null,vl=!1}catch(l){throw Be!==null&&(Be=Be.slice(e+1)),lu(hi,vt),l}finally{M=t,ql=!1}}return null}var Qt=[],Kt=0,Jr=null,qr=0,Se=[],Ee=0,Pt=null,He=1,Ve="";function wt(e,t){Qt[Kt++]=qr,Qt[Kt++]=Jr,Jr=e,qr=t}function Iu(e,t,n){Se[Ee++]=He,Se[Ee++]=Ve,Se[Ee++]=Pt,Pt=e;var r=He;e=Ve;var l=32-be(r)-1;r&=~(1<<l),n+=1;var o=32-be(t)+l;if(30<o){var i=l-l%5;o=(r&(1<<i)-1).toString(32),r>>=i,l-=i,He=1<<32-be(t)+l|n<<l|r,Ve=o+e}else He=1<<o|n<<l|r,Ve=e}function Ci(e){e.return!==null&&(wt(e,1),Iu(e,1,0))}function Ni(e){for(;e===Jr;)Jr=Qt[--Kt],Qt[Kt]=null,qr=Qt[--Kt],Qt[Kt]=null;for(;e===Pt;)Pt=Se[--Ee],Se[Ee]=null,Ve=Se[--Ee],Se[Ee]=null,He=Se[--Ee],Se[Ee]=null}var ye=null,ve=null,F=!1,Re=null;function Mu(e,t){var n=Ce(5,null,null,0);n.elementType="DELETED",n.stateNode=t,n.return=e,t=e.deletions,t===null?(e.deletions=[n],e.flags|=16):t.push(n)}function Fa(e,t){switch(e.tag){case 5:var n=e.type;return t=t.nodeType!==1||n.toLowerCase()!==t.nodeName.toLowerCase()?null:t,t!==null?(e.stateNode=t,ye=e,ve=st(t.firstChild),!0):!1;case 6:return t=e.pendingProps===""||t.nodeType!==3?null:t,t!==null?(e.stateNode=t,ye=e,ve=null,!0):!1;case 13:return t=t.nodeType!==8?null:t,t!==null?(n=Pt!==null?{id:He,overflow:Ve}:null,e.memoizedState={dehydrated:t,treeContext:n,retryLane:1073741824},n=Ce(18,null,null,0),n.stateNode=t,n.return=e,e.child=n,ye=e,ve=null,!0):!1;default:return!1}}function Ao(e){return(e.mode&1)!==0&&(e.flags&128)===0}function Do(e){if(F){var t=ve;if(t){var n=t;if(!Fa(e,t)){if(Ao(e))throw Error(k(418));t=st(n.nextSibling);var r=ye;t&&Fa(e,t)?Mu(r,n):(e.flags=e.flags&-4097|2,F=!1,ye=e)}}else{if(Ao(e))throw Error(k(418));e.flags=e.flags&-4097|2,F=!1,ye=e}}}function Ua(e){for(e=e.return;e!==null&&e.tag!==5&&e.tag!==3&&e.tag!==13;)e=e.return;ye=e}function Sr(e){if(e!==ye)return!1;if(!F)return Ua(e),F=!0,!1;var t;if((t=e.tag!==3)&&!(t=e.tag!==5)&&(t=e.type,t=t!=="head"&&t!=="body"&&!bo(e.type,e.memoizedProps)),t&&(t=ve)){if(Ao(e))throw Ou(),Error(k(418));for(;t;)Mu(e,t),t=st(t.nextSibling)}if(Ua(e),e.tag===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(k(317));e:{for(e=e.nextSibling,t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"){if(t===0){ve=st(e.nextSibling);break e}t--}else n!=="$"&&n!=="$!"&&n!=="$?"||t++}e=e.nextSibling}ve=null}}else ve=ye?st(e.stateNode.nextSibling):null;return!0}function Ou(){for(var e=ve;e;)e=st(e.nextSibling)}function on(){ve=ye=null,F=!1}function _i(e){Re===null?Re=[e]:Re.push(e)}var ep=Ge.ReactCurrentBatchConfig;function kn(e,t,n){if(e=n.ref,e!==null&&typeof e!="function"&&typeof e!="object"){if(n._owner){if(n=n._owner,n){if(n.tag!==1)throw Error(k(309));var r=n.stateNode}if(!r)throw Error(k(147,e));var l=r,o=""+e;return t!==null&&t.ref!==null&&typeof t.ref=="function"&&t.ref._stringRef===o?t.ref:(t=function(i){var a=l.refs;i===null?delete a[o]:a[o]=i},t._stringRef=o,t)}if(typeof e!="string")throw Error(k(284));if(!n._owner)throw Error(k(290,e))}return e}function Er(e,t){throw e=Object.prototype.toString.call(t),Error(k(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e))}function $a(e){var t=e._init;return t(e._payload)}function Au(e){function t(d,c){if(e){var p=d.deletions;p===null?(d.deletions=[c],d.flags|=16):p.push(c)}}function n(d,c){if(!e)return null;for(;c!==null;)t(d,c),c=c.sibling;return null}function r(d,c){for(d=new Map;c!==null;)c.key!==null?d.set(c.key,c):d.set(c.index,c),c=c.sibling;return d}function l(d,c){return d=ft(d,c),d.index=0,d.sibling=null,d}function o(d,c,p){return d.index=p,e?(p=d.alternate,p!==null?(p=p.index,p<c?(d.flags|=2,c):p):(d.flags|=2,c)):(d.flags|=1048576,c)}function i(d){return e&&d.alternate===null&&(d.flags|=2),d}function a(d,c,p,x){return c===null||c.tag!==6?(c=oo(p,d.mode,x),c.return=d,c):(c=l(c,p),c.return=d,c)}function s(d,c,p,x){var C=p.type;return C===Ut?m(d,c,p.props.children,x,p.key):c!==null&&(c.elementType===C||typeof C=="object"&&C!==null&&C.$$typeof===qe&&$a(C)===c.type)?(x=l(c,p.props),x.ref=kn(d,c,p),x.return=d,x):(x=Fr(p.type,p.key,p.props,null,d.mode,x),x.ref=kn(d,c,p),x.return=d,x)}function u(d,c,p,x){return c===null||c.tag!==4||c.stateNode.containerInfo!==p.containerInfo||c.stateNode.implementation!==p.implementation?(c=io(p,d.mode,x),c.return=d,c):(c=l(c,p.children||[]),c.return=d,c)}function m(d,c,p,x,C){return c===null||c.tag!==7?(c=_t(p,d.mode,x,C),c.return=d,c):(c=l(c,p),c.return=d,c)}function f(d,c,p){if(typeof c=="string"&&c!==""||typeof c=="number")return c=oo(""+c,d.mode,p),c.return=d,c;if(typeof c=="object"&&c!==null){switch(c.$$typeof){case fr:return p=Fr(c.type,c.key,c.props,null,d.mode,p),p.ref=kn(d,null,c),p.return=d,p;case Ft:return c=io(c,d.mode,p),c.return=d,c;case qe:var x=c._init;return f(d,x(c._payload),p)}if(Nn(c)||gn(c))return c=_t(c,d.mode,p,null),c.return=d,c;Er(d,c)}return null}function h(d,c,p,x){var C=c!==null?c.key:null;if(typeof p=="string"&&p!==""||typeof p=="number")return C!==null?null:a(d,c,""+p,x);if(typeof p=="object"&&p!==null){switch(p.$$typeof){case fr:return p.key===C?s(d,c,p,x):null;case Ft:return p.key===C?u(d,c,p,x):null;case qe:return C=p._init,h(d,c,C(p._payload),x)}if(Nn(p)||gn(p))return C!==null?null:m(d,c,p,x,null);Er(d,p)}return null}function g(d,c,p,x,C){if(typeof x=="string"&&x!==""||typeof x=="number")return d=d.get(p)||null,a(c,d,""+x,C);if(typeof x=="object"&&x!==null){switch(x.$$typeof){case fr:return d=d.get(x.key===null?p:x.key)||null,s(c,d,x,C);case Ft:return d=d.get(x.key===null?p:x.key)||null,u(c,d,x,C);case qe:var T=x._init;return g(d,c,p,T(x._payload),C)}if(Nn(x)||gn(x))return d=d.get(p)||null,m(c,d,x,C,null);Er(c,x)}return null}function w(d,c,p,x){for(var C=null,T=null,z=c,P=c=0,V=null;z!==null&&P<p.length;P++){z.index>P?(V=z,z=null):V=z.sibling;var b=h(d,z,p[P],x);if(b===null){z===null&&(z=V);break}e&&z&&b.alternate===null&&t(d,z),c=o(b,c,P),T===null?C=b:T.sibling=b,T=b,z=V}if(P===p.length)return n(d,z),F&&wt(d,P),C;if(z===null){for(;P<p.length;P++)z=f(d,p[P],x),z!==null&&(c=o(z,c,P),T===null?C=z:T.sibling=z,T=z);return F&&wt(d,P),C}for(z=r(d,z);P<p.length;P++)V=g(z,d,P,p[P],x),V!==null&&(e&&V.alternate!==null&&z.delete(V.key===null?P:V.key),c=o(V,c,P),T===null?C=V:T.sibling=V,T=V);return e&&z.forEach(function(ze){return t(d,ze)}),F&&wt(d,P),C}function v(d,c,p,x){var C=gn(p);if(typeof C!="function")throw Error(k(150));if(p=C.call(p),p==null)throw Error(k(151));for(var T=C=null,z=c,P=c=0,V=null,b=p.next();z!==null&&!b.done;P++,b=p.next()){z.index>P?(V=z,z=null):V=z.sibling;var ze=h(d,z,b.value,x);if(ze===null){z===null&&(z=V);break}e&&z&&ze.alternate===null&&t(d,z),c=o(ze,c,P),T===null?C=ze:T.sibling=ze,T=ze,z=V}if(b.done)return n(d,z),F&&wt(d,P),C;if(z===null){for(;!b.done;P++,b=p.next())b=f(d,b.value,x),b!==null&&(c=o(b,c,P),T===null?C=b:T.sibling=b,T=b);return F&&wt(d,P),C}for(z=r(d,z);!b.done;P++,b=p.next())b=g(z,d,P,b.value,x),b!==null&&(e&&b.alternate!==null&&z.delete(b.key===null?P:b.key),c=o(b,c,P),T===null?C=b:T.sibling=b,T=b);return e&&z.forEach(function(mn){return t(d,mn)}),F&&wt(d,P),C}function E(d,c,p,x){if(typeof p=="object"&&p!==null&&p.type===Ut&&p.key===null&&(p=p.props.children),typeof p=="object"&&p!==null){switch(p.$$typeof){case fr:e:{for(var C=p.key,T=c;T!==null;){if(T.key===C){if(C=p.type,C===Ut){if(T.tag===7){n(d,T.sibling),c=l(T,p.props.children),c.return=d,d=c;break e}}else if(T.elementType===C||typeof C=="object"&&C!==null&&C.$$typeof===qe&&$a(C)===T.type){n(d,T.sibling),c=l(T,p.props),c.ref=kn(d,T,p),c.return=d,d=c;break e}n(d,T);break}else t(d,T);T=T.sibling}p.type===Ut?(c=_t(p.props.children,d.mode,x,p.key),c.return=d,d=c):(x=Fr(p.type,p.key,p.props,null,d.mode,x),x.ref=kn(d,c,p),x.return=d,d=x)}return i(d);case Ft:e:{for(T=p.key;c!==null;){if(c.key===T)if(c.tag===4&&c.stateNode.containerInfo===p.containerInfo&&c.stateNode.implementation===p.implementation){n(d,c.sibling),c=l(c,p.children||[]),c.return=d,d=c;break e}else{n(d,c);break}else t(d,c);c=c.sibling}c=io(p,d.mode,x),c.return=d,d=c}return i(d);case qe:return T=p._init,E(d,c,T(p._payload),x)}if(Nn(p))return w(d,c,p,x);if(gn(p))return v(d,c,p,x);Er(d,p)}return typeof p=="string"&&p!==""||typeof p=="number"?(p=""+p,c!==null&&c.tag===6?(n(d,c.sibling),c=l(c,p),c.return=d,d=c):(n(d,c),c=oo(p,d.mode,x),c.return=d,d=c),i(d)):n(d,c)}return E}var an=Au(!0),Du=Au(!1),Zr=gt(null),el=null,Yt=null,Ti=null;function zi(){Ti=Yt=el=null}function Pi(e){var t=Zr.current;D(Zr),e._currentValue=t}function Fo(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,r!==null&&(r.childLanes|=t)):r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t),e===n)break;e=e.return}}function tn(e,t){el=e,Ti=Yt=null,e=e.dependencies,e!==null&&e.firstContext!==null&&(e.lanes&t&&(fe=!0),e.firstContext=null)}function _e(e){var t=e._currentValue;if(Ti!==e)if(e={context:e,memoizedValue:t,next:null},Yt===null){if(el===null)throw Error(k(308));Yt=e,el.dependencies={lanes:0,firstContext:e}}else Yt=Yt.next=e;return t}var Et=null;function Li(e){Et===null?Et=[e]:Et.push(e)}function Fu(e,t,n,r){var l=t.interleaved;return l===null?(n.next=n,Li(t)):(n.next=l.next,l.next=n),t.interleaved=n,Ye(e,r)}function Ye(e,t){e.lanes|=t;var n=e.alternate;for(n!==null&&(n.lanes|=t),n=e,e=e.return;e!==null;)e.childLanes|=t,n=e.alternate,n!==null&&(n.childLanes|=t),n=e,e=e.return;return n.tag===3?n.stateNode:null}var Ze=!1;function ji(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function Uu(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function We(e,t){return{eventTime:e,lane:t,tag:0,payload:null,callback:null,next:null}}function ut(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,I&2){var l=r.pending;return l===null?t.next=t:(t.next=l.next,l.next=t),r.pending=t,Ye(e,n)}return l=r.interleaved,l===null?(t.next=t,Li(r)):(t.next=l.next,l.next=t),r.interleaved=t,Ye(e,n)}function br(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194240)!==0)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,gi(e,n)}}function Ba(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var l=null,o=null;if(n=n.firstBaseUpdate,n!==null){do{var i={eventTime:n.eventTime,lane:n.lane,tag:n.tag,payload:n.payload,callback:n.callback,next:null};o===null?l=o=i:o=o.next=i,n=n.next}while(n!==null);o===null?l=o=t:o=o.next=t}else l=o=t;n={baseState:r.baseState,firstBaseUpdate:l,lastBaseUpdate:o,shared:r.shared,effects:r.effects},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}function tl(e,t,n,r){var l=e.updateQueue;Ze=!1;var o=l.firstBaseUpdate,i=l.lastBaseUpdate,a=l.shared.pending;if(a!==null){l.shared.pending=null;var s=a,u=s.next;s.next=null,i===null?o=u:i.next=u,i=s;var m=e.alternate;m!==null&&(m=m.updateQueue,a=m.lastBaseUpdate,a!==i&&(a===null?m.firstBaseUpdate=u:a.next=u,m.lastBaseUpdate=s))}if(o!==null){var f=l.baseState;i=0,m=u=s=null,a=o;do{var h=a.lane,g=a.eventTime;if((r&h)===h){m!==null&&(m=m.next={eventTime:g,lane:0,tag:a.tag,payload:a.payload,callback:a.callback,next:null});e:{var w=e,v=a;switch(h=t,g=n,v.tag){case 1:if(w=v.payload,typeof w=="function"){f=w.call(g,f,h);break e}f=w;break e;case 3:w.flags=w.flags&-65537|128;case 0:if(w=v.payload,h=typeof w=="function"?w.call(g,f,h):w,h==null)break e;f=B({},f,h);break e;case 2:Ze=!0}}a.callback!==null&&a.lane!==0&&(e.flags|=64,h=l.effects,h===null?l.effects=[a]:h.push(a))}else g={eventTime:g,lane:h,tag:a.tag,payload:a.payload,callback:a.callback,next:null},m===null?(u=m=g,s=f):m=m.next=g,i|=h;if(a=a.next,a===null){if(a=l.shared.pending,a===null)break;h=a,a=h.next,h.next=null,l.lastBaseUpdate=h,l.shared.pending=null}}while(!0);if(m===null&&(s=f),l.baseState=s,l.firstBaseUpdate=u,l.lastBaseUpdate=m,t=l.shared.interleaved,t!==null){l=t;do i|=l.lane,l=l.next;while(l!==t)}else o===null&&(l.shared.lanes=0);jt|=i,e.lanes=i,e.memoizedState=f}}function Ha(e,t,n){if(e=t.effects,t.effects=null,e!==null)for(t=0;t<e.length;t++){var r=e[t],l=r.callback;if(l!==null){if(r.callback=null,r=n,typeof l!="function")throw Error(k(191,l));l.call(r)}}}var ar={},Ue=gt(ar),Xn=gt(ar),Gn=gt(ar);function Ct(e){if(e===ar)throw Error(k(174));return e}function Ri(e,t){switch(O(Gn,t),O(Xn,e),O(Ue,ar),e=t.nodeType,e){case 9:case 11:t=(t=t.documentElement)?t.namespaceURI:xo(null,"");break;default:e=e===8?t.parentNode:t,t=e.namespaceURI||null,e=e.tagName,t=xo(t,e)}D(Ue),O(Ue,t)}function sn(){D(Ue),D(Xn),D(Gn)}function $u(e){Ct(Gn.current);var t=Ct(Ue.current),n=xo(t,e.type);t!==n&&(O(Xn,e),O(Ue,n))}function bi(e){Xn.current===e&&(D(Ue),D(Xn))}var U=gt(0);function nl(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||n.data==="$?"||n.data==="$!"))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!==void 0){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var Zl=[];function Ii(){for(var e=0;e<Zl.length;e++)Zl[e]._workInProgressVersionPrimary=null;Zl.length=0}var Ir=Ge.ReactCurrentDispatcher,eo=Ge.ReactCurrentBatchConfig,Lt=0,$=null,Y=null,q=null,rl=!1,In=!1,Jn=0,tp=0;function re(){throw Error(k(321))}function Mi(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!Me(e[n],t[n]))return!1;return!0}function Oi(e,t,n,r,l,o){if(Lt=o,$=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,Ir.current=e===null||e.memoizedState===null?op:ip,e=n(r,l),In){o=0;do{if(In=!1,Jn=0,25<=o)throw Error(k(301));o+=1,q=Y=null,t.updateQueue=null,Ir.current=ap,e=n(r,l)}while(In)}if(Ir.current=ll,t=Y!==null&&Y.next!==null,Lt=0,q=Y=$=null,rl=!1,t)throw Error(k(300));return e}function Ai(){var e=Jn!==0;return Jn=0,e}function Ae(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return q===null?$.memoizedState=q=e:q=q.next=e,q}function Te(){if(Y===null){var e=$.alternate;e=e!==null?e.memoizedState:null}else e=Y.next;var t=q===null?$.memoizedState:q.next;if(t!==null)q=t,Y=e;else{if(e===null)throw Error(k(310));Y=e,e={memoizedState:Y.memoizedState,baseState:Y.baseState,baseQueue:Y.baseQueue,queue:Y.queue,next:null},q===null?$.memoizedState=q=e:q=q.next=e}return q}function qn(e,t){return typeof t=="function"?t(e):t}function to(e){var t=Te(),n=t.queue;if(n===null)throw Error(k(311));n.lastRenderedReducer=e;var r=Y,l=r.baseQueue,o=n.pending;if(o!==null){if(l!==null){var i=l.next;l.next=o.next,o.next=i}r.baseQueue=l=o,n.pending=null}if(l!==null){o=l.next,r=r.baseState;var a=i=null,s=null,u=o;do{var m=u.lane;if((Lt&m)===m)s!==null&&(s=s.next={lane:0,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),r=u.hasEagerState?u.eagerState:e(r,u.action);else{var f={lane:m,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null};s===null?(a=s=f,i=r):s=s.next=f,$.lanes|=m,jt|=m}u=u.next}while(u!==null&&u!==o);s===null?i=r:s.next=a,Me(r,t.memoizedState)||(fe=!0),t.memoizedState=r,t.baseState=i,t.baseQueue=s,n.lastRenderedState=r}if(e=n.interleaved,e!==null){l=e;do o=l.lane,$.lanes|=o,jt|=o,l=l.next;while(l!==e)}else l===null&&(n.lanes=0);return[t.memoizedState,n.dispatch]}function no(e){var t=Te(),n=t.queue;if(n===null)throw Error(k(311));n.lastRenderedReducer=e;var r=n.dispatch,l=n.pending,o=t.memoizedState;if(l!==null){n.pending=null;var i=l=l.next;do o=e(o,i.action),i=i.next;while(i!==l);Me(o,t.memoizedState)||(fe=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),n.lastRenderedState=o}return[o,r]}function Bu(){}function Hu(e,t){var n=$,r=Te(),l=t(),o=!Me(r.memoizedState,l);if(o&&(r.memoizedState=l,fe=!0),r=r.queue,Di(Qu.bind(null,n,r,e),[e]),r.getSnapshot!==t||o||q!==null&&q.memoizedState.tag&1){if(n.flags|=2048,Zn(9,Wu.bind(null,n,r,l,t),void 0,null),Z===null)throw Error(k(349));Lt&30||Vu(n,t,l)}return l}function Vu(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=$.updateQueue,t===null?(t={lastEffect:null,stores:null},$.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function Wu(e,t,n,r){t.value=n,t.getSnapshot=r,Ku(t)&&Yu(e)}function Qu(e,t,n){return n(function(){Ku(t)&&Yu(e)})}function Ku(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!Me(e,n)}catch{return!0}}function Yu(e){var t=Ye(e,1);t!==null&&Ie(t,e,1,-1)}function Va(e){var t=Ae();return typeof e=="function"&&(e=e()),t.memoizedState=t.baseState=e,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:qn,lastRenderedState:e},t.queue=e,e=e.dispatch=lp.bind(null,$,e),[t.memoizedState,e]}function Zn(e,t,n,r){return e={tag:e,create:t,destroy:n,deps:r,next:null},t=$.updateQueue,t===null?(t={lastEffect:null,stores:null},$.updateQueue=t,t.lastEffect=e.next=e):(n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e)),e}function Xu(){return Te().memoizedState}function Mr(e,t,n,r){var l=Ae();$.flags|=e,l.memoizedState=Zn(1|t,n,void 0,r===void 0?null:r)}function yl(e,t,n,r){var l=Te();r=r===void 0?null:r;var o=void 0;if(Y!==null){var i=Y.memoizedState;if(o=i.destroy,r!==null&&Mi(r,i.deps)){l.memoizedState=Zn(t,n,o,r);return}}$.flags|=e,l.memoizedState=Zn(1|t,n,o,r)}function Wa(e,t){return Mr(8390656,8,e,t)}function Di(e,t){return yl(2048,8,e,t)}function Gu(e,t){return yl(4,2,e,t)}function Ju(e,t){return yl(4,4,e,t)}function qu(e,t){if(typeof t=="function")return e=e(),t(e),function(){t(null)};if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Zu(e,t,n){return n=n!=null?n.concat([e]):null,yl(4,4,qu.bind(null,t,e),n)}function Fi(){}function ec(e,t){var n=Te();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&Mi(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function tc(e,t){var n=Te();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&Mi(t,r[1])?r[0]:(e=e(),n.memoizedState=[e,t],e)}function nc(e,t,n){return Lt&21?(Me(n,t)||(n=au(),$.lanes|=n,jt|=n,e.baseState=!0),t):(e.baseState&&(e.baseState=!1,fe=!0),e.memoizedState=n)}function np(e,t){var n=M;M=n!==0&&4>n?n:4,e(!0);var r=eo.transition;eo.transition={};try{e(!1),t()}finally{M=n,eo.transition=r}}function rc(){return Te().memoizedState}function rp(e,t,n){var r=dt(e);if(n={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null},lc(e))oc(t,n);else if(n=Fu(e,t,n,r),n!==null){var l=se();Ie(n,e,r,l),ic(n,t,r)}}function lp(e,t,n){var r=dt(e),l={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null};if(lc(e))oc(t,l);else{var o=e.alternate;if(e.lanes===0&&(o===null||o.lanes===0)&&(o=t.lastRenderedReducer,o!==null))try{var i=t.lastRenderedState,a=o(i,n);if(l.hasEagerState=!0,l.eagerState=a,Me(a,i)){var s=t.interleaved;s===null?(l.next=l,Li(t)):(l.next=s.next,s.next=l),t.interleaved=l;return}}catch{}finally{}n=Fu(e,t,l,r),n!==null&&(l=se(),Ie(n,e,r,l),ic(n,t,r))}}function lc(e){var t=e.alternate;return e===$||t!==null&&t===$}function oc(e,t){In=rl=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function ic(e,t,n){if(n&4194240){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,gi(e,n)}}var ll={readContext:_e,useCallback:re,useContext:re,useEffect:re,useImperativeHandle:re,useInsertionEffect:re,useLayoutEffect:re,useMemo:re,useReducer:re,useRef:re,useState:re,useDebugValue:re,useDeferredValue:re,useTransition:re,useMutableSource:re,useSyncExternalStore:re,useId:re,unstable_isNewReconciler:!1},op={readContext:_e,useCallback:function(e,t){return Ae().memoizedState=[e,t===void 0?null:t],e},useContext:_e,useEffect:Wa,useImperativeHandle:function(e,t,n){return n=n!=null?n.concat([e]):null,Mr(4194308,4,qu.bind(null,t,e),n)},useLayoutEffect:function(e,t){return Mr(4194308,4,e,t)},useInsertionEffect:function(e,t){return Mr(4,2,e,t)},useMemo:function(e,t){var n=Ae();return t=t===void 0?null:t,e=e(),n.memoizedState=[e,t],e},useReducer:function(e,t,n){var r=Ae();return t=n!==void 0?n(t):t,r.memoizedState=r.baseState=t,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:t},r.queue=e,e=e.dispatch=rp.bind(null,$,e),[r.memoizedState,e]},useRef:function(e){var t=Ae();return e={current:e},t.memoizedState=e},useState:Va,useDebugValue:Fi,useDeferredValue:function(e){return Ae().memoizedState=e},useTransition:function(){var e=Va(!1),t=e[0];return e=np.bind(null,e[1]),Ae().memoizedState=e,[t,e]},useMutableSource:function(){},useSyncExternalStore:function(e,t,n){var r=$,l=Ae();if(F){if(n===void 0)throw Error(k(407));n=n()}else{if(n=t(),Z===null)throw Error(k(349));Lt&30||Vu(r,t,n)}l.memoizedState=n;var o={value:n,getSnapshot:t};return l.queue=o,Wa(Qu.bind(null,r,o,e),[e]),r.flags|=2048,Zn(9,Wu.bind(null,r,o,n,t),void 0,null),n},useId:function(){var e=Ae(),t=Z.identifierPrefix;if(F){var n=Ve,r=He;n=(r&~(1<<32-be(r)-1)).toString(32)+n,t=":"+t+"R"+n,n=Jn++,0<n&&(t+="H"+n.toString(32)),t+=":"}else n=tp++,t=":"+t+"r"+n.toString(32)+":";return e.memoizedState=t},unstable_isNewReconciler:!1},ip={readContext:_e,useCallback:ec,useContext:_e,useEffect:Di,useImperativeHandle:Zu,useInsertionEffect:Gu,useLayoutEffect:Ju,useMemo:tc,useReducer:to,useRef:Xu,useState:function(){return to(qn)},useDebugValue:Fi,useDeferredValue:function(e){var t=Te();return nc(t,Y.memoizedState,e)},useTransition:function(){var e=to(qn)[0],t=Te().memoizedState;return[e,t]},useMutableSource:Bu,useSyncExternalStore:Hu,useId:rc,unstable_isNewReconciler:!1},ap={readContext:_e,useCallback:ec,useContext:_e,useEffect:Di,useImperativeHandle:Zu,useInsertionEffect:Gu,useLayoutEffect:Ju,useMemo:tc,useReducer:no,useRef:Xu,useState:function(){return no(qn)},useDebugValue:Fi,useDeferredValue:function(e){var t=Te();return Y===null?t.memoizedState=e:nc(t,Y.memoizedState,e)},useTransition:function(){var e=no(qn)[0],t=Te().memoizedState;return[e,t]},useMutableSource:Bu,useSyncExternalStore:Hu,useId:rc,unstable_isNewReconciler:!1};function Le(e,t){if(e&&e.defaultProps){t=B({},t),e=e.defaultProps;for(var n in e)t[n]===void 0&&(t[n]=e[n]);return t}return t}function Uo(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:B({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var xl={isMounted:function(e){return(e=e._reactInternals)?It(e)===e:!1},enqueueSetState:function(e,t,n){e=e._reactInternals;var r=se(),l=dt(e),o=We(r,l);o.payload=t,n!=null&&(o.callback=n),t=ut(e,o,l),t!==null&&(Ie(t,e,l,r),br(t,e,l))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=se(),l=dt(e),o=We(r,l);o.tag=1,o.payload=t,n!=null&&(o.callback=n),t=ut(e,o,l),t!==null&&(Ie(t,e,l,r),br(t,e,l))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=se(),r=dt(e),l=We(n,r);l.tag=2,t!=null&&(l.callback=t),t=ut(e,l,r),t!==null&&(Ie(t,e,r,n),br(t,e,r))}};function Qa(e,t,n,r,l,o,i){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(r,o,i):t.prototype&&t.prototype.isPureReactComponent?!Wn(n,r)||!Wn(l,o):!0}function ac(e,t,n){var r=!1,l=mt,o=t.contextType;return typeof o=="object"&&o!==null?o=_e(o):(l=me(t)?zt:ie.current,r=t.contextTypes,o=(r=r!=null)?ln(e,l):mt),t=new t(n,o),e.memoizedState=t.state!==null&&t.state!==void 0?t.state:null,t.updater=xl,e.stateNode=t,t._reactInternals=e,r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=l,e.__reactInternalMemoizedMaskedChildContext=o),t}function Ka(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&xl.enqueueReplaceState(t,t.state,null)}function $o(e,t,n,r){var l=e.stateNode;l.props=n,l.state=e.memoizedState,l.refs={},ji(e);var o=t.contextType;typeof o=="object"&&o!==null?l.context=_e(o):(o=me(t)?zt:ie.current,l.context=ln(e,o)),l.state=e.memoizedState,o=t.getDerivedStateFromProps,typeof o=="function"&&(Uo(e,t,o,n),l.state=e.memoizedState),typeof t.getDerivedStateFromProps=="function"||typeof l.getSnapshotBeforeUpdate=="function"||typeof l.UNSAFE_componentWillMount!="function"&&typeof l.componentWillMount!="function"||(t=l.state,typeof l.componentWillMount=="function"&&l.componentWillMount(),typeof l.UNSAFE_componentWillMount=="function"&&l.UNSAFE_componentWillMount(),t!==l.state&&xl.enqueueReplaceState(l,l.state,null),tl(e,n,l,r),l.state=e.memoizedState),typeof l.componentDidMount=="function"&&(e.flags|=4194308)}function un(e,t){try{var n="",r=t;do n+=Id(r),r=r.return;while(r);var l=n}catch(o){l=`
Error generating stack: `+o.message+`
`+o.stack}return{value:e,source:t,stack:l,digest:null}}function ro(e,t,n){return{value:e,source:null,stack:n??null,digest:t??null}}function Bo(e,t){try{console.error(t.value)}catch(n){setTimeout(function(){throw n})}}var sp=typeof WeakMap=="function"?WeakMap:Map;function sc(e,t,n){n=We(-1,n),n.tag=3,n.payload={element:null};var r=t.value;return n.callback=function(){il||(il=!0,qo=r),Bo(e,t)},n}function uc(e,t,n){n=We(-1,n),n.tag=3;var r=e.type.getDerivedStateFromError;if(typeof r=="function"){var l=t.value;n.payload=function(){return r(l)},n.callback=function(){Bo(e,t)}}var o=e.stateNode;return o!==null&&typeof o.componentDidCatch=="function"&&(n.callback=function(){Bo(e,t),typeof r!="function"&&(ct===null?ct=new Set([this]):ct.add(this));var i=t.stack;this.componentDidCatch(t.value,{componentStack:i!==null?i:""})}),n}function Ya(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new sp;var l=new Set;r.set(t,l)}else l=r.get(t),l===void 0&&(l=new Set,r.set(t,l));l.has(n)||(l.add(n),e=Sp.bind(null,e,t,n),t.then(e,e))}function Xa(e){do{var t;if((t=e.tag===13)&&(t=e.memoizedState,t=t!==null?t.dehydrated!==null:!0),t)return e;e=e.return}while(e!==null);return null}function Ga(e,t,n,r,l){return e.mode&1?(e.flags|=65536,e.lanes=l,e):(e===t?e.flags|=65536:(e.flags|=128,n.flags|=131072,n.flags&=-52805,n.tag===1&&(n.alternate===null?n.tag=17:(t=We(-1,1),t.tag=2,ut(n,t,1))),n.lanes|=1),e)}var up=Ge.ReactCurrentOwner,fe=!1;function ae(e,t,n,r){t.child=e===null?Du(t,null,n,r):an(t,e.child,n,r)}function Ja(e,t,n,r,l){n=n.render;var o=t.ref;return tn(t,l),r=Oi(e,t,n,r,o,l),n=Ai(),e!==null&&!fe?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~l,Xe(e,t,l)):(F&&n&&Ci(t),t.flags|=1,ae(e,t,r,l),t.child)}function qa(e,t,n,r,l){if(e===null){var o=n.type;return typeof o=="function"&&!Ki(o)&&o.defaultProps===void 0&&n.compare===null&&n.defaultProps===void 0?(t.tag=15,t.type=o,cc(e,t,o,r,l)):(e=Fr(n.type,null,r,t,t.mode,l),e.ref=t.ref,e.return=t,t.child=e)}if(o=e.child,!(e.lanes&l)){var i=o.memoizedProps;if(n=n.compare,n=n!==null?n:Wn,n(i,r)&&e.ref===t.ref)return Xe(e,t,l)}return t.flags|=1,e=ft(o,r),e.ref=t.ref,e.return=t,t.child=e}function cc(e,t,n,r,l){if(e!==null){var o=e.memoizedProps;if(Wn(o,r)&&e.ref===t.ref)if(fe=!1,t.pendingProps=r=o,(e.lanes&l)!==0)e.flags&131072&&(fe=!0);else return t.lanes=e.lanes,Xe(e,t,l)}return Ho(e,t,n,r,l)}function dc(e,t,n){var r=t.pendingProps,l=r.children,o=e!==null?e.memoizedState:null;if(r.mode==="hidden")if(!(t.mode&1))t.memoizedState={baseLanes:0,cachePool:null,transitions:null},O(Gt,ge),ge|=n;else{if(!(n&1073741824))return e=o!==null?o.baseLanes|n:n,t.lanes=t.childLanes=1073741824,t.memoizedState={baseLanes:e,cachePool:null,transitions:null},t.updateQueue=null,O(Gt,ge),ge|=e,null;t.memoizedState={baseLanes:0,cachePool:null,transitions:null},r=o!==null?o.baseLanes:n,O(Gt,ge),ge|=r}else o!==null?(r=o.baseLanes|n,t.memoizedState=null):r=n,O(Gt,ge),ge|=r;return ae(e,t,l,n),t.child}function fc(e,t){var n=t.ref;(e===null&&n!==null||e!==null&&e.ref!==n)&&(t.flags|=512,t.flags|=2097152)}function Ho(e,t,n,r,l){var o=me(n)?zt:ie.current;return o=ln(t,o),tn(t,l),n=Oi(e,t,n,r,o,l),r=Ai(),e!==null&&!fe?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~l,Xe(e,t,l)):(F&&r&&Ci(t),t.flags|=1,ae(e,t,n,l),t.child)}function Za(e,t,n,r,l){if(me(n)){var o=!0;Gr(t)}else o=!1;if(tn(t,l),t.stateNode===null)Or(e,t),ac(t,n,r),$o(t,n,r,l),r=!0;else if(e===null){var i=t.stateNode,a=t.memoizedProps;i.props=a;var s=i.context,u=n.contextType;typeof u=="object"&&u!==null?u=_e(u):(u=me(n)?zt:ie.current,u=ln(t,u));var m=n.getDerivedStateFromProps,f=typeof m=="function"||typeof i.getSnapshotBeforeUpdate=="function";f||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(a!==r||s!==u)&&Ka(t,i,r,u),Ze=!1;var h=t.memoizedState;i.state=h,tl(t,r,i,l),s=t.memoizedState,a!==r||h!==s||pe.current||Ze?(typeof m=="function"&&(Uo(t,n,m,r),s=t.memoizedState),(a=Ze||Qa(t,n,a,r,h,s,u))?(f||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount()),typeof i.componentDidMount=="function"&&(t.flags|=4194308)):(typeof i.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=s),i.props=r,i.state=s,i.context=u,r=a):(typeof i.componentDidMount=="function"&&(t.flags|=4194308),r=!1)}else{i=t.stateNode,Uu(e,t),a=t.memoizedProps,u=t.type===t.elementType?a:Le(t.type,a),i.props=u,f=t.pendingProps,h=i.context,s=n.contextType,typeof s=="object"&&s!==null?s=_e(s):(s=me(n)?zt:ie.current,s=ln(t,s));var g=n.getDerivedStateFromProps;(m=typeof g=="function"||typeof i.getSnapshotBeforeUpdate=="function")||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(a!==f||h!==s)&&Ka(t,i,r,s),Ze=!1,h=t.memoizedState,i.state=h,tl(t,r,i,l);var w=t.memoizedState;a!==f||h!==w||pe.current||Ze?(typeof g=="function"&&(Uo(t,n,g,r),w=t.memoizedState),(u=Ze||Qa(t,n,u,r,h,w,s)||!1)?(m||typeof i.UNSAFE_componentWillUpdate!="function"&&typeof i.componentWillUpdate!="function"||(typeof i.componentWillUpdate=="function"&&i.componentWillUpdate(r,w,s),typeof i.UNSAFE_componentWillUpdate=="function"&&i.UNSAFE_componentWillUpdate(r,w,s)),typeof i.componentDidUpdate=="function"&&(t.flags|=4),typeof i.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof i.componentDidUpdate!="function"||a===e.memoizedProps&&h===e.memoizedState||(t.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||a===e.memoizedProps&&h===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=w),i.props=r,i.state=w,i.context=s,r=u):(typeof i.componentDidUpdate!="function"||a===e.memoizedProps&&h===e.memoizedState||(t.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||a===e.memoizedProps&&h===e.memoizedState||(t.flags|=1024),r=!1)}return Vo(e,t,n,r,o,l)}function Vo(e,t,n,r,l,o){fc(e,t);var i=(t.flags&128)!==0;if(!r&&!i)return l&&Da(t,n,!1),Xe(e,t,o);r=t.stateNode,up.current=t;var a=i&&typeof n.getDerivedStateFromError!="function"?null:r.render();return t.flags|=1,e!==null&&i?(t.child=an(t,e.child,null,o),t.child=an(t,null,a,o)):ae(e,t,a,o),t.memoizedState=r.state,l&&Da(t,n,!0),t.child}function pc(e){var t=e.stateNode;t.pendingContext?Aa(e,t.pendingContext,t.pendingContext!==t.context):t.context&&Aa(e,t.context,!1),Ri(e,t.containerInfo)}function es(e,t,n,r,l){return on(),_i(l),t.flags|=256,ae(e,t,n,r),t.child}var Wo={dehydrated:null,treeContext:null,retryLane:0};function Qo(e){return{baseLanes:e,cachePool:null,transitions:null}}function mc(e,t,n){var r=t.pendingProps,l=U.current,o=!1,i=(t.flags&128)!==0,a;if((a=i)||(a=e!==null&&e.memoizedState===null?!1:(l&2)!==0),a?(o=!0,t.flags&=-129):(e===null||e.memoizedState!==null)&&(l|=1),O(U,l&1),e===null)return Do(t),e=t.memoizedState,e!==null&&(e=e.dehydrated,e!==null)?(t.mode&1?e.data==="$!"?t.lanes=8:t.lanes=1073741824:t.lanes=1,null):(i=r.children,e=r.fallback,o?(r=t.mode,o=t.child,i={mode:"hidden",children:i},!(r&1)&&o!==null?(o.childLanes=0,o.pendingProps=i):o=Sl(i,r,0,null),e=_t(e,r,n,null),o.return=t,e.return=t,o.sibling=e,t.child=o,t.child.memoizedState=Qo(n),t.memoizedState=Wo,e):Ui(t,i));if(l=e.memoizedState,l!==null&&(a=l.dehydrated,a!==null))return cp(e,t,i,r,a,l,n);if(o){o=r.fallback,i=t.mode,l=e.child,a=l.sibling;var s={mode:"hidden",children:r.children};return!(i&1)&&t.child!==l?(r=t.child,r.childLanes=0,r.pendingProps=s,t.deletions=null):(r=ft(l,s),r.subtreeFlags=l.subtreeFlags&14680064),a!==null?o=ft(a,o):(o=_t(o,i,n,null),o.flags|=2),o.return=t,r.return=t,r.sibling=o,t.child=r,r=o,o=t.child,i=e.child.memoizedState,i=i===null?Qo(n):{baseLanes:i.baseLanes|n,cachePool:null,transitions:i.transitions},o.memoizedState=i,o.childLanes=e.childLanes&~n,t.memoizedState=Wo,r}return o=e.child,e=o.sibling,r=ft(o,{mode:"visible",children:r.children}),!(t.mode&1)&&(r.lanes=n),r.return=t,r.sibling=null,e!==null&&(n=t.deletions,n===null?(t.deletions=[e],t.flags|=16):n.push(e)),t.child=r,t.memoizedState=null,r}function Ui(e,t){return t=Sl({mode:"visible",children:t},e.mode,0,null),t.return=e,e.child=t}function Cr(e,t,n,r){return r!==null&&_i(r),an(t,e.child,null,n),e=Ui(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function cp(e,t,n,r,l,o,i){if(n)return t.flags&256?(t.flags&=-257,r=ro(Error(k(422))),Cr(e,t,i,r)):t.memoizedState!==null?(t.child=e.child,t.flags|=128,null):(o=r.fallback,l=t.mode,r=Sl({mode:"visible",children:r.children},l,0,null),o=_t(o,l,i,null),o.flags|=2,r.return=t,o.return=t,r.sibling=o,t.child=r,t.mode&1&&an(t,e.child,null,i),t.child.memoizedState=Qo(i),t.memoizedState=Wo,o);if(!(t.mode&1))return Cr(e,t,i,null);if(l.data==="$!"){if(r=l.nextSibling&&l.nextSibling.dataset,r)var a=r.dgst;return r=a,o=Error(k(419)),r=ro(o,r,void 0),Cr(e,t,i,r)}if(a=(i&e.childLanes)!==0,fe||a){if(r=Z,r!==null){switch(i&-i){case 4:l=2;break;case 16:l=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:l=32;break;case 536870912:l=268435456;break;default:l=0}l=l&(r.suspendedLanes|i)?0:l,l!==0&&l!==o.retryLane&&(o.retryLane=l,Ye(e,l),Ie(r,e,l,-1))}return Qi(),r=ro(Error(k(421))),Cr(e,t,i,r)}return l.data==="$?"?(t.flags|=128,t.child=e.child,t=Ep.bind(null,e),l._reactRetry=t,null):(e=o.treeContext,ve=st(l.nextSibling),ye=t,F=!0,Re=null,e!==null&&(Se[Ee++]=He,Se[Ee++]=Ve,Se[Ee++]=Pt,He=e.id,Ve=e.overflow,Pt=t),t=Ui(t,r.children),t.flags|=4096,t)}function ts(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),Fo(e.return,t,n)}function lo(e,t,n,r,l){var o=e.memoizedState;o===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:l}:(o.isBackwards=t,o.rendering=null,o.renderingStartTime=0,o.last=r,o.tail=n,o.tailMode=l)}function hc(e,t,n){var r=t.pendingProps,l=r.revealOrder,o=r.tail;if(ae(e,t,r.children,n),r=U.current,r&2)r=r&1|2,t.flags|=128;else{if(e!==null&&e.flags&128)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&ts(e,n,t);else if(e.tag===19)ts(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}r&=1}if(O(U,r),!(t.mode&1))t.memoizedState=null;else switch(l){case"forwards":for(n=t.child,l=null;n!==null;)e=n.alternate,e!==null&&nl(e)===null&&(l=n),n=n.sibling;n=l,n===null?(l=t.child,t.child=null):(l=n.sibling,n.sibling=null),lo(t,!1,l,n,o);break;case"backwards":for(n=null,l=t.child,t.child=null;l!==null;){if(e=l.alternate,e!==null&&nl(e)===null){t.child=l;break}e=l.sibling,l.sibling=n,n=l,l=e}lo(t,!0,n,null,o);break;case"together":lo(t,!1,null,null,void 0);break;default:t.memoizedState=null}return t.child}function Or(e,t){!(t.mode&1)&&e!==null&&(e.alternate=null,t.alternate=null,t.flags|=2)}function Xe(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),jt|=t.lanes,!(n&t.childLanes))return null;if(e!==null&&t.child!==e.child)throw Error(k(153));if(t.child!==null){for(e=t.child,n=ft(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=ft(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function dp(e,t,n){switch(t.tag){case 3:pc(t),on();break;case 5:$u(t);break;case 1:me(t.type)&&Gr(t);break;case 4:Ri(t,t.stateNode.containerInfo);break;case 10:var r=t.type._context,l=t.memoizedProps.value;O(Zr,r._currentValue),r._currentValue=l;break;case 13:if(r=t.memoizedState,r!==null)return r.dehydrated!==null?(O(U,U.current&1),t.flags|=128,null):n&t.child.childLanes?mc(e,t,n):(O(U,U.current&1),e=Xe(e,t,n),e!==null?e.sibling:null);O(U,U.current&1);break;case 19:if(r=(n&t.childLanes)!==0,e.flags&128){if(r)return hc(e,t,n);t.flags|=128}if(l=t.memoizedState,l!==null&&(l.rendering=null,l.tail=null,l.lastEffect=null),O(U,U.current),r)break;return null;case 22:case 23:return t.lanes=0,dc(e,t,n)}return Xe(e,t,n)}var gc,Ko,vc,yc;gc=function(e,t){for(var n=t.child;n!==null;){if(n.tag===5||n.tag===6)e.appendChild(n.stateNode);else if(n.tag!==4&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return;n=n.return}n.sibling.return=n.return,n=n.sibling}};Ko=function(){};vc=function(e,t,n,r){var l=e.memoizedProps;if(l!==r){e=t.stateNode,Ct(Ue.current);var o=null;switch(n){case"input":l=ho(e,l),r=ho(e,r),o=[];break;case"select":l=B({},l,{value:void 0}),r=B({},r,{value:void 0}),o=[];break;case"textarea":l=yo(e,l),r=yo(e,r),o=[];break;default:typeof l.onClick!="function"&&typeof r.onClick=="function"&&(e.onclick=Yr)}wo(n,r);var i;n=null;for(u in l)if(!r.hasOwnProperty(u)&&l.hasOwnProperty(u)&&l[u]!=null)if(u==="style"){var a=l[u];for(i in a)a.hasOwnProperty(i)&&(n||(n={}),n[i]="")}else u!=="dangerouslySetInnerHTML"&&u!=="children"&&u!=="suppressContentEditableWarning"&&u!=="suppressHydrationWarning"&&u!=="autoFocus"&&(Dn.hasOwnProperty(u)?o||(o=[]):(o=o||[]).push(u,null));for(u in r){var s=r[u];if(a=l!=null?l[u]:void 0,r.hasOwnProperty(u)&&s!==a&&(s!=null||a!=null))if(u==="style")if(a){for(i in a)!a.hasOwnProperty(i)||s&&s.hasOwnProperty(i)||(n||(n={}),n[i]="");for(i in s)s.hasOwnProperty(i)&&a[i]!==s[i]&&(n||(n={}),n[i]=s[i])}else n||(o||(o=[]),o.push(u,n)),n=s;else u==="dangerouslySetInnerHTML"?(s=s?s.__html:void 0,a=a?a.__html:void 0,s!=null&&a!==s&&(o=o||[]).push(u,s)):u==="children"?typeof s!="string"&&typeof s!="number"||(o=o||[]).push(u,""+s):u!=="suppressContentEditableWarning"&&u!=="suppressHydrationWarning"&&(Dn.hasOwnProperty(u)?(s!=null&&u==="onScroll"&&A("scroll",e),o||a===s||(o=[])):(o=o||[]).push(u,s))}n&&(o=o||[]).push("style",n);var u=o;(t.updateQueue=u)&&(t.flags|=4)}};yc=function(e,t,n,r){n!==r&&(t.flags|=4)};function Sn(e,t){if(!F)switch(e.tailMode){case"hidden":t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case"collapsed":n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null}}function le(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var l=e.child;l!==null;)n|=l.lanes|l.childLanes,r|=l.subtreeFlags&14680064,r|=l.flags&14680064,l.return=e,l=l.sibling;else for(l=e.child;l!==null;)n|=l.lanes|l.childLanes,r|=l.subtreeFlags,r|=l.flags,l.return=e,l=l.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function fp(e,t,n){var r=t.pendingProps;switch(Ni(t),t.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return le(t),null;case 1:return me(t.type)&&Xr(),le(t),null;case 3:return r=t.stateNode,sn(),D(pe),D(ie),Ii(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(e===null||e.child===null)&&(Sr(t)?t.flags|=4:e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,Re!==null&&(ti(Re),Re=null))),Ko(e,t),le(t),null;case 5:bi(t);var l=Ct(Gn.current);if(n=t.type,e!==null&&t.stateNode!=null)vc(e,t,n,r,l),e.ref!==t.ref&&(t.flags|=512,t.flags|=2097152);else{if(!r){if(t.stateNode===null)throw Error(k(166));return le(t),null}if(e=Ct(Ue.current),Sr(t)){r=t.stateNode,n=t.type;var o=t.memoizedProps;switch(r[De]=t,r[Yn]=o,e=(t.mode&1)!==0,n){case"dialog":A("cancel",r),A("close",r);break;case"iframe":case"object":case"embed":A("load",r);break;case"video":case"audio":for(l=0;l<Tn.length;l++)A(Tn[l],r);break;case"source":A("error",r);break;case"img":case"image":case"link":A("error",r),A("load",r);break;case"details":A("toggle",r);break;case"input":ca(r,o),A("invalid",r);break;case"select":r._wrapperState={wasMultiple:!!o.multiple},A("invalid",r);break;case"textarea":fa(r,o),A("invalid",r)}wo(n,o),l=null;for(var i in o)if(o.hasOwnProperty(i)){var a=o[i];i==="children"?typeof a=="string"?r.textContent!==a&&(o.suppressHydrationWarning!==!0&&kr(r.textContent,a,e),l=["children",a]):typeof a=="number"&&r.textContent!==""+a&&(o.suppressHydrationWarning!==!0&&kr(r.textContent,a,e),l=["children",""+a]):Dn.hasOwnProperty(i)&&a!=null&&i==="onScroll"&&A("scroll",r)}switch(n){case"input":pr(r),da(r,o,!0);break;case"textarea":pr(r),pa(r);break;case"select":case"option":break;default:typeof o.onClick=="function"&&(r.onclick=Yr)}r=l,t.updateQueue=r,r!==null&&(t.flags|=4)}else{i=l.nodeType===9?l:l.ownerDocument,e==="http://www.w3.org/1999/xhtml"&&(e=Qs(n)),e==="http://www.w3.org/1999/xhtml"?n==="script"?(e=i.createElement("div"),e.innerHTML="<script><\/script>",e=e.removeChild(e.firstChild)):typeof r.is=="string"?e=i.createElement(n,{is:r.is}):(e=i.createElement(n),n==="select"&&(i=e,r.multiple?i.multiple=!0:r.size&&(i.size=r.size))):e=i.createElementNS(e,n),e[De]=t,e[Yn]=r,gc(e,t,!1,!1),t.stateNode=e;e:{switch(i=ko(n,r),n){case"dialog":A("cancel",e),A("close",e),l=r;break;case"iframe":case"object":case"embed":A("load",e),l=r;break;case"video":case"audio":for(l=0;l<Tn.length;l++)A(Tn[l],e);l=r;break;case"source":A("error",e),l=r;break;case"img":case"image":case"link":A("error",e),A("load",e),l=r;break;case"details":A("toggle",e),l=r;break;case"input":ca(e,r),l=ho(e,r),A("invalid",e);break;case"option":l=r;break;case"select":e._wrapperState={wasMultiple:!!r.multiple},l=B({},r,{value:void 0}),A("invalid",e);break;case"textarea":fa(e,r),l=yo(e,r),A("invalid",e);break;default:l=r}wo(n,l),a=l;for(o in a)if(a.hasOwnProperty(o)){var s=a[o];o==="style"?Xs(e,s):o==="dangerouslySetInnerHTML"?(s=s?s.__html:void 0,s!=null&&Ks(e,s)):o==="children"?typeof s=="string"?(n!=="textarea"||s!=="")&&Fn(e,s):typeof s=="number"&&Fn(e,""+s):o!=="suppressContentEditableWarning"&&o!=="suppressHydrationWarning"&&o!=="autoFocus"&&(Dn.hasOwnProperty(o)?s!=null&&o==="onScroll"&&A("scroll",e):s!=null&&ci(e,o,s,i))}switch(n){case"input":pr(e),da(e,r,!1);break;case"textarea":pr(e),pa(e);break;case"option":r.value!=null&&e.setAttribute("value",""+pt(r.value));break;case"select":e.multiple=!!r.multiple,o=r.value,o!=null?Jt(e,!!r.multiple,o,!1):r.defaultValue!=null&&Jt(e,!!r.multiple,r.defaultValue,!0);break;default:typeof l.onClick=="function"&&(e.onclick=Yr)}switch(n){case"button":case"input":case"select":case"textarea":r=!!r.autoFocus;break e;case"img":r=!0;break e;default:r=!1}}r&&(t.flags|=4)}t.ref!==null&&(t.flags|=512,t.flags|=2097152)}return le(t),null;case 6:if(e&&t.stateNode!=null)yc(e,t,e.memoizedProps,r);else{if(typeof r!="string"&&t.stateNode===null)throw Error(k(166));if(n=Ct(Gn.current),Ct(Ue.current),Sr(t)){if(r=t.stateNode,n=t.memoizedProps,r[De]=t,(o=r.nodeValue!==n)&&(e=ye,e!==null))switch(e.tag){case 3:kr(r.nodeValue,n,(e.mode&1)!==0);break;case 5:e.memoizedProps.suppressHydrationWarning!==!0&&kr(r.nodeValue,n,(e.mode&1)!==0)}o&&(t.flags|=4)}else r=(n.nodeType===9?n:n.ownerDocument).createTextNode(r),r[De]=t,t.stateNode=r}return le(t),null;case 13:if(D(U),r=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(F&&ve!==null&&t.mode&1&&!(t.flags&128))Ou(),on(),t.flags|=98560,o=!1;else if(o=Sr(t),r!==null&&r.dehydrated!==null){if(e===null){if(!o)throw Error(k(318));if(o=t.memoizedState,o=o!==null?o.dehydrated:null,!o)throw Error(k(317));o[De]=t}else on(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;le(t),o=!1}else Re!==null&&(ti(Re),Re=null),o=!0;if(!o)return t.flags&65536?t:null}return t.flags&128?(t.lanes=n,t):(r=r!==null,r!==(e!==null&&e.memoizedState!==null)&&r&&(t.child.flags|=8192,t.mode&1&&(e===null||U.current&1?X===0&&(X=3):Qi())),t.updateQueue!==null&&(t.flags|=4),le(t),null);case 4:return sn(),Ko(e,t),e===null&&Qn(t.stateNode.containerInfo),le(t),null;case 10:return Pi(t.type._context),le(t),null;case 17:return me(t.type)&&Xr(),le(t),null;case 19:if(D(U),o=t.memoizedState,o===null)return le(t),null;if(r=(t.flags&128)!==0,i=o.rendering,i===null)if(r)Sn(o,!1);else{if(X!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(i=nl(e),i!==null){for(t.flags|=128,Sn(o,!1),r=i.updateQueue,r!==null&&(t.updateQueue=r,t.flags|=4),t.subtreeFlags=0,r=n,n=t.child;n!==null;)o=n,e=r,o.flags&=14680066,i=o.alternate,i===null?(o.childLanes=0,o.lanes=e,o.child=null,o.subtreeFlags=0,o.memoizedProps=null,o.memoizedState=null,o.updateQueue=null,o.dependencies=null,o.stateNode=null):(o.childLanes=i.childLanes,o.lanes=i.lanes,o.child=i.child,o.subtreeFlags=0,o.deletions=null,o.memoizedProps=i.memoizedProps,o.memoizedState=i.memoizedState,o.updateQueue=i.updateQueue,o.type=i.type,e=i.dependencies,o.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext}),n=n.sibling;return O(U,U.current&1|2),t.child}e=e.sibling}o.tail!==null&&Q()>cn&&(t.flags|=128,r=!0,Sn(o,!1),t.lanes=4194304)}else{if(!r)if(e=nl(i),e!==null){if(t.flags|=128,r=!0,n=e.updateQueue,n!==null&&(t.updateQueue=n,t.flags|=4),Sn(o,!0),o.tail===null&&o.tailMode==="hidden"&&!i.alternate&&!F)return le(t),null}else 2*Q()-o.renderingStartTime>cn&&n!==1073741824&&(t.flags|=128,r=!0,Sn(o,!1),t.lanes=4194304);o.isBackwards?(i.sibling=t.child,t.child=i):(n=o.last,n!==null?n.sibling=i:t.child=i,o.last=i)}return o.tail!==null?(t=o.tail,o.rendering=t,o.tail=t.sibling,o.renderingStartTime=Q(),t.sibling=null,n=U.current,O(U,r?n&1|2:n&1),t):(le(t),null);case 22:case 23:return Wi(),r=t.memoizedState!==null,e!==null&&e.memoizedState!==null!==r&&(t.flags|=8192),r&&t.mode&1?ge&1073741824&&(le(t),t.subtreeFlags&6&&(t.flags|=8192)):le(t),null;case 24:return null;case 25:return null}throw Error(k(156,t.tag))}function pp(e,t){switch(Ni(t),t.tag){case 1:return me(t.type)&&Xr(),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return sn(),D(pe),D(ie),Ii(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 5:return bi(t),null;case 13:if(D(U),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(k(340));on()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return D(U),null;case 4:return sn(),null;case 10:return Pi(t.type._context),null;case 22:case 23:return Wi(),null;case 24:return null;default:return null}}var Nr=!1,oe=!1,mp=typeof WeakSet=="function"?WeakSet:Set,N=null;function Xt(e,t){var n=e.ref;if(n!==null)if(typeof n=="function")try{n(null)}catch(r){H(e,t,r)}else n.current=null}function Yo(e,t,n){try{n()}catch(r){H(e,t,r)}}var ns=!1;function hp(e,t){if(jo=Wr,e=Eu(),Ei(e)){if("selectionStart"in e)var n={start:e.selectionStart,end:e.selectionEnd};else e:{n=(n=e.ownerDocument)&&n.defaultView||window;var r=n.getSelection&&n.getSelection();if(r&&r.rangeCount!==0){n=r.anchorNode;var l=r.anchorOffset,o=r.focusNode;r=r.focusOffset;try{n.nodeType,o.nodeType}catch{n=null;break e}var i=0,a=-1,s=-1,u=0,m=0,f=e,h=null;t:for(;;){for(var g;f!==n||l!==0&&f.nodeType!==3||(a=i+l),f!==o||r!==0&&f.nodeType!==3||(s=i+r),f.nodeType===3&&(i+=f.nodeValue.length),(g=f.firstChild)!==null;)h=f,f=g;for(;;){if(f===e)break t;if(h===n&&++u===l&&(a=i),h===o&&++m===r&&(s=i),(g=f.nextSibling)!==null)break;f=h,h=f.parentNode}f=g}n=a===-1||s===-1?null:{start:a,end:s}}else n=null}n=n||{start:0,end:0}}else n=null;for(Ro={focusedElem:e,selectionRange:n},Wr=!1,N=t;N!==null;)if(t=N,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,N=e;else for(;N!==null;){t=N;try{var w=t.alternate;if(t.flags&1024)switch(t.tag){case 0:case 11:case 15:break;case 1:if(w!==null){var v=w.memoizedProps,E=w.memoizedState,d=t.stateNode,c=d.getSnapshotBeforeUpdate(t.elementType===t.type?v:Le(t.type,v),E);d.__reactInternalSnapshotBeforeUpdate=c}break;case 3:var p=t.stateNode.containerInfo;p.nodeType===1?p.textContent="":p.nodeType===9&&p.documentElement&&p.removeChild(p.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(k(163))}}catch(x){H(t,t.return,x)}if(e=t.sibling,e!==null){e.return=t.return,N=e;break}N=t.return}return w=ns,ns=!1,w}function Mn(e,t,n){var r=t.updateQueue;if(r=r!==null?r.lastEffect:null,r!==null){var l=r=r.next;do{if((l.tag&e)===e){var o=l.destroy;l.destroy=void 0,o!==void 0&&Yo(t,n,o)}l=l.next}while(l!==r)}}function wl(e,t){if(t=t.updateQueue,t=t!==null?t.lastEffect:null,t!==null){var n=t=t.next;do{if((n.tag&e)===e){var r=n.create;n.destroy=r()}n=n.next}while(n!==t)}}function Xo(e){var t=e.ref;if(t!==null){var n=e.stateNode;switch(e.tag){case 5:e=n;break;default:e=n}typeof t=="function"?t(e):t.current=e}}function xc(e){var t=e.alternate;t!==null&&(e.alternate=null,xc(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&(delete t[De],delete t[Yn],delete t[Mo],delete t[Jf],delete t[qf])),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function wc(e){return e.tag===5||e.tag===3||e.tag===4}function rs(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||wc(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Go(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.nodeType===8?n.parentNode.insertBefore(e,t):n.insertBefore(e,t):(n.nodeType===8?(t=n.parentNode,t.insertBefore(e,n)):(t=n,t.appendChild(e)),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=Yr));else if(r!==4&&(e=e.child,e!==null))for(Go(e,t,n),e=e.sibling;e!==null;)Go(e,t,n),e=e.sibling}function Jo(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(r!==4&&(e=e.child,e!==null))for(Jo(e,t,n),e=e.sibling;e!==null;)Jo(e,t,n),e=e.sibling}var ee=null,je=!1;function Je(e,t,n){for(n=n.child;n!==null;)kc(e,t,n),n=n.sibling}function kc(e,t,n){if(Fe&&typeof Fe.onCommitFiberUnmount=="function")try{Fe.onCommitFiberUnmount(fl,n)}catch{}switch(n.tag){case 5:oe||Xt(n,t);case 6:var r=ee,l=je;ee=null,Je(e,t,n),ee=r,je=l,ee!==null&&(je?(e=ee,n=n.stateNode,e.nodeType===8?e.parentNode.removeChild(n):e.removeChild(n)):ee.removeChild(n.stateNode));break;case 18:ee!==null&&(je?(e=ee,n=n.stateNode,e.nodeType===8?Jl(e.parentNode,n):e.nodeType===1&&Jl(e,n),Hn(e)):Jl(ee,n.stateNode));break;case 4:r=ee,l=je,ee=n.stateNode.containerInfo,je=!0,Je(e,t,n),ee=r,je=l;break;case 0:case 11:case 14:case 15:if(!oe&&(r=n.updateQueue,r!==null&&(r=r.lastEffect,r!==null))){l=r=r.next;do{var o=l,i=o.destroy;o=o.tag,i!==void 0&&(o&2||o&4)&&Yo(n,t,i),l=l.next}while(l!==r)}Je(e,t,n);break;case 1:if(!oe&&(Xt(n,t),r=n.stateNode,typeof r.componentWillUnmount=="function"))try{r.props=n.memoizedProps,r.state=n.memoizedState,r.componentWillUnmount()}catch(a){H(n,t,a)}Je(e,t,n);break;case 21:Je(e,t,n);break;case 22:n.mode&1?(oe=(r=oe)||n.memoizedState!==null,Je(e,t,n),oe=r):Je(e,t,n);break;default:Je(e,t,n)}}function ls(e){var t=e.updateQueue;if(t!==null){e.updateQueue=null;var n=e.stateNode;n===null&&(n=e.stateNode=new mp),t.forEach(function(r){var l=Cp.bind(null,e,r);n.has(r)||(n.add(r),r.then(l,l))})}}function Pe(e,t){var n=t.deletions;if(n!==null)for(var r=0;r<n.length;r++){var l=n[r];try{var o=e,i=t,a=i;e:for(;a!==null;){switch(a.tag){case 5:ee=a.stateNode,je=!1;break e;case 3:ee=a.stateNode.containerInfo,je=!0;break e;case 4:ee=a.stateNode.containerInfo,je=!0;break e}a=a.return}if(ee===null)throw Error(k(160));kc(o,i,l),ee=null,je=!1;var s=l.alternate;s!==null&&(s.return=null),l.return=null}catch(u){H(l,t,u)}}if(t.subtreeFlags&12854)for(t=t.child;t!==null;)Sc(t,e),t=t.sibling}function Sc(e,t){var n=e.alternate,r=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(Pe(t,e),Oe(e),r&4){try{Mn(3,e,e.return),wl(3,e)}catch(v){H(e,e.return,v)}try{Mn(5,e,e.return)}catch(v){H(e,e.return,v)}}break;case 1:Pe(t,e),Oe(e),r&512&&n!==null&&Xt(n,n.return);break;case 5:if(Pe(t,e),Oe(e),r&512&&n!==null&&Xt(n,n.return),e.flags&32){var l=e.stateNode;try{Fn(l,"")}catch(v){H(e,e.return,v)}}if(r&4&&(l=e.stateNode,l!=null)){var o=e.memoizedProps,i=n!==null?n.memoizedProps:o,a=e.type,s=e.updateQueue;if(e.updateQueue=null,s!==null)try{a==="input"&&o.type==="radio"&&o.name!=null&&Vs(l,o),ko(a,i);var u=ko(a,o);for(i=0;i<s.length;i+=2){var m=s[i],f=s[i+1];m==="style"?Xs(l,f):m==="dangerouslySetInnerHTML"?Ks(l,f):m==="children"?Fn(l,f):ci(l,m,f,u)}switch(a){case"input":go(l,o);break;case"textarea":Ws(l,o);break;case"select":var h=l._wrapperState.wasMultiple;l._wrapperState.wasMultiple=!!o.multiple;var g=o.value;g!=null?Jt(l,!!o.multiple,g,!1):h!==!!o.multiple&&(o.defaultValue!=null?Jt(l,!!o.multiple,o.defaultValue,!0):Jt(l,!!o.multiple,o.multiple?[]:"",!1))}l[Yn]=o}catch(v){H(e,e.return,v)}}break;case 6:if(Pe(t,e),Oe(e),r&4){if(e.stateNode===null)throw Error(k(162));l=e.stateNode,o=e.memoizedProps;try{l.nodeValue=o}catch(v){H(e,e.return,v)}}break;case 3:if(Pe(t,e),Oe(e),r&4&&n!==null&&n.memoizedState.isDehydrated)try{Hn(t.containerInfo)}catch(v){H(e,e.return,v)}break;case 4:Pe(t,e),Oe(e);break;case 13:Pe(t,e),Oe(e),l=e.child,l.flags&8192&&(o=l.memoizedState!==null,l.stateNode.isHidden=o,!o||l.alternate!==null&&l.alternate.memoizedState!==null||(Hi=Q())),r&4&&ls(e);break;case 22:if(m=n!==null&&n.memoizedState!==null,e.mode&1?(oe=(u=oe)||m,Pe(t,e),oe=u):Pe(t,e),Oe(e),r&8192){if(u=e.memoizedState!==null,(e.stateNode.isHidden=u)&&!m&&e.mode&1)for(N=e,m=e.child;m!==null;){for(f=N=m;N!==null;){switch(h=N,g=h.child,h.tag){case 0:case 11:case 14:case 15:Mn(4,h,h.return);break;case 1:Xt(h,h.return);var w=h.stateNode;if(typeof w.componentWillUnmount=="function"){r=h,n=h.return;try{t=r,w.props=t.memoizedProps,w.state=t.memoizedState,w.componentWillUnmount()}catch(v){H(r,n,v)}}break;case 5:Xt(h,h.return);break;case 22:if(h.memoizedState!==null){is(f);continue}}g!==null?(g.return=h,N=g):is(f)}m=m.sibling}e:for(m=null,f=e;;){if(f.tag===5){if(m===null){m=f;try{l=f.stateNode,u?(o=l.style,typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none"):(a=f.stateNode,s=f.memoizedProps.style,i=s!=null&&s.hasOwnProperty("display")?s.display:null,a.style.display=Ys("display",i))}catch(v){H(e,e.return,v)}}}else if(f.tag===6){if(m===null)try{f.stateNode.nodeValue=u?"":f.memoizedProps}catch(v){H(e,e.return,v)}}else if((f.tag!==22&&f.tag!==23||f.memoizedState===null||f===e)&&f.child!==null){f.child.return=f,f=f.child;continue}if(f===e)break e;for(;f.sibling===null;){if(f.return===null||f.return===e)break e;m===f&&(m=null),f=f.return}m===f&&(m=null),f.sibling.return=f.return,f=f.sibling}}break;case 19:Pe(t,e),Oe(e),r&4&&ls(e);break;case 21:break;default:Pe(t,e),Oe(e)}}function Oe(e){var t=e.flags;if(t&2){try{e:{for(var n=e.return;n!==null;){if(wc(n)){var r=n;break e}n=n.return}throw Error(k(160))}switch(r.tag){case 5:var l=r.stateNode;r.flags&32&&(Fn(l,""),r.flags&=-33);var o=rs(e);Jo(e,o,l);break;case 3:case 4:var i=r.stateNode.containerInfo,a=rs(e);Go(e,a,i);break;default:throw Error(k(161))}}catch(s){H(e,e.return,s)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function gp(e,t,n){N=e,Ec(e)}function Ec(e,t,n){for(var r=(e.mode&1)!==0;N!==null;){var l=N,o=l.child;if(l.tag===22&&r){var i=l.memoizedState!==null||Nr;if(!i){var a=l.alternate,s=a!==null&&a.memoizedState!==null||oe;a=Nr;var u=oe;if(Nr=i,(oe=s)&&!u)for(N=l;N!==null;)i=N,s=i.child,i.tag===22&&i.memoizedState!==null?as(l):s!==null?(s.return=i,N=s):as(l);for(;o!==null;)N=o,Ec(o),o=o.sibling;N=l,Nr=a,oe=u}os(e)}else l.subtreeFlags&8772&&o!==null?(o.return=l,N=o):os(e)}}function os(e){for(;N!==null;){var t=N;if(t.flags&8772){var n=t.alternate;try{if(t.flags&8772)switch(t.tag){case 0:case 11:case 15:oe||wl(5,t);break;case 1:var r=t.stateNode;if(t.flags&4&&!oe)if(n===null)r.componentDidMount();else{var l=t.elementType===t.type?n.memoizedProps:Le(t.type,n.memoizedProps);r.componentDidUpdate(l,n.memoizedState,r.__reactInternalSnapshotBeforeUpdate)}var o=t.updateQueue;o!==null&&Ha(t,o,r);break;case 3:var i=t.updateQueue;if(i!==null){if(n=null,t.child!==null)switch(t.child.tag){case 5:n=t.child.stateNode;break;case 1:n=t.child.stateNode}Ha(t,i,n)}break;case 5:var a=t.stateNode;if(n===null&&t.flags&4){n=a;var s=t.memoizedProps;switch(t.type){case"button":case"input":case"select":case"textarea":s.autoFocus&&n.focus();break;case"img":s.src&&(n.src=s.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(t.memoizedState===null){var u=t.alternate;if(u!==null){var m=u.memoizedState;if(m!==null){var f=m.dehydrated;f!==null&&Hn(f)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(k(163))}oe||t.flags&512&&Xo(t)}catch(h){H(t,t.return,h)}}if(t===e){N=null;break}if(n=t.sibling,n!==null){n.return=t.return,N=n;break}N=t.return}}function is(e){for(;N!==null;){var t=N;if(t===e){N=null;break}var n=t.sibling;if(n!==null){n.return=t.return,N=n;break}N=t.return}}function as(e){for(;N!==null;){var t=N;try{switch(t.tag){case 0:case 11:case 15:var n=t.return;try{wl(4,t)}catch(s){H(t,n,s)}break;case 1:var r=t.stateNode;if(typeof r.componentDidMount=="function"){var l=t.return;try{r.componentDidMount()}catch(s){H(t,l,s)}}var o=t.return;try{Xo(t)}catch(s){H(t,o,s)}break;case 5:var i=t.return;try{Xo(t)}catch(s){H(t,i,s)}}}catch(s){H(t,t.return,s)}if(t===e){N=null;break}var a=t.sibling;if(a!==null){a.return=t.return,N=a;break}N=t.return}}var vp=Math.ceil,ol=Ge.ReactCurrentDispatcher,$i=Ge.ReactCurrentOwner,Ne=Ge.ReactCurrentBatchConfig,I=0,Z=null,K=null,te=0,ge=0,Gt=gt(0),X=0,er=null,jt=0,kl=0,Bi=0,On=null,de=null,Hi=0,cn=1/0,$e=null,il=!1,qo=null,ct=null,_r=!1,rt=null,al=0,An=0,Zo=null,Ar=-1,Dr=0;function se(){return I&6?Q():Ar!==-1?Ar:Ar=Q()}function dt(e){return e.mode&1?I&2&&te!==0?te&-te:ep.transition!==null?(Dr===0&&(Dr=au()),Dr):(e=M,e!==0||(e=window.event,e=e===void 0?16:mu(e.type)),e):1}function Ie(e,t,n,r){if(50<An)throw An=0,Zo=null,Error(k(185));lr(e,n,r),(!(I&2)||e!==Z)&&(e===Z&&(!(I&2)&&(kl|=n),X===4&&tt(e,te)),he(e,r),n===1&&I===0&&!(t.mode&1)&&(cn=Q()+500,vl&&vt()))}function he(e,t){var n=e.callbackNode;Zd(e,t);var r=Vr(e,e===Z?te:0);if(r===0)n!==null&&ga(n),e.callbackNode=null,e.callbackPriority=0;else if(t=r&-r,e.callbackPriority!==t){if(n!=null&&ga(n),t===1)e.tag===0?Zf(ss.bind(null,e)):bu(ss.bind(null,e)),Xf(function(){!(I&6)&&vt()}),n=null;else{switch(su(r)){case 1:n=hi;break;case 4:n=ou;break;case 16:n=Hr;break;case 536870912:n=iu;break;default:n=Hr}n=jc(n,Cc.bind(null,e))}e.callbackPriority=t,e.callbackNode=n}}function Cc(e,t){if(Ar=-1,Dr=0,I&6)throw Error(k(327));var n=e.callbackNode;if(nn()&&e.callbackNode!==n)return null;var r=Vr(e,e===Z?te:0);if(r===0)return null;if(r&30||r&e.expiredLanes||t)t=sl(e,r);else{t=r;var l=I;I|=2;var o=_c();(Z!==e||te!==t)&&($e=null,cn=Q()+500,Nt(e,t));do try{wp();break}catch(a){Nc(e,a)}while(!0);zi(),ol.current=o,I=l,K!==null?t=0:(Z=null,te=0,t=X)}if(t!==0){if(t===2&&(l=_o(e),l!==0&&(r=l,t=ei(e,l))),t===1)throw n=er,Nt(e,0),tt(e,r),he(e,Q()),n;if(t===6)tt(e,r);else{if(l=e.current.alternate,!(r&30)&&!yp(l)&&(t=sl(e,r),t===2&&(o=_o(e),o!==0&&(r=o,t=ei(e,o))),t===1))throw n=er,Nt(e,0),tt(e,r),he(e,Q()),n;switch(e.finishedWork=l,e.finishedLanes=r,t){case 0:case 1:throw Error(k(345));case 2:kt(e,de,$e);break;case 3:if(tt(e,r),(r&130023424)===r&&(t=Hi+500-Q(),10<t)){if(Vr(e,0)!==0)break;if(l=e.suspendedLanes,(l&r)!==r){se(),e.pingedLanes|=e.suspendedLanes&l;break}e.timeoutHandle=Io(kt.bind(null,e,de,$e),t);break}kt(e,de,$e);break;case 4:if(tt(e,r),(r&4194240)===r)break;for(t=e.eventTimes,l=-1;0<r;){var i=31-be(r);o=1<<i,i=t[i],i>l&&(l=i),r&=~o}if(r=l,r=Q()-r,r=(120>r?120:480>r?480:1080>r?1080:1920>r?1920:3e3>r?3e3:4320>r?4320:1960*vp(r/1960))-r,10<r){e.timeoutHandle=Io(kt.bind(null,e,de,$e),r);break}kt(e,de,$e);break;case 5:kt(e,de,$e);break;default:throw Error(k(329))}}}return he(e,Q()),e.callbackNode===n?Cc.bind(null,e):null}function ei(e,t){var n=On;return e.current.memoizedState.isDehydrated&&(Nt(e,t).flags|=256),e=sl(e,t),e!==2&&(t=de,de=n,t!==null&&ti(t)),e}function ti(e){de===null?de=e:de.push.apply(de,e)}function yp(e){for(var t=e;;){if(t.flags&16384){var n=t.updateQueue;if(n!==null&&(n=n.stores,n!==null))for(var r=0;r<n.length;r++){var l=n[r],o=l.getSnapshot;l=l.value;try{if(!Me(o(),l))return!1}catch{return!1}}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function tt(e,t){for(t&=~Bi,t&=~kl,e.suspendedLanes|=t,e.pingedLanes&=~t,e=e.expirationTimes;0<t;){var n=31-be(t),r=1<<n;e[n]=-1,t&=~r}}function ss(e){if(I&6)throw Error(k(327));nn();var t=Vr(e,0);if(!(t&1))return he(e,Q()),null;var n=sl(e,t);if(e.tag!==0&&n===2){var r=_o(e);r!==0&&(t=r,n=ei(e,r))}if(n===1)throw n=er,Nt(e,0),tt(e,t),he(e,Q()),n;if(n===6)throw Error(k(345));return e.finishedWork=e.current.alternate,e.finishedLanes=t,kt(e,de,$e),he(e,Q()),null}function Vi(e,t){var n=I;I|=1;try{return e(t)}finally{I=n,I===0&&(cn=Q()+500,vl&&vt())}}function Rt(e){rt!==null&&rt.tag===0&&!(I&6)&&nn();var t=I;I|=1;var n=Ne.transition,r=M;try{if(Ne.transition=null,M=1,e)return e()}finally{M=r,Ne.transition=n,I=t,!(I&6)&&vt()}}function Wi(){ge=Gt.current,D(Gt)}function Nt(e,t){e.finishedWork=null,e.finishedLanes=0;var n=e.timeoutHandle;if(n!==-1&&(e.timeoutHandle=-1,Yf(n)),K!==null)for(n=K.return;n!==null;){var r=n;switch(Ni(r),r.tag){case 1:r=r.type.childContextTypes,r!=null&&Xr();break;case 3:sn(),D(pe),D(ie),Ii();break;case 5:bi(r);break;case 4:sn();break;case 13:D(U);break;case 19:D(U);break;case 10:Pi(r.type._context);break;case 22:case 23:Wi()}n=n.return}if(Z=e,K=e=ft(e.current,null),te=ge=t,X=0,er=null,Bi=kl=jt=0,de=On=null,Et!==null){for(t=0;t<Et.length;t++)if(n=Et[t],r=n.interleaved,r!==null){n.interleaved=null;var l=r.next,o=n.pending;if(o!==null){var i=o.next;o.next=l,r.next=i}n.pending=r}Et=null}return e}function Nc(e,t){do{var n=K;try{if(zi(),Ir.current=ll,rl){for(var r=$.memoizedState;r!==null;){var l=r.queue;l!==null&&(l.pending=null),r=r.next}rl=!1}if(Lt=0,q=Y=$=null,In=!1,Jn=0,$i.current=null,n===null||n.return===null){X=1,er=t,K=null;break}e:{var o=e,i=n.return,a=n,s=t;if(t=te,a.flags|=32768,s!==null&&typeof s=="object"&&typeof s.then=="function"){var u=s,m=a,f=m.tag;if(!(m.mode&1)&&(f===0||f===11||f===15)){var h=m.alternate;h?(m.updateQueue=h.updateQueue,m.memoizedState=h.memoizedState,m.lanes=h.lanes):(m.updateQueue=null,m.memoizedState=null)}var g=Xa(i);if(g!==null){g.flags&=-257,Ga(g,i,a,o,t),g.mode&1&&Ya(o,u,t),t=g,s=u;var w=t.updateQueue;if(w===null){var v=new Set;v.add(s),t.updateQueue=v}else w.add(s);break e}else{if(!(t&1)){Ya(o,u,t),Qi();break e}s=Error(k(426))}}else if(F&&a.mode&1){var E=Xa(i);if(E!==null){!(E.flags&65536)&&(E.flags|=256),Ga(E,i,a,o,t),_i(un(s,a));break e}}o=s=un(s,a),X!==4&&(X=2),On===null?On=[o]:On.push(o),o=i;do{switch(o.tag){case 3:o.flags|=65536,t&=-t,o.lanes|=t;var d=sc(o,s,t);Ba(o,d);break e;case 1:a=s;var c=o.type,p=o.stateNode;if(!(o.flags&128)&&(typeof c.getDerivedStateFromError=="function"||p!==null&&typeof p.componentDidCatch=="function"&&(ct===null||!ct.has(p)))){o.flags|=65536,t&=-t,o.lanes|=t;var x=uc(o,a,t);Ba(o,x);break e}}o=o.return}while(o!==null)}zc(n)}catch(C){t=C,K===n&&n!==null&&(K=n=n.return);continue}break}while(!0)}function _c(){var e=ol.current;return ol.current=ll,e===null?ll:e}function Qi(){(X===0||X===3||X===2)&&(X=4),Z===null||!(jt&268435455)&&!(kl&268435455)||tt(Z,te)}function sl(e,t){var n=I;I|=2;var r=_c();(Z!==e||te!==t)&&($e=null,Nt(e,t));do try{xp();break}catch(l){Nc(e,l)}while(!0);if(zi(),I=n,ol.current=r,K!==null)throw Error(k(261));return Z=null,te=0,X}function xp(){for(;K!==null;)Tc(K)}function wp(){for(;K!==null&&!Vd();)Tc(K)}function Tc(e){var t=Lc(e.alternate,e,ge);e.memoizedProps=e.pendingProps,t===null?zc(e):K=t,$i.current=null}function zc(e){var t=e;do{var n=t.alternate;if(e=t.return,t.flags&32768){if(n=pp(n,t),n!==null){n.flags&=32767,K=n;return}if(e!==null)e.flags|=32768,e.subtreeFlags=0,e.deletions=null;else{X=6,K=null;return}}else if(n=fp(n,t,ge),n!==null){K=n;return}if(t=t.sibling,t!==null){K=t;return}K=t=e}while(t!==null);X===0&&(X=5)}function kt(e,t,n){var r=M,l=Ne.transition;try{Ne.transition=null,M=1,kp(e,t,n,r)}finally{Ne.transition=l,M=r}return null}function kp(e,t,n,r){do nn();while(rt!==null);if(I&6)throw Error(k(327));n=e.finishedWork;var l=e.finishedLanes;if(n===null)return null;if(e.finishedWork=null,e.finishedLanes=0,n===e.current)throw Error(k(177));e.callbackNode=null,e.callbackPriority=0;var o=n.lanes|n.childLanes;if(ef(e,o),e===Z&&(K=Z=null,te=0),!(n.subtreeFlags&2064)&&!(n.flags&2064)||_r||(_r=!0,jc(Hr,function(){return nn(),null})),o=(n.flags&15990)!==0,n.subtreeFlags&15990||o){o=Ne.transition,Ne.transition=null;var i=M;M=1;var a=I;I|=4,$i.current=null,hp(e,n),Sc(n,e),$f(Ro),Wr=!!jo,Ro=jo=null,e.current=n,gp(n),Wd(),I=a,M=i,Ne.transition=o}else e.current=n;if(_r&&(_r=!1,rt=e,al=l),o=e.pendingLanes,o===0&&(ct=null),Yd(n.stateNode),he(e,Q()),t!==null)for(r=e.onRecoverableError,n=0;n<t.length;n++)l=t[n],r(l.value,{componentStack:l.stack,digest:l.digest});if(il)throw il=!1,e=qo,qo=null,e;return al&1&&e.tag!==0&&nn(),o=e.pendingLanes,o&1?e===Zo?An++:(An=0,Zo=e):An=0,vt(),null}function nn(){if(rt!==null){var e=su(al),t=Ne.transition,n=M;try{if(Ne.transition=null,M=16>e?16:e,rt===null)var r=!1;else{if(e=rt,rt=null,al=0,I&6)throw Error(k(331));var l=I;for(I|=4,N=e.current;N!==null;){var o=N,i=o.child;if(N.flags&16){var a=o.deletions;if(a!==null){for(var s=0;s<a.length;s++){var u=a[s];for(N=u;N!==null;){var m=N;switch(m.tag){case 0:case 11:case 15:Mn(8,m,o)}var f=m.child;if(f!==null)f.return=m,N=f;else for(;N!==null;){m=N;var h=m.sibling,g=m.return;if(xc(m),m===u){N=null;break}if(h!==null){h.return=g,N=h;break}N=g}}}var w=o.alternate;if(w!==null){var v=w.child;if(v!==null){w.child=null;do{var E=v.sibling;v.sibling=null,v=E}while(v!==null)}}N=o}}if(o.subtreeFlags&2064&&i!==null)i.return=o,N=i;else e:for(;N!==null;){if(o=N,o.flags&2048)switch(o.tag){case 0:case 11:case 15:Mn(9,o,o.return)}var d=o.sibling;if(d!==null){d.return=o.return,N=d;break e}N=o.return}}var c=e.current;for(N=c;N!==null;){i=N;var p=i.child;if(i.subtreeFlags&2064&&p!==null)p.return=i,N=p;else e:for(i=c;N!==null;){if(a=N,a.flags&2048)try{switch(a.tag){case 0:case 11:case 15:wl(9,a)}}catch(C){H(a,a.return,C)}if(a===i){N=null;break e}var x=a.sibling;if(x!==null){x.return=a.return,N=x;break e}N=a.return}}if(I=l,vt(),Fe&&typeof Fe.onPostCommitFiberRoot=="function")try{Fe.onPostCommitFiberRoot(fl,e)}catch{}r=!0}return r}finally{M=n,Ne.transition=t}}return!1}function us(e,t,n){t=un(n,t),t=sc(e,t,1),e=ut(e,t,1),t=se(),e!==null&&(lr(e,1,t),he(e,t))}function H(e,t,n){if(e.tag===3)us(e,e,n);else for(;t!==null;){if(t.tag===3){us(t,e,n);break}else if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof r.componentDidCatch=="function"&&(ct===null||!ct.has(r))){e=un(n,e),e=uc(t,e,1),t=ut(t,e,1),e=se(),t!==null&&(lr(t,1,e),he(t,e));break}}t=t.return}}function Sp(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),t=se(),e.pingedLanes|=e.suspendedLanes&n,Z===e&&(te&n)===n&&(X===4||X===3&&(te&130023424)===te&&500>Q()-Hi?Nt(e,0):Bi|=n),he(e,t)}function Pc(e,t){t===0&&(e.mode&1?(t=gr,gr<<=1,!(gr&130023424)&&(gr=4194304)):t=1);var n=se();e=Ye(e,t),e!==null&&(lr(e,t,n),he(e,n))}function Ep(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),Pc(e,n)}function Cp(e,t){var n=0;switch(e.tag){case 13:var r=e.stateNode,l=e.memoizedState;l!==null&&(n=l.retryLane);break;case 19:r=e.stateNode;break;default:throw Error(k(314))}r!==null&&r.delete(t),Pc(e,n)}var Lc;Lc=function(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps||pe.current)fe=!0;else{if(!(e.lanes&n)&&!(t.flags&128))return fe=!1,dp(e,t,n);fe=!!(e.flags&131072)}else fe=!1,F&&t.flags&1048576&&Iu(t,qr,t.index);switch(t.lanes=0,t.tag){case 2:var r=t.type;Or(e,t),e=t.pendingProps;var l=ln(t,ie.current);tn(t,n),l=Oi(null,t,r,e,l,n);var o=Ai();return t.flags|=1,typeof l=="object"&&l!==null&&typeof l.render=="function"&&l.$$typeof===void 0?(t.tag=1,t.memoizedState=null,t.updateQueue=null,me(r)?(o=!0,Gr(t)):o=!1,t.memoizedState=l.state!==null&&l.state!==void 0?l.state:null,ji(t),l.updater=xl,t.stateNode=l,l._reactInternals=t,$o(t,r,e,n),t=Vo(null,t,r,!0,o,n)):(t.tag=0,F&&o&&Ci(t),ae(null,t,l,n),t=t.child),t;case 16:r=t.elementType;e:{switch(Or(e,t),e=t.pendingProps,l=r._init,r=l(r._payload),t.type=r,l=t.tag=_p(r),e=Le(r,e),l){case 0:t=Ho(null,t,r,e,n);break e;case 1:t=Za(null,t,r,e,n);break e;case 11:t=Ja(null,t,r,e,n);break e;case 14:t=qa(null,t,r,Le(r.type,e),n);break e}throw Error(k(306,r,""))}return t;case 0:return r=t.type,l=t.pendingProps,l=t.elementType===r?l:Le(r,l),Ho(e,t,r,l,n);case 1:return r=t.type,l=t.pendingProps,l=t.elementType===r?l:Le(r,l),Za(e,t,r,l,n);case 3:e:{if(pc(t),e===null)throw Error(k(387));r=t.pendingProps,o=t.memoizedState,l=o.element,Uu(e,t),tl(t,r,null,n);var i=t.memoizedState;if(r=i.element,o.isDehydrated)if(o={element:r,isDehydrated:!1,cache:i.cache,pendingSuspenseBoundaries:i.pendingSuspenseBoundaries,transitions:i.transitions},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){l=un(Error(k(423)),t),t=es(e,t,r,n,l);break e}else if(r!==l){l=un(Error(k(424)),t),t=es(e,t,r,n,l);break e}else for(ve=st(t.stateNode.containerInfo.firstChild),ye=t,F=!0,Re=null,n=Du(t,null,r,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling;else{if(on(),r===l){t=Xe(e,t,n);break e}ae(e,t,r,n)}t=t.child}return t;case 5:return $u(t),e===null&&Do(t),r=t.type,l=t.pendingProps,o=e!==null?e.memoizedProps:null,i=l.children,bo(r,l)?i=null:o!==null&&bo(r,o)&&(t.flags|=32),fc(e,t),ae(e,t,i,n),t.child;case 6:return e===null&&Do(t),null;case 13:return mc(e,t,n);case 4:return Ri(t,t.stateNode.containerInfo),r=t.pendingProps,e===null?t.child=an(t,null,r,n):ae(e,t,r,n),t.child;case 11:return r=t.type,l=t.pendingProps,l=t.elementType===r?l:Le(r,l),Ja(e,t,r,l,n);case 7:return ae(e,t,t.pendingProps,n),t.child;case 8:return ae(e,t,t.pendingProps.children,n),t.child;case 12:return ae(e,t,t.pendingProps.children,n),t.child;case 10:e:{if(r=t.type._context,l=t.pendingProps,o=t.memoizedProps,i=l.value,O(Zr,r._currentValue),r._currentValue=i,o!==null)if(Me(o.value,i)){if(o.children===l.children&&!pe.current){t=Xe(e,t,n);break e}}else for(o=t.child,o!==null&&(o.return=t);o!==null;){var a=o.dependencies;if(a!==null){i=o.child;for(var s=a.firstContext;s!==null;){if(s.context===r){if(o.tag===1){s=We(-1,n&-n),s.tag=2;var u=o.updateQueue;if(u!==null){u=u.shared;var m=u.pending;m===null?s.next=s:(s.next=m.next,m.next=s),u.pending=s}}o.lanes|=n,s=o.alternate,s!==null&&(s.lanes|=n),Fo(o.return,n,t),a.lanes|=n;break}s=s.next}}else if(o.tag===10)i=o.type===t.type?null:o.child;else if(o.tag===18){if(i=o.return,i===null)throw Error(k(341));i.lanes|=n,a=i.alternate,a!==null&&(a.lanes|=n),Fo(i,n,t),i=o.sibling}else i=o.child;if(i!==null)i.return=o;else for(i=o;i!==null;){if(i===t){i=null;break}if(o=i.sibling,o!==null){o.return=i.return,i=o;break}i=i.return}o=i}ae(e,t,l.children,n),t=t.child}return t;case 9:return l=t.type,r=t.pendingProps.children,tn(t,n),l=_e(l),r=r(l),t.flags|=1,ae(e,t,r,n),t.child;case 14:return r=t.type,l=Le(r,t.pendingProps),l=Le(r.type,l),qa(e,t,r,l,n);case 15:return cc(e,t,t.type,t.pendingProps,n);case 17:return r=t.type,l=t.pendingProps,l=t.elementType===r?l:Le(r,l),Or(e,t),t.tag=1,me(r)?(e=!0,Gr(t)):e=!1,tn(t,n),ac(t,r,l),$o(t,r,l,n),Vo(null,t,r,!0,e,n);case 19:return hc(e,t,n);case 22:return dc(e,t,n)}throw Error(k(156,t.tag))};function jc(e,t){return lu(e,t)}function Np(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Ce(e,t,n,r){return new Np(e,t,n,r)}function Ki(e){return e=e.prototype,!(!e||!e.isReactComponent)}function _p(e){if(typeof e=="function")return Ki(e)?1:0;if(e!=null){if(e=e.$$typeof,e===fi)return 11;if(e===pi)return 14}return 2}function ft(e,t){var n=e.alternate;return n===null?(n=Ce(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&14680064,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n}function Fr(e,t,n,r,l,o){var i=2;if(r=e,typeof e=="function")Ki(e)&&(i=1);else if(typeof e=="string")i=5;else e:switch(e){case Ut:return _t(n.children,l,o,t);case di:i=8,l|=8;break;case co:return e=Ce(12,n,t,l|2),e.elementType=co,e.lanes=o,e;case fo:return e=Ce(13,n,t,l),e.elementType=fo,e.lanes=o,e;case po:return e=Ce(19,n,t,l),e.elementType=po,e.lanes=o,e;case $s:return Sl(n,l,o,t);default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case Fs:i=10;break e;case Us:i=9;break e;case fi:i=11;break e;case pi:i=14;break e;case qe:i=16,r=null;break e}throw Error(k(130,e==null?e:typeof e,""))}return t=Ce(i,n,t,l),t.elementType=e,t.type=r,t.lanes=o,t}function _t(e,t,n,r){return e=Ce(7,e,r,t),e.lanes=n,e}function Sl(e,t,n,r){return e=Ce(22,e,r,t),e.elementType=$s,e.lanes=n,e.stateNode={isHidden:!1},e}function oo(e,t,n){return e=Ce(6,e,null,t),e.lanes=n,e}function io(e,t,n){return t=Ce(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}function Tp(e,t,n,r,l){this.tag=t,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=Ul(0),this.expirationTimes=Ul(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Ul(0),this.identifierPrefix=r,this.onRecoverableError=l,this.mutableSourceEagerHydrationData=null}function Yi(e,t,n,r,l,o,i,a,s){return e=new Tp(e,t,n,a,s),t===1?(t=1,o===!0&&(t|=8)):t=0,o=Ce(3,null,null,t),e.current=o,o.stateNode=e,o.memoizedState={element:r,isDehydrated:n,cache:null,transitions:null,pendingSuspenseBoundaries:null},ji(o),e}function zp(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:Ft,key:r==null?null:""+r,children:e,containerInfo:t,implementation:n}}function Rc(e){if(!e)return mt;e=e._reactInternals;e:{if(It(e)!==e||e.tag!==1)throw Error(k(170));var t=e;do{switch(t.tag){case 3:t=t.stateNode.context;break e;case 1:if(me(t.type)){t=t.stateNode.__reactInternalMemoizedMergedChildContext;break e}}t=t.return}while(t!==null);throw Error(k(171))}if(e.tag===1){var n=e.type;if(me(n))return Ru(e,n,t)}return t}function bc(e,t,n,r,l,o,i,a,s){return e=Yi(n,r,!0,e,l,o,i,a,s),e.context=Rc(null),n=e.current,r=se(),l=dt(n),o=We(r,l),o.callback=t??null,ut(n,o,l),e.current.lanes=l,lr(e,l,r),he(e,r),e}function El(e,t,n,r){var l=t.current,o=se(),i=dt(l);return n=Rc(n),t.context===null?t.context=n:t.pendingContext=n,t=We(o,i),t.payload={element:e},r=r===void 0?null:r,r!==null&&(t.callback=r),e=ut(l,t,i),e!==null&&(Ie(e,l,i,o),br(e,l,i)),i}function ul(e){if(e=e.current,!e.child)return null;switch(e.child.tag){case 5:return e.child.stateNode;default:return e.child.stateNode}}function cs(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function Xi(e,t){cs(e,t),(e=e.alternate)&&cs(e,t)}function Pp(){return null}var Ic=typeof reportError=="function"?reportError:function(e){console.error(e)};function Gi(e){this._internalRoot=e}Cl.prototype.render=Gi.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(k(409));El(e,t,null,null)};Cl.prototype.unmount=Gi.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;Rt(function(){El(null,e,null,null)}),t[Ke]=null}};function Cl(e){this._internalRoot=e}Cl.prototype.unstable_scheduleHydration=function(e){if(e){var t=du();e={blockedOn:null,target:e,priority:t};for(var n=0;n<et.length&&t!==0&&t<et[n].priority;n++);et.splice(n,0,e),n===0&&pu(e)}};function Ji(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function Nl(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11&&(e.nodeType!==8||e.nodeValue!==" react-mount-point-unstable "))}function ds(){}function Lp(e,t,n,r,l){if(l){if(typeof r=="function"){var o=r;r=function(){var u=ul(i);o.call(u)}}var i=bc(t,r,e,0,null,!1,!1,"",ds);return e._reactRootContainer=i,e[Ke]=i.current,Qn(e.nodeType===8?e.parentNode:e),Rt(),i}for(;l=e.lastChild;)e.removeChild(l);if(typeof r=="function"){var a=r;r=function(){var u=ul(s);a.call(u)}}var s=Yi(e,0,!1,null,null,!1,!1,"",ds);return e._reactRootContainer=s,e[Ke]=s.current,Qn(e.nodeType===8?e.parentNode:e),Rt(function(){El(t,s,n,r)}),s}function _l(e,t,n,r,l){var o=n._reactRootContainer;if(o){var i=o;if(typeof l=="function"){var a=l;l=function(){var s=ul(i);a.call(s)}}El(t,i,e,l)}else i=Lp(n,t,e,l,r);return ul(i)}uu=function(e){switch(e.tag){case 3:var t=e.stateNode;if(t.current.memoizedState.isDehydrated){var n=_n(t.pendingLanes);n!==0&&(gi(t,n|1),he(t,Q()),!(I&6)&&(cn=Q()+500,vt()))}break;case 13:Rt(function(){var r=Ye(e,1);if(r!==null){var l=se();Ie(r,e,1,l)}}),Xi(e,1)}};vi=function(e){if(e.tag===13){var t=Ye(e,134217728);if(t!==null){var n=se();Ie(t,e,134217728,n)}Xi(e,134217728)}};cu=function(e){if(e.tag===13){var t=dt(e),n=Ye(e,t);if(n!==null){var r=se();Ie(n,e,t,r)}Xi(e,t)}};du=function(){return M};fu=function(e,t){var n=M;try{return M=e,t()}finally{M=n}};Eo=function(e,t,n){switch(t){case"input":if(go(e,n),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll("input[name="+JSON.stringify(""+t)+'][type="radio"]'),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var l=gl(r);if(!l)throw Error(k(90));Hs(r),go(r,l)}}}break;case"textarea":Ws(e,n);break;case"select":t=n.value,t!=null&&Jt(e,!!n.multiple,t,!1)}};qs=Vi;Zs=Rt;var jp={usingClientEntryPoint:!1,Events:[ir,Vt,gl,Gs,Js,Vi]},En={findFiberByHostInstance:St,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},Rp={bundleType:En.bundleType,version:En.version,rendererPackageName:En.rendererPackageName,rendererConfig:En.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:Ge.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return e=nu(e),e===null?null:e.stateNode},findFiberByHostInstance:En.findFiberByHostInstance||Pp,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Tr=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Tr.isDisabled&&Tr.supportsFiber)try{fl=Tr.inject(Rp),Fe=Tr}catch{}}we.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=jp;we.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!Ji(t))throw Error(k(200));return zp(e,t,null,n)};we.createRoot=function(e,t){if(!Ji(e))throw Error(k(299));var n=!1,r="",l=Ic;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(r=t.identifierPrefix),t.onRecoverableError!==void 0&&(l=t.onRecoverableError)),t=Yi(e,1,!1,null,null,n,!1,r,l),e[Ke]=t.current,Qn(e.nodeType===8?e.parentNode:e),new Gi(t)};we.findDOMNode=function(e){if(e==null)return null;if(e.nodeType===1)return e;var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(k(188)):(e=Object.keys(e).join(","),Error(k(268,e)));return e=nu(t),e=e===null?null:e.stateNode,e};we.flushSync=function(e){return Rt(e)};we.hydrate=function(e,t,n){if(!Nl(t))throw Error(k(200));return _l(null,e,t,!0,n)};we.hydrateRoot=function(e,t,n){if(!Ji(e))throw Error(k(405));var r=n!=null&&n.hydratedSources||null,l=!1,o="",i=Ic;if(n!=null&&(n.unstable_strictMode===!0&&(l=!0),n.identifierPrefix!==void 0&&(o=n.identifierPrefix),n.onRecoverableError!==void 0&&(i=n.onRecoverableError)),t=bc(t,null,e,1,n??null,l,!1,o,i),e[Ke]=t.current,Qn(e),r)for(e=0;e<r.length;e++)n=r[e],l=n._getVersion,l=l(n._source),t.mutableSourceEagerHydrationData==null?t.mutableSourceEagerHydrationData=[n,l]:t.mutableSourceEagerHydrationData.push(n,l);return new Cl(t)};we.render=function(e,t,n){if(!Nl(t))throw Error(k(200));return _l(null,e,t,!1,n)};we.unmountComponentAtNode=function(e){if(!Nl(e))throw Error(k(40));return e._reactRootContainer?(Rt(function(){_l(null,null,e,!1,function(){e._reactRootContainer=null,e[Ke]=null})}),!0):!1};we.unstable_batchedUpdates=Vi;we.unstable_renderSubtreeIntoContainer=function(e,t,n,r){if(!Nl(n))throw Error(k(200));if(e==null||e._reactInternals===void 0)throw Error(k(38));return _l(e,t,n,!1,r)};we.version="18.3.1-next-f1338f8080-20240426";function Mc(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Mc)}catch(e){console.error(e)}}Mc(),Ms.exports=we;var bp=Ms.exports,fs=bp;so.createRoot=fs.createRoot,so.hydrateRoot=fs.hydrateRoot;/**
 * @remix-run/router v1.23.2
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */function tr(){return tr=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},tr.apply(this,arguments)}var lt;(function(e){e.Pop="POP",e.Push="PUSH",e.Replace="REPLACE"})(lt||(lt={}));const ps="popstate";function Ip(e){e===void 0&&(e={});function t(l,o){let{pathname:i="/",search:a="",hash:s=""}=Mt(l.location.hash.substr(1));return!i.startsWith("/")&&!i.startsWith(".")&&(i="/"+i),ni("",{pathname:i,search:a,hash:s},o.state&&o.state.usr||null,o.state&&o.state.key||"default")}function n(l,o){let i=l.document.querySelector("base"),a="";if(i&&i.getAttribute("href")){let s=l.location.href,u=s.indexOf("#");a=u===-1?s:s.slice(0,u)}return a+"#"+(typeof o=="string"?o:Oc(o))}function r(l,o){Tl(l.pathname.charAt(0)==="/","relative pathnames are not supported in hash history.push("+JSON.stringify(o)+")")}return Op(t,n,r,e)}function G(e,t){if(e===!1||e===null||typeof e>"u")throw new Error(t)}function Tl(e,t){if(!e){typeof console<"u"&&console.warn(t);try{throw new Error(t)}catch{}}}function Mp(){return Math.random().toString(36).substr(2,8)}function ms(e,t){return{usr:e.state,key:e.key,idx:t}}function ni(e,t,n,r){return n===void 0&&(n=null),tr({pathname:typeof e=="string"?e:e.pathname,search:"",hash:""},typeof t=="string"?Mt(t):t,{state:n,key:t&&t.key||r||Mp()})}function Oc(e){let{pathname:t="/",search:n="",hash:r=""}=e;return n&&n!=="?"&&(t+=n.charAt(0)==="?"?n:"?"+n),r&&r!=="#"&&(t+=r.charAt(0)==="#"?r:"#"+r),t}function Mt(e){let t={};if(e){let n=e.indexOf("#");n>=0&&(t.hash=e.substr(n),e=e.substr(0,n));let r=e.indexOf("?");r>=0&&(t.search=e.substr(r),e=e.substr(0,r)),e&&(t.pathname=e)}return t}function Op(e,t,n,r){r===void 0&&(r={});let{window:l=document.defaultView,v5Compat:o=!1}=r,i=l.history,a=lt.Pop,s=null,u=m();u==null&&(u=0,i.replaceState(tr({},i.state,{idx:u}),""));function m(){return(i.state||{idx:null}).idx}function f(){a=lt.Pop;let E=m(),d=E==null?null:E-u;u=E,s&&s({action:a,location:v.location,delta:d})}function h(E,d){a=lt.Push;let c=ni(v.location,E,d);n&&n(c,E),u=m()+1;let p=ms(c,u),x=v.createHref(c);try{i.pushState(p,"",x)}catch(C){if(C instanceof DOMException&&C.name==="DataCloneError")throw C;l.location.assign(x)}o&&s&&s({action:a,location:v.location,delta:1})}function g(E,d){a=lt.Replace;let c=ni(v.location,E,d);n&&n(c,E),u=m();let p=ms(c,u),x=v.createHref(c);i.replaceState(p,"",x),o&&s&&s({action:a,location:v.location,delta:0})}function w(E){let d=l.location.origin!=="null"?l.location.origin:l.location.href,c=typeof E=="string"?E:Oc(E);return c=c.replace(/ $/,"%20"),G(d,"No window.location.(origin|href) available to create URL for href: "+c),new URL(c,d)}let v={get action(){return a},get location(){return e(l,i)},listen(E){if(s)throw new Error("A history only accepts one active listener");return l.addEventListener(ps,f),s=E,()=>{l.removeEventListener(ps,f),s=null}},createHref(E){return t(l,E)},createURL:w,encodeLocation(E){let d=w(E);return{pathname:d.pathname,search:d.search,hash:d.hash}},push:h,replace:g,go(E){return i.go(E)}};return v}var hs;(function(e){e.data="data",e.deferred="deferred",e.redirect="redirect",e.error="error"})(hs||(hs={}));function Ap(e,t,n){return n===void 0&&(n="/"),Dp(e,t,n)}function Dp(e,t,n,r){let l=typeof t=="string"?Mt(t):t,o=Fc(l.pathname||"/",n);if(o==null)return null;let i=Ac(e);Fp(i);let a=null;for(let s=0;a==null&&s<i.length;++s){let u=Jp(o);a=Yp(i[s],u)}return a}function Ac(e,t,n,r){t===void 0&&(t=[]),n===void 0&&(n=[]),r===void 0&&(r="");let l=(o,i,a)=>{let s={relativePath:a===void 0?o.path||"":a,caseSensitive:o.caseSensitive===!0,childrenIndex:i,route:o};s.relativePath.startsWith("/")&&(G(s.relativePath.startsWith(r),'Absolute route path "'+s.relativePath+'" nested under path '+('"'+r+'" is not valid. An absolute child route path ')+"must start with the combined path of all its parent routes."),s.relativePath=s.relativePath.slice(r.length));let u=Tt([r,s.relativePath]),m=n.concat(s);o.children&&o.children.length>0&&(G(o.index!==!0,"Index routes must not have child routes. Please remove "+('all child routes from route path "'+u+'".')),Ac(o.children,t,m,u)),!(o.path==null&&!o.index)&&t.push({path:u,score:Qp(u,o.index),routesMeta:m})};return e.forEach((o,i)=>{var a;if(o.path===""||!((a=o.path)!=null&&a.includes("?")))l(o,i);else for(let s of Dc(o.path))l(o,i,s)}),t}function Dc(e){let t=e.split("/");if(t.length===0)return[];let[n,...r]=t,l=n.endsWith("?"),o=n.replace(/\?$/,"");if(r.length===0)return l?[o,""]:[o];let i=Dc(r.join("/")),a=[];return a.push(...i.map(s=>s===""?o:[o,s].join("/"))),l&&a.push(...i),a.map(s=>e.startsWith("/")&&s===""?"/":s)}function Fp(e){e.sort((t,n)=>t.score!==n.score?n.score-t.score:Kp(t.routesMeta.map(r=>r.childrenIndex),n.routesMeta.map(r=>r.childrenIndex)))}const Up=/^:[\w-]+$/,$p=3,Bp=2,Hp=1,Vp=10,Wp=-2,gs=e=>e==="*";function Qp(e,t){let n=e.split("/"),r=n.length;return n.some(gs)&&(r+=Wp),t&&(r+=Bp),n.filter(l=>!gs(l)).reduce((l,o)=>l+(Up.test(o)?$p:o===""?Hp:Vp),r)}function Kp(e,t){return e.length===t.length&&e.slice(0,-1).every((r,l)=>r===t[l])?e[e.length-1]-t[t.length-1]:0}function Yp(e,t,n){let{routesMeta:r}=e,l={},o="/",i=[];for(let a=0;a<r.length;++a){let s=r[a],u=a===r.length-1,m=o==="/"?t:t.slice(o.length)||"/",f=Xp({path:s.relativePath,caseSensitive:s.caseSensitive,end:u},m),h=s.route;if(!f)return null;Object.assign(l,f.params),i.push({params:l,pathname:Tt([o,f.pathname]),pathnameBase:lm(Tt([o,f.pathnameBase])),route:h}),f.pathnameBase!=="/"&&(o=Tt([o,f.pathnameBase]))}return i}function Xp(e,t){typeof e=="string"&&(e={path:e,caseSensitive:!1,end:!0});let[n,r]=Gp(e.path,e.caseSensitive,e.end),l=t.match(n);if(!l)return null;let o=l[0],i=o.replace(/(.)\/+$/,"$1"),a=l.slice(1);return{params:r.reduce((u,m,f)=>{let{paramName:h,isOptional:g}=m;if(h==="*"){let v=a[f]||"";i=o.slice(0,o.length-v.length).replace(/(.)\/+$/,"$1")}const w=a[f];return g&&!w?u[h]=void 0:u[h]=(w||"").replace(/%2F/g,"/"),u},{}),pathname:o,pathnameBase:i,pattern:e}}function Gp(e,t,n){t===void 0&&(t=!1),n===void 0&&(n=!0),Tl(e==="*"||!e.endsWith("*")||e.endsWith("/*"),'Route path "'+e+'" will be treated as if it were '+('"'+e.replace(/\*$/,"/*")+'" because the `*` character must ')+"always follow a `/` in the pattern. To get rid of this warning, "+('please change the route path to "'+e.replace(/\*$/,"/*")+'".'));let r=[],l="^"+e.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(i,a,s)=>(r.push({paramName:a,isOptional:s!=null}),s?"/?([^\\/]+)?":"/([^\\/]+)"));return e.endsWith("*")?(r.push({paramName:"*"}),l+=e==="*"||e==="/*"?"(.*)$":"(?:\\/(.+)|\\/*)$"):n?l+="\\/*$":e!==""&&e!=="/"&&(l+="(?:(?=\\/|$))"),[new RegExp(l,t?void 0:"i"),r]}function Jp(e){try{return e.split("/").map(t=>decodeURIComponent(t).replace(/\//g,"%2F")).join("/")}catch(t){return Tl(!1,'The URL path "'+e+'" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent '+("encoding ("+t+").")),e}}function Fc(e,t){if(t==="/")return e;if(!e.toLowerCase().startsWith(t.toLowerCase()))return null;let n=t.endsWith("/")?t.length-1:t.length,r=e.charAt(n);return r&&r!=="/"?null:e.slice(n)||"/"}const qp=/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,Zp=e=>qp.test(e);function em(e,t){t===void 0&&(t="/");let{pathname:n,search:r="",hash:l=""}=typeof e=="string"?Mt(e):e,o;if(n)if(Zp(n))o=n;else{if(n.includes("//")){let i=n;n=n.replace(/\/\/+/g,"/"),Tl(!1,"Pathnames cannot have embedded double slashes - normalizing "+(i+" -> "+n))}n.startsWith("/")?o=vs(n.substring(1),"/"):o=vs(n,t)}else o=t;return{pathname:o,search:om(r),hash:im(l)}}function vs(e,t){let n=t.replace(/\/+$/,"").split("/");return e.split("/").forEach(l=>{l===".."?n.length>1&&n.pop():l!=="."&&n.push(l)}),n.length>1?n.join("/"):"/"}function ao(e,t,n,r){return"Cannot include a '"+e+"' character in a manually specified "+("`to."+t+"` field ["+JSON.stringify(r)+"].  Please separate it out to the ")+("`to."+n+"` field. Alternatively you may provide the full path as ")+'a string in <Link to="..."> and the router will parse it for you.'}function tm(e){return e.filter((t,n)=>n===0||t.route.path&&t.route.path.length>0)}function nm(e,t){let n=tm(e);return t?n.map((r,l)=>l===n.length-1?r.pathname:r.pathnameBase):n.map(r=>r.pathnameBase)}function rm(e,t,n,r){r===void 0&&(r=!1);let l;typeof e=="string"?l=Mt(e):(l=tr({},e),G(!l.pathname||!l.pathname.includes("?"),ao("?","pathname","search",l)),G(!l.pathname||!l.pathname.includes("#"),ao("#","pathname","hash",l)),G(!l.search||!l.search.includes("#"),ao("#","search","hash",l)));let o=e===""||l.pathname==="",i=o?"/":l.pathname,a;if(i==null)a=n;else{let f=t.length-1;if(!r&&i.startsWith("..")){let h=i.split("/");for(;h[0]==="..";)h.shift(),f-=1;l.pathname=h.join("/")}a=f>=0?t[f]:"/"}let s=em(l,a),u=i&&i!=="/"&&i.endsWith("/"),m=(o||i===".")&&n.endsWith("/");return!s.pathname.endsWith("/")&&(u||m)&&(s.pathname+="/"),s}const Tt=e=>e.join("/").replace(/\/\/+/g,"/"),lm=e=>e.replace(/\/+$/,"").replace(/^\/*/,"/"),om=e=>!e||e==="?"?"":e.startsWith("?")?e:"?"+e,im=e=>!e||e==="#"?"":e.startsWith("#")?e:"#"+e;function am(e){return e!=null&&typeof e.status=="number"&&typeof e.statusText=="string"&&typeof e.internal=="boolean"&&"data"in e}const Uc=["post","put","patch","delete"];new Set(Uc);const sm=["get",...Uc];new Set(sm);/**
 * React Router v6.30.3
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */function nr(){return nr=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},nr.apply(this,arguments)}const qi=S.createContext(null),um=S.createContext(null),zl=S.createContext(null),Pl=S.createContext(null),Ot=S.createContext({outlet:null,matches:[],isDataRoute:!1}),$c=S.createContext(null);function Ll(){return S.useContext(Pl)!=null}function Bc(){return Ll()||G(!1),S.useContext(Pl).location}function Hc(e){S.useContext(zl).static||S.useLayoutEffect(e)}function jl(){let{isDataRoute:e}=S.useContext(Ot);return e?Em():cm()}function cm(){Ll()||G(!1);let e=S.useContext(qi),{basename:t,future:n,navigator:r}=S.useContext(zl),{matches:l}=S.useContext(Ot),{pathname:o}=Bc(),i=JSON.stringify(nm(l,n.v7_relativeSplatPath)),a=S.useRef(!1);return Hc(()=>{a.current=!0}),S.useCallback(function(u,m){if(m===void 0&&(m={}),!a.current)return;if(typeof u=="number"){r.go(u);return}let f=rm(u,JSON.parse(i),o,m.relative==="path");e==null&&t!=="/"&&(f.pathname=f.pathname==="/"?t:Tt([t,f.pathname])),(m.replace?r.replace:r.push)(f,m.state,m)},[t,r,i,o,e])}function dm(){let{matches:e}=S.useContext(Ot),t=e[e.length-1];return t?t.params:{}}function fm(e,t){return pm(e,t)}function pm(e,t,n,r){Ll()||G(!1);let{navigator:l}=S.useContext(zl),{matches:o}=S.useContext(Ot),i=o[o.length-1],a=i?i.params:{};i&&i.pathname;let s=i?i.pathnameBase:"/";i&&i.route;let u=Bc(),m;if(t){var f;let E=typeof t=="string"?Mt(t):t;s==="/"||(f=E.pathname)!=null&&f.startsWith(s)||G(!1),m=E}else m=u;let h=m.pathname||"/",g=h;if(s!=="/"){let E=s.replace(/^\//,"").split("/");g="/"+h.replace(/^\//,"").split("/").slice(E.length).join("/")}let w=Ap(e,{pathname:g}),v=ym(w&&w.map(E=>Object.assign({},E,{params:Object.assign({},a,E.params),pathname:Tt([s,l.encodeLocation?l.encodeLocation(E.pathname).pathname:E.pathname]),pathnameBase:E.pathnameBase==="/"?s:Tt([s,l.encodeLocation?l.encodeLocation(E.pathnameBase).pathname:E.pathnameBase])})),o,n,r);return t&&v?S.createElement(Pl.Provider,{value:{location:nr({pathname:"/",search:"",hash:"",state:null,key:"default"},m),navigationType:lt.Pop}},v):v}function mm(){let e=Sm(),t=am(e)?e.status+" "+e.statusText:e instanceof Error?e.message:JSON.stringify(e),n=e instanceof Error?e.stack:null,l={padding:"0.5rem",backgroundColor:"rgba(200,200,200, 0.5)"};return S.createElement(S.Fragment,null,S.createElement("h2",null,"Unexpected Application Error!"),S.createElement("h3",{style:{fontStyle:"italic"}},t),n?S.createElement("pre",{style:l},n):null,null)}const hm=S.createElement(mm,null);class gm extends S.Component{constructor(t){super(t),this.state={location:t.location,revalidation:t.revalidation,error:t.error}}static getDerivedStateFromError(t){return{error:t}}static getDerivedStateFromProps(t,n){return n.location!==t.location||n.revalidation!=="idle"&&t.revalidation==="idle"?{error:t.error,location:t.location,revalidation:t.revalidation}:{error:t.error!==void 0?t.error:n.error,location:n.location,revalidation:t.revalidation||n.revalidation}}componentDidCatch(t,n){console.error("React Router caught the following error during render",t,n)}render(){return this.state.error!==void 0?S.createElement(Ot.Provider,{value:this.props.routeContext},S.createElement($c.Provider,{value:this.state.error,children:this.props.component})):this.props.children}}function vm(e){let{routeContext:t,match:n,children:r}=e,l=S.useContext(qi);return l&&l.static&&l.staticContext&&(n.route.errorElement||n.route.ErrorBoundary)&&(l.staticContext._deepestRenderedBoundaryId=n.route.id),S.createElement(Ot.Provider,{value:t},r)}function ym(e,t,n,r){var l;if(t===void 0&&(t=[]),n===void 0&&(n=null),r===void 0&&(r=null),e==null){var o;if(!n)return null;if(n.errors)e=n.matches;else if((o=r)!=null&&o.v7_partialHydration&&t.length===0&&!n.initialized&&n.matches.length>0)e=n.matches;else return null}let i=e,a=(l=n)==null?void 0:l.errors;if(a!=null){let m=i.findIndex(f=>f.route.id&&(a==null?void 0:a[f.route.id])!==void 0);m>=0||G(!1),i=i.slice(0,Math.min(i.length,m+1))}let s=!1,u=-1;if(n&&r&&r.v7_partialHydration)for(let m=0;m<i.length;m++){let f=i[m];if((f.route.HydrateFallback||f.route.hydrateFallbackElement)&&(u=m),f.route.id){let{loaderData:h,errors:g}=n,w=f.route.loader&&h[f.route.id]===void 0&&(!g||g[f.route.id]===void 0);if(f.route.lazy||w){s=!0,u>=0?i=i.slice(0,u+1):i=[i[0]];break}}}return i.reduceRight((m,f,h)=>{let g,w=!1,v=null,E=null;n&&(g=a&&f.route.id?a[f.route.id]:void 0,v=f.route.errorElement||hm,s&&(u<0&&h===0?(Cm("route-fallback"),w=!0,E=null):u===h&&(w=!0,E=f.route.hydrateFallbackElement||null)));let d=t.concat(i.slice(0,h+1)),c=()=>{let p;return g?p=v:w?p=E:f.route.Component?p=S.createElement(f.route.Component,null):f.route.element?p=f.route.element:p=m,S.createElement(vm,{match:f,routeContext:{outlet:m,matches:d,isDataRoute:n!=null},children:p})};return n&&(f.route.ErrorBoundary||f.route.errorElement||h===0)?S.createElement(gm,{location:n.location,revalidation:n.revalidation,component:v,error:g,children:c(),routeContext:{outlet:null,matches:d,isDataRoute:!0}}):c()},null)}var Vc=function(e){return e.UseBlocker="useBlocker",e.UseRevalidator="useRevalidator",e.UseNavigateStable="useNavigate",e}(Vc||{}),Wc=function(e){return e.UseBlocker="useBlocker",e.UseLoaderData="useLoaderData",e.UseActionData="useActionData",e.UseRouteError="useRouteError",e.UseNavigation="useNavigation",e.UseRouteLoaderData="useRouteLoaderData",e.UseMatches="useMatches",e.UseRevalidator="useRevalidator",e.UseNavigateStable="useNavigate",e.UseRouteId="useRouteId",e}(Wc||{});function xm(e){let t=S.useContext(qi);return t||G(!1),t}function wm(e){let t=S.useContext(um);return t||G(!1),t}function km(e){let t=S.useContext(Ot);return t||G(!1),t}function Qc(e){let t=km(),n=t.matches[t.matches.length-1];return n.route.id||G(!1),n.route.id}function Sm(){var e;let t=S.useContext($c),n=wm(),r=Qc();return t!==void 0?t:(e=n.errors)==null?void 0:e[r]}function Em(){let{router:e}=xm(Vc.UseNavigateStable),t=Qc(Wc.UseNavigateStable),n=S.useRef(!1);return Hc(()=>{n.current=!0}),S.useCallback(function(l,o){o===void 0&&(o={}),n.current&&(typeof l=="number"?e.navigate(l):e.navigate(l,nr({fromRouteId:t},o)))},[e,t])}const ys={};function Cm(e,t,n){ys[e]||(ys[e]=!0)}function Nm(e,t){e==null||e.v7_startTransition,e==null||e.v7_relativeSplatPath}function zn(e){G(!1)}function _m(e){let{basename:t="/",children:n=null,location:r,navigationType:l=lt.Pop,navigator:o,static:i=!1,future:a}=e;Ll()&&G(!1);let s=t.replace(/^\/*/,"/"),u=S.useMemo(()=>({basename:s,navigator:o,static:i,future:nr({v7_relativeSplatPath:!1},a)}),[s,a,o,i]);typeof r=="string"&&(r=Mt(r));let{pathname:m="/",search:f="",hash:h="",state:g=null,key:w="default"}=r,v=S.useMemo(()=>{let E=Fc(m,s);return E==null?null:{location:{pathname:E,search:f,hash:h,state:g,key:w},navigationType:l}},[s,m,f,h,g,w,l]);return v==null?null:S.createElement(zl.Provider,{value:u},S.createElement(Pl.Provider,{children:n,value:v}))}function Tm(e){let{children:t,location:n}=e;return fm(ri(t),n)}new Promise(()=>{});function ri(e,t){t===void 0&&(t=[]);let n=[];return S.Children.forEach(e,(r,l)=>{if(!S.isValidElement(r))return;let o=[...t,l];if(r.type===S.Fragment){n.push.apply(n,ri(r.props.children,o));return}r.type!==zn&&G(!1),!r.props.index||!r.props.children||G(!1);let i={id:r.props.id||o.join("-"),caseSensitive:r.props.caseSensitive,element:r.props.element,Component:r.props.Component,index:r.props.index,path:r.props.path,loader:r.props.loader,action:r.props.action,errorElement:r.props.errorElement,ErrorBoundary:r.props.ErrorBoundary,hasErrorBoundary:r.props.ErrorBoundary!=null||r.props.errorElement!=null,shouldRevalidate:r.props.shouldRevalidate,handle:r.props.handle,lazy:r.props.lazy};r.props.children&&(i.children=ri(r.props.children,o)),n.push(i)}),n}/**
 * React Router DOM v6.30.3
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */const zm="6";try{window.__reactRouterVersion=zm}catch{}const Pm="startTransition",xs=kd[Pm];function Lm(e){let{basename:t,children:n,future:r,window:l}=e,o=S.useRef();o.current==null&&(o.current=Ip({window:l,v5Compat:!0}));let i=o.current,[a,s]=S.useState({action:i.action,location:i.location}),{v7_startTransition:u}=r||{},m=S.useCallback(f=>{u&&xs?xs(()=>s(f)):s(f)},[s,u]);return S.useLayoutEffect(()=>i.listen(m),[i,m]),S.useEffect(()=>Nm(r),[r]),S.createElement(_m,{basename:t,children:n,location:a.location,navigationType:a.action,navigator:i,future:r})}var ws;(function(e){e.UseScrollRestoration="useScrollRestoration",e.UseSubmit="useSubmit",e.UseSubmitFetcher="useSubmitFetcher",e.UseFetcher="useFetcher",e.useViewTransitionState="useViewTransitionState"})(ws||(ws={}));var ks;(function(e){e.UseFetcher="useFetcher",e.UseFetchers="useFetchers",e.UseScrollRestoration="useScrollRestoration"})(ks||(ks={}));function Zi(e){const t=new Date().toISOString();return{id:e.id||jm(),title:e.title||"",subtitle:e.subtitle||"",tag:e.tag||"",source:e.source||"",textContent:e.textContent||"",diagramContent:e.diagramContent||"",userNotes:e.userNotes||"",createdAt:e.createdAt||t,updatedAt:e.updatedAt||t}}function jm(){return`note_${Date.now()}_${Math.random().toString(36).substring(2,9)}`}function Ss(e){return{id:e.id,title:e.title,tag:e.tag,createdAt:e.createdAt,updatedAt:e.updatedAt}}const ea="ai_note_",Kc="ai_note_index";function Yc(e){try{const t=localStorage.getItem(e);return t?JSON.parse(t):null}catch{return null}}function Xc(e,t){localStorage.setItem(e,JSON.stringify(t))}function Rm(e){localStorage.removeItem(e)}function sr(){return Yc(Kc)||[]}function Gc(e){Xc(Kc,e)}function Jc(e){return Yc(ea+e)}function bm(e){Xc(ea+e.id,e);const t=sr(),n=t.findIndex(r=>r.id===e.id);n>=0?t[n]=Ss(e):t.push(Ss(e)),t.sort((r,l)=>new Date(l.updatedAt).getTime()-new Date(r.updatedAt).getTime()),Gc(t)}function qc(e){Rm(ea+e);const t=sr().filter(n=>n.id!==e);Gc(t)}function Im(){return sr().map(t=>Jc(t.id)).filter(t=>t!==null)}function ta(){return{url:localStorage.getItem("ai_note_api_url")||"https://api.deepseek.com",key:localStorage.getItem("ai_note_api_key")||"",model:localStorage.getItem("ai_note_api_model")||"deepseek-chat"}}function Mm(e){e.url!==void 0&&localStorage.setItem("ai_note_api_url",e.url),e.key!==void 0&&localStorage.setItem("ai_note_api_key",e.key),e.model!==void 0&&localStorage.setItem("ai_note_api_model",e.model)}function na(){const{key:e}=ta();return!!e}function Zc(){return localStorage.getItem("ai_note_proxy_url")||"http://127.0.0.1:8765"}function Om(e){localStorage.setItem("ai_note_proxy_url",e)}const Am=`你是一个专业的笔记生成助手。你的任务是将用户提供的网页链接或文字内容转化为精美的双页签图文笔记。

你必须输出纯 JSON 格式，不要输出任何其他内容。

## 输出 JSON 格式

{
  "title": "笔记标题（简短）",
  "subtitle": "副标题/补充说明",
  "tag": "分类标签",
  "source": "原文链接（无则为空字符串）",
  "text_content": "文字页签的完整 HTML 内容",
  "diagram_content": "图解页签的完整 HTML 内容"
}

⚠️ HTML 属性必须使用单引号：JSON 字符串内部使用双引号包裹，HTML 属性用单引号避免转义冲突。
✅ 正确：<div class='tag-pill tag-blue'>内容</div>
❌ 错误：<div class="tag-pill tag-blue">内容</div>

## 内容质量标准（必读）

每个知识点必须写得有血有肉，不是骨架：

- 每个框架/概念/方案展开度：说明设计思想（为什么这么做）、实现细节（具体参数/数据）、优缺点或边界、数据效果（如有）
- 每个知识点的 text_content 中必须 ≥5 个 HTML 块（h标签/ul/table/p/code 等，不算标题本身）
- 少于这个深度需要补充

### 文字页签标题层级规则

h2 — 主要章节（每篇至少 4 个 h2）
├─ h3 — 子主题/要点分类
│  ├─ p/ul/ol — 正文内容
│  ├─ .highlight-box — 重点强调
│  └─ blockquote — 引用

编号规范：
- h2 标题前缀：一、二、三、……（中文大写数字 + 顿号）
- h3 标题前缀：1. 2. 3. ……（阿拉伯数字 + 点号）
- 列表内细分可用 (1)、(2)、(3) 或 ①②③
- 每个 h2 下至少有一个 h3 或直接跟内容
- h2 → h3 → p/ul 一级一级往下，不得跳级

文字页签可用 HTML 组件：
- 正文标题和段落：h2/h3/p/ul/ol
- 单条重点强调：<div class='highlight-box highlight-blue'>...</div>（蓝/橙/绿三种）
- 引用观点：<blockquote>...</blockquote>
- 源码示例：<pre><code>...</code></pre>
- 对比数据：<table>
- 内联标记：<span class='tag-*'>...</span>
- 底部关键词：<div class='footer-tags'><span class='footer-tag tag-blue'>标签</span></div>
- 文字页签不要出现任何卡片样式组件

### 图解页签视觉图表选型

图解页签的内容必须放"一眼扫过去就能获得洞察"的视觉内容。

不同类型的内容使用不同的组件（以下组件在 template.css 中都有样式定义）：

1. 复杂系统架构/多分支流程图（>4节点）→ Mermaid flowchart TB（纵向）
   示例：<div class='mermaid'>flowchart TB\\nA[起点]-->B[终点]</div>
   特殊符号避坑：≥改用>=，→改用->，≤改用<=，≠改用!=，下划线避免使用

2. 简单线性流程（≤4节点，无分支）→ CSS Flow Nodes
   示例：<div class='css-flow'><div class='css-flow-row'><span class='css-node blue'>节点1</span><span class='css-arrow'>→</span><span class='css-node green'>节点2</span></div></div>
   节点类：blue / green / orange

3. 并列概念/方案对比（3-4项）→ CSS 多列卡片网格
   示例（3列）：<div class='diagram-grid-3'>
     <div class='grid-card'><div class='grid-card-label'>标签</div><div class='grid-card-title'>标题</div><div class='grid-card-desc'>描述</div></div>
     ...重复
   </div>
   带图标版本加 grid-card-icon 和 grid-card-emoji

4. 步骤递进（1→2→3顺序关系）→ CSS 纵向步骤卡片
   示例：<div class='step-list'>
     <div class='step-item' style='background:#e8f0fe;'>
       <div class='step-circle' style='background:#667eea;'>1</div>
       <div class='step-content'><div class='step-title'>第一级<span class='step-tag' style='color:#667eea;'>⚡标签</span></div><div class='step-desc'>描述</div></div>
     </div>
   </div>
   颜色递进规范：蓝(#e8f0fe/#667eea)→紫(#f0ebff/#7c3aed)→橙(#fef4e8/#f59e0b)

5. 多维度信息分组/功能要点 → CSS 两列网格+标签组
   示例：<div class='tag-grid-2'>
     <div class='tag-card'><div class='tag-card-title'>分组名</div><div class='tag-group'><span class='tag-pill tag-blue'>标签1</span><span class='tag-pill tag-purple'>标签2</span></div></div>
   </div>
   标签颜色：tag-blue(功能) / tag-purple(技术) / tag-green(性能) / tag-orange(监控)

6. 树形结构/分类/选型决策 → CSS Tree
   示例：<div class='tree-wrap'><ul><li><span class='node-root'>根节点</span><ul><li><span class='node-label'>分支 <span class='arrow'>→</span> 说明</span></li><li><span class='node-leaf'>叶子 <span class='tree-tag tag-green'>推荐</span></span></li></ul></li></ul></div>

7. 数据总结 → 效果条/信息条
   <div class='effect-bar'>📊 效果：xxx</div>
   <div class='info-bar'>说明信息 <span class='bar-sep'>|</span> 更多信息</div>

重要规则：
- diagram_content 中不同类型的模块用 <div class='diagram-section'> 包裹
- 每个 diagram-section 中可以包含：h3 标题、diagram-desc 描述、布局组件、effect-bar/info-bar
- 必须包含至少 3 个不同的 diagram-section 模块
- Mermaid 代码中不要用 ≥→≤≠≈∈ 等特殊符号，下划线避免使用
- 表格统一放在 text_content 中，图解页签用卡片/标签/树形替代
- 确保输出合法 JSON，HTML 中的换行用 \\n 表示`;async function ed(e){var m,f,h;const{url:t,key:n,model:r}=ta(),l=t.endsWith("/")?`${t}v1/chat/completions`:`${t}/v1/chat/completions`,o=await fetch(l,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify({model:r,messages:[{role:"system",content:Am},{role:"user",content:e}],temperature:.7,max_tokens:16384}),signal:AbortSignal.timeout(12e4)});if(!o.ok){const g=await o.text();throw new Error(`API 请求失败 (${o.status}): ${g.substring(0,200)}`)}const a=(h=(f=(m=(await o.json()).choices)==null?void 0:m[0])==null?void 0:f.message)==null?void 0:h.content;if(!a)throw new Error("AI 返回内容为空");const s=a.match(/\{[\s\S]*\}/);if(!s)throw new Error(`AI 返回格式异常: ${a.substring(0,200)}...`);const u=JSON.parse(s[0]);if(!u.title||!u.text_content)throw new Error("AI 返回内容不完整");return u.diagram_content||(u.diagram_content=td),u.source||(u.source=""),u}async function Dm(e){try{const r=`/api/fetch?url=${encodeURIComponent(e)}`,l=await fetch(r,{signal:AbortSignal.timeout(25e3)});if(l.ok){const o=await l.json();if(o.ok&&o.text&&o.text.length>=100)return o.text}}catch{}const t=Zc();try{const r=`${t}/fetch?url=${encodeURIComponent(e)}`,l=await fetch(r,{signal:AbortSignal.timeout(3e4)});if(l.ok){const o=await l.json();if(o.ok&&o.text&&o.text.length>=100)return o.text}}catch{}const n=["https://api.allorigins.win/raw?url=","https://corsproxy.io/?"];for(const r of n)try{const l=await fetch(r+encodeURIComponent(e),{signal:AbortSignal.timeout(15e3)});if(!l.ok)continue;const o=await l.text();if(/captcha|验证|login|403|404/.test(o.substring(0,500)))continue;const i=o.match(/<(?:article|main)[^>]*>([\s\S]*?)<\/(?:article|main)>/i)||o.match(/<[^>]+role="main"[^>]*>([\s\S]*?)<\/[^>]+>/i)||o.match(/<[^>]+class="[^"]*(?:rich_media|content|article|post|entry)[^"]*"[^>]*>([\s\S]*?)<\/[^>]+>/i);let s=(i?i[1]:o).replace(/<(script|style|nav|footer|header|aside|noscript|iframe|svg)[^>]*>[\s\S]*?<\/\1>/gi,"").replace(/<[^>]+>/g," ").replace(/&[a-z]+;|&#\d+;/gi," ").replace(/\s+/g," ").trim();if(!s||s.length<100)continue;return s}catch{continue}return console.warn("无法抓取网页内容（可能需登录或反爬保护）"),null}async function Fm(e){if(!na())return cl(e);try{const t=await Dm(e);if(!t)throw new Error("无法获取网页内容（该网站可能有反爬保护或需要登录）");const n=await ed(`请根据以下网页内容生成笔记：

来源链接：${e}

网页内容：
${t}`);return Zi({title:n.title,subtitle:n.subtitle,tag:n.tag,source:n.source||e,textContent:n.text_content,diagramContent:n.diagram_content})}catch(t){if((t instanceof Error?t.message:String(t)).includes("无法获取网页内容"))throw t;return console.error("AI 生成失败，使用 mock 数据:",t),cl(e)}}async function Um(e){if(!na())return cl(e);try{const t=await ed(`请根据以下内容生成笔记：

${e}`);return Zi({title:t.title,subtitle:t.subtitle,tag:t.tag,source:t.source||"",textContent:t.text_content,diagramContent:t.diagram_content})}catch(t){return console.error("AI 生成失败，使用 mock 数据:",t),cl(e)}}const $m=`
<h2>一、核心概念</h2>
<p>灵知笔记系统是一个智能化的知识管理工具，能够自动将任意内容转换为结构化的双页签笔记。</p>

<div class='highlight-box highlight-blue'>
<strong>✨ 核心价值</strong>：将碎片化信息转化为可回顾、可分享的知识资产，阅读效率提升 3 倍以上。
</div>

<h3>1. 三大核心能力</h3>
<p>灵知笔记系统围绕三个核心能力构建：</p>
<ul>
<li><strong>内容理解</strong>：自动提取 URL 或文本中的核心知识点，识别逻辑关系和层级结构</li>
<li><strong>智能摘要</strong>：生成简洁的要点总结和关键概念，降低信息过载</li>
<li><strong>可视化</strong>：将复杂逻辑转化为直观的图表和流程图，实现"一眼看懂"</li>
</ul>

<h3>2. 工作流程</h3>
<p>笔记生成系统采用四阶段流水线，从原始内容到精美笔记：</p>
<ol>
<li><strong>内容获取</strong> — 从网页、文本、音视频获取原始内容，支持多种输入格式</li>
<li><strong>内容分析</strong> — 提取 3-8 个核心知识点，识别逻辑关系和重要性排序</li>
<li><strong>结构化</strong> — 组织为文字笔记 + 图解笔记两种互补形式</li>
<li><strong>渲染输出</strong> — 生成精美的双页签 HTML 笔记，适配移动端和桌面端</li>
</ol>

<h2>二、双页签设计理念</h2>
<p>双页签设计的核心原则是"分工互补"：文字页签负责深度阐述，图解页签负责视觉总结。</p>

<h3>1. 文字页签：完整阐述</h3>
<p>文字页签的内容适合<strong>逐行阅读</strong>，用于完整理解知识：</p>
<ul>
<li>使用分层标题（h2→h3→p）构建清晰的知识骨架</li>
<li>高亮框标注重点内容，区分核心观点和辅助说明</li>
<li>引用块展示第三方观点和数据，增强可信度</li>
<li>底部标签区提供关键词索引，便于回顾</li>
</ul>

<blockquote>💡 一个好的灵知笔记应该让读者既能深度阅读（文字页签），又能一眼看懂（图解页签）。两者缺一不可。</blockquote>

<h3>2. 图解页签：视觉总结</h3>
<p>图解页签的内容适合<strong>扫读</strong>，用于快速获取洞察：</p>
<ul>
<li>流程图展示完整链路和分支逻辑</li>
<li>卡片网格并列展示概念对比</li>
<li>步骤列表展示递进关系</li>
<li>标签组多维分类，一眼看懂全貌</li>
</ul>

<h2>三、适用场景</h2>
<p>灵知笔记系统覆盖多个知识管理场景：</p>

<h3>1. 技术文档学习</h3>
<p>面对长篇技术文档，灵知笔记自动提取核心架构、关键接口和实现细节，生成结构化摘要。</p>

<h3>2. 产品方案分析</h3>
<p>分析竞品方案或产品设计文档时，灵知笔记自动对比不同方案的优劣势，输出并列对比卡片和决策树。</p>

<h3>3. 知识管理整理</h3>
<p>将碎片化信息统一转化为结构化的知识资产，建立个人知识库。</p>

<div class='footer-tags'>
<span class='footer-tag tag-blue'>灵知笔记</span>
<span class='footer-tag tag-purple'>知识管理</span>
<span class='footer-tag tag-green'>可视化</span>
<span class='footer-tag tag-orange'>双页签</span>
</div>
`,td=`
<div class='diagram-section'>
  <h3>🔄 笔记生成流程</h3>
  <div class='diagram-desc'>从输入到输出的完整处理链路</div>
  <div class='css-flow'>
    <div class='css-flow-row'>
      <span class='css-node blue'>用户输入</span>
      <span class='css-arrow'>→</span>
      <span class='css-node blue'>内容获取</span>
      <span class='css-arrow'>→</span>
      <span class='css-node blue'>知识提取</span>
      <span class='css-arrow'>→</span>
      <span class='css-node blue'>结构化</span>
      <span class='css-arrow'>→</span>
      <span class='css-node green'>渲染输出</span>
    </div>
  </div>
</div>

<div class='diagram-section'>
  <h3>📦 三阶段方案</h3>
  <div class='diagram-desc'>逐步增强的内容处理能力</div>
  <div class='diagram-grid-3'>
    <div class='grid-card'>
      <div class='grid-card-label'>📝 阶段一</div>
      <div class='grid-card-title'>内容获取</div>
      <div class='grid-card-desc'>从 URL 或文本中抓取原始内容，支持多种输入格式</div>
    </div>
    <div class='grid-card'>
      <div class='grid-card-label'>🧠 阶段二</div>
      <div class='grid-card-title'>AI 分析</div>
      <div class='grid-card-desc'>提取核心知识点，识别逻辑关系，标注重要性</div>
    </div>
    <div class='grid-card'>
      <div class='grid-card-label'>🎨 阶段三</div>
      <div class='grid-card-title'>美化输出</div>
      <div class='grid-card-desc'>渲染为双页签笔记，适配多端展示</div>
    </div>
  </div>
  <div class='effect-bar'>📊 效果：阅读效率提升 3 倍，信息保留率提高 60%</div>
</div>

<div class='diagram-section'>
  <h3>⚡ 实施步骤</h3>
  <div class='diagram-desc'>分阶段推进</div>
  <div class='step-list'>
    <div class='step-item' style='background:#e8f0fe;'>
      <div class='step-circle' style='background:#667eea;'>1</div>
      <div class='step-content'>
        <div class='step-title'>第一步 <span class='step-tag' style='color:#667eea;'>⚡ 收集</span></div>
        <div class='step-desc'>收集原始内容，支持网页链接和纯文本输入</div>
      </div>
    </div>
    <div class='step-item' style='background:#f0ebff;'>
      <div class='step-circle' style='background:#7c3aed;'>2</div>
      <div class='step-content'>
        <div class='step-title'>第二步 <span class='step-tag' style='color:#7c3aed;'>🧠 分析</span></div>
        <div class='step-desc'>AI 智能分析内容，提取核心知识点</div>
      </div>
    </div>
    <div class='step-item' style='background:#fef4e8;'>
      <div class='step-circle' style='background:#f59e0b;'>3</div>
      <div class='step-content'>
        <div class='step-title'>第三步 <span class='step-tag' style='color:#f59e0b;'>🎨 生成</span></div>
        <div class='step-desc'>生成精美图文笔记，支持分享和导出</div>
      </div>
    </div>
  </div>
</div>

<div class='diagram-section'>
  <h3>🏷 功能要点</h3>
  <div class='diagram-desc'>多维度能力分组</div>
  <div class='tag-grid-2'>
    <div class='tag-card'>
      <div class='tag-card-title'>📤 内容输入</div>
      <div class='tag-group'>
        <span class='tag-pill tag-blue'>网页链接</span>
        <span class='tag-pill tag-blue'>纯文本</span>
      </div>
    </div>
    <div class='tag-card'>
      <div class='tag-card-title'>🎯 核心能力</div>
      <div class='tag-group'>
        <span class='tag-pill tag-purple'>知识提取</span>
        <span class='tag-pill tag-purple'>图表生成</span>
      </div>
    </div>
    <div class='tag-card'>
      <div class='tag-card-title'>⚡ 输出形式</div>
      <div class='tag-group'>
        <span class='tag-pill tag-green'>文字笔记</span>
        <span class='tag-pill tag-green'>图解笔记</span>
      </div>
    </div>
    <div class='tag-card'>
      <div class='tag-card-title'>📊 数据指标</div>
      <div class='tag-group'>
        <span class='tag-pill tag-orange'>阅读效率 +300%</span>
        <span class='tag-pill tag-orange'>信息保留 +60%</span>
      </div>
    </div>
  </div>
  <div class='info-bar'><strong> 适用场景：</strong>技术文档 <span class='bar-sep'>|</span> 产品分析 <span class='bar-sep'>|</span> 知识整理</div>
</div>
`;async function cl(e){return await new Promise(t=>setTimeout(t,400)),Zi({title:"灵知笔记 - 双页签图文笔记生成器",subtitle:"智能知识管理 · 从内容到笔记只需一秒",tag:"AI · 知识管理",source:e,textContent:$m,diagramContent:td})}function Bm(){const e=jl(),[t,n]=S.useState("url"),[r,l]=S.useState(""),[o,i]=S.useState(""),[a,s]=S.useState(!1),[u,m]=S.useState(""),f=na(),h=S.useCallback(async()=>{if(m(""),t==="url"&&!r.trim()){m("请输入网页链接");return}if(t==="text"&&!o.trim()){m("请输入文字内容");return}s(!0);try{const g=await(t==="url"?Fm(r.trim()):Um(o.trim()));bm(g),e(`/note/${g.id}`)}catch(g){const w=g instanceof Error?g.message:"生成失败，请稍后重试";m(w)}finally{s(!1)}},[t,r,o,e]);return y.jsxs("div",{className:"home-page",children:[y.jsxs("div",{className:"hero-section",children:[y.jsx("div",{className:"hero-mark",children:"—"}),y.jsxs("h1",{className:"hero-title",children:["AI ",y.jsx("span",{children:"笔记"})]}),y.jsx("p",{className:"hero-desc",children:"输入链接或文字，AI 自动生成精美的双页签图文笔记"}),y.jsx("div",{className:"hero-rule"})]}),!f&&y.jsxs("div",{className:"api-notice",children:[y.jsx("span",{children:"API 未配置，使用示例数据演示"}),y.jsx("button",{onClick:()=>e("/settings"),children:"设置"})]}),u&&y.jsx("div",{className:"error-banner",children:u}),y.jsxs("div",{className:"mode-tabs",children:[y.jsx("button",{className:`mode-tab ${t==="url"?"active":""}`,onClick:()=>n("url"),children:"网页链接"}),y.jsx("button",{className:`mode-tab ${t==="text"?"active":""}`,onClick:()=>n("text"),children:"纯文字"})]}),y.jsx("div",{className:"input-section",children:t==="url"?y.jsx("input",{className:"url-input",type:"url",placeholder:"粘贴网页链接...",value:r,onChange:g=>l(g.target.value)}):y.jsx("textarea",{className:"text-input",placeholder:"输入或粘贴文字内容...",value:o,onChange:g=>i(g.target.value),rows:8})}),y.jsx("button",{className:"btn-generate",disabled:a||!r.trim()&&!o.trim(),onClick:h,children:a?f?"分析中…":"生成示例中…":"生成笔记"}),y.jsxs("div",{className:"bottom-nav",children:[y.jsx("button",{onClick:()=>e("/notes"),children:"我的笔记"}),y.jsx("button",{onClick:()=>e("/settings"),children:"设置"})]})]})}function Dt(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}const Hm=`
/* ===== Reset & Base ===== */
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html { font-size:15px; scroll-behavior:smooth; }

body {
  font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'PingFang SC', 'Helvetica Neue', Arial, sans-serif;
  background: #f0f2f5;
  color: #1a2332;
  line-height: 1.7;
  min-height: 100vh;
  padding: 0;
}

/* ===== Container ===== */
.container {
  max-width: 860px;
  margin: 0 auto;
  padding: 20px 16px 90px;
}

/* ===== Fixed Tab Bottom Bar ===== */
.tab-bar-fixed {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 100;
  padding: 0 16px 12px;
  background: linear-gradient(to top, #f0f2f5 70%, transparent);
  pointer-events: none;
  transform: translateY(0);
  transition: transform 0.35s cubic-bezier(.4,0,.2,1);
}
.tab-bar-fixed.tab-hidden {
  transform: translateY(100%);
}
.tab-bar-fixed .tab-nav {
  max-width: 860px;
  margin: 0 auto;
  pointer-events: auto;
  box-shadow: 0 -4px 20px rgba(0,0,0,0.08), 0 2px 12px rgba(0,0,0,0.04);
}

/* ===== Header ===== */
.note-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 16px;
  padding: 20px 24px;
  margin-bottom: 16px;
  color: #fff;
  position: relative;
  overflow: hidden;
}
.note-header::before {
  content: '';
  position: absolute;
  top: -50%;
  right: -20%;
  width: 300px;
  height: 300px;
  background: rgba(255,255,255,0.08);
  border-radius: 50%;
}
.note-header::after {
  content: '';
  position: absolute;
  bottom: -30%;
  left: -10%;
  width: 200px;
  height: 200px;
  background: rgba(255,255,255,0.05);
  border-radius: 50%;
}
.note-tag {
  display: inline-block;
  background: rgba(255,255,255,0.2);
  backdrop-filter: blur(10px);
  padding: 3px 10px;
  border-radius: 16px;
  font-size: 0.7rem;
  font-weight: 600;
  letter-spacing: 0.5px;
  margin-bottom: 8px;
  border: 1px solid rgba(255,255,255,0.15);
}
.note-header h1 {
  font-size: 1.4rem;
  font-weight: 700;
  position: relative;
  z-index: 1;
  line-height: 1.3;
}
.note-header .subtitle {
  font-size: 0.85rem;
  opacity: 0.85;
  margin-top: 4px;
  position: relative;
  z-index: 1;
  font-weight: 400;
}
/* note-author removed — only note-source is used */

/* ===== Source Link ===== */
.note-source {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 6px;
  position: relative;
  z-index: 1;
  flex-wrap: wrap;
}
.source-label {
  font-size: 0.7rem;
  color: rgba(255,255,255,0.5);
  white-space: nowrap;
}
.source-link {
  font-size: 0.75rem;
  color: rgba(255,255,255,0.8);
  text-decoration: none;
  border-bottom: 1px solid rgba(255,255,255,0.25);
  padding-bottom: 1px;
  transition: border-color 0.2s;
  word-break: break-all;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 100%;
}
.source-link:hover {
  border-bottom-color: rgba(255,255,255,0.7);
  color: #fff;
}

/* ===== Tab Navigation ===== */
.tab-nav {
  display: flex;
  gap: 0;
  background: #fff;
  border-radius: 16px;
  overflow: hidden;
  margin-bottom: 20px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.04);
  border: 1px solid #eef0f4;
}
.tab-btn {
  flex: 1;
  padding: 14px 20px;
  border: none;
  background: transparent;
  font-size: 0.95rem;
  font-weight: 600;
  color: #8896ab;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  font-family: inherit;
}
/* ===== FAB Copy Button ===== */
.fab-copy {
  position: fixed;
  right: 20px;
  bottom: 90px;
  z-index: 101;
  width: 48px;
  height: 48px;
  border-radius: 50%;
  border: none;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: #fff;
  font-size: 1.3rem;
  cursor: pointer;
  box-shadow: 0 4px 16px rgba(102,126,234,0.4);
  transition: all 0.3s cubic-bezier(.4,0,.2,1);
  display: flex;
  align-items: center;
  justify-content: center;
}
.fab-copy:hover {
  transform: scale(1.1);
  box-shadow: 0 6px 24px rgba(102,126,234,0.5);
}
.fab-copy:active {
  transform: scale(0.95);
}
.fab-copy.success {
  background: linear-gradient(135deg, #34d399 0%, #059669 100%);
  box-shadow: 0 4px 16px rgba(52,211,153,0.4);
}
.tab-btn::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 0;
  height: 3px;
  background: linear-gradient(90deg, #667eea, #764ba2);
  border-radius: 3px 3px 0 0;
  transition: width 0.3s ease;
}
.tab-btn:hover {
  color: #4a5a72;
  background: #f8f9fb;
}
.tab-btn.active {
  color: #667eea;
}
.tab-btn.active::after {
  width: 60%;
}
.tab-btn .icon { margin-right: 6px; }

/* ===== Tab Content ===== */
.tab-content { display: none; }
.tab-content.active { display: block; animation: fadeIn 0.35s ease; }

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(8px); }
  to { opacity: 1; transform: translateY(0); }
}

/* ===== Text Tab ===== */
.text-tab { }

/* ===== Cards ===== */
.card {
  background: #fff;
  border-radius: 16px;
  padding: 24px 24px;
  margin-bottom: 16px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.04);
  border: 1px solid #eef0f4;
  transition: box-shadow 0.2s;
}

/* ===== Content Styles ===== */
.text-content h2 {
  font-size: 1.3rem;
  font-weight: 700;
  color: #1a2332;
  margin: 24px 0 12px;
  padding-bottom: 8px;
  border-bottom: 2px solid #f0f2f5;
  display: flex;
  align-items: center;
  gap: 8px;
}
.text-content h2:first-child { margin-top: 0; }
.text-content h3 {
  font-size: 1.05rem;
  font-weight: 600;
  color: #2d3e5c;
  margin: 16px 0 8px;
}
.text-content p {
  margin-bottom: 10px;
  color: #3a4a62;
  line-height: 1.8;
}
.text-content ul, .text-content ol {
  margin: 8px 0 12px 20px;
  color: #3a4a62;
}
.text-content li { margin-bottom: 6px; }
.text-content strong { color: #1a2332; }

/* ===== Highlight Tags ===== */
.tag-blue { background:#e8f0fe; color:#1a5fb4; padding:2px 10px; border-radius:8px; font-size:0.8rem; font-weight:600; }
.tag-green { background:#e6f7ed; color:#1a8c4a; padding:2px 10px; border-radius:8px; font-size:0.8rem; font-weight:600; }
.tag-orange { background:#fef4e8; color:#b45a1a; padding:2px 10px; border-radius:8px; font-size:0.8rem; font-weight:600; }
.tag-purple { background:#f0ebff; color:#6b3fa0; padding:2px 10px; border-radius:8px; font-size:0.8rem; font-weight:600; }
.tag-red { background:#fee8e8; color:#b41a1a; padding:2px 10px; border-radius:8px; font-size:0.8rem; font-weight:600; }

/* ===== Highlight Box ===== */
.highlight-box {
  background: #f0f4fe;
  border-left: 4px solid #667eea;
  padding: 14px 18px;
  border-radius: 0 12px 12px 0;
  margin: 12px 0;
}
.highlight-box.warn { background: #fef4e8; border-left-color: #f59e0b; }
.highlight-box.success { background: #e6f7ed; border-left-color: #22c55e; }
.highlight-box.info { background: #eef2ff; border-left-color: #6366f1; }

/* ===== Quote ===== */
blockquote {
  background: #f8f9fb;
  border-left: 3px solid #d0d5dd;
  padding: 10px 16px;
  margin: 12px 0;
  border-radius: 0 8px 8px 0;
  color: #5a6a7e;
  font-style: italic;
}

/* ===== Text Tab Cards REMOVED — 文字页签无卡片，一切归文字 ===== */

/* ===== Code ===== */
code {
  background: #f0f2f5;
  padding: 2px 8px;
  border-radius: 6px;
  font-size: 0.85em;
  font-family: 'JetBrains Mono', 'SF Mono', monospace;
  color: #e74c3c;
}
pre {
  background: #1a2332;
  border-radius: 12px;
  padding: 16px 20px;
  margin: 12px 0;
  overflow-x: auto;
}
pre code {
  background: transparent;
  color: #e8e8e8;
  padding: 0;
  font-size: 0.85rem;
}

/* ===== Table ===== */
.table-wrap {
  overflow-x: auto;
  margin: 12px 0;
}
table {
  width: 100%;
  border-collapse: collapse;
  border-radius: 12px;
  overflow: hidden;
  font-size: 0.9rem;
}
th {
  background: #f0f4fe;
  color: #1a2332;
  font-weight: 600;
  padding: 10px 14px;
  text-align: left;
  border-bottom: 2px solid #dce3f0;
}
td {
  padding: 10px 14px;
  border-bottom: 1px solid #eef0f4;
  color: #3a4a62;
}
tr:last-child td { border-bottom: none; }
tr:hover td { background: #f8f9fb; }

/* ===== Footer Tags ===== */
.footer-tags {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  margin-top: 20px;
  padding-top: 16px;
  border-top: 1px solid #eef0f4;
}

/* ===== DIAGRAM TAB ===== */
.diagram-tab { }

.diagram-section {
  background: #fff;
  border-radius: 16px;
  padding: 24px;
  margin-bottom: 16px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.04);
  border: 1px solid #eef0f4;
}
.diagram-section h3 {
  font-size: 1.1rem;
  font-weight: 700;
  color: #1a2332;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  gap: 8px;
}
.diagram-section .diagram-desc {
  font-size: 0.85rem;
  color: #5a6a7e;
  margin-bottom: 16px;
}
.diagram-section .mermaid {
  text-align: center;
  margin: 12px 0;
}
.diagram-section .mermaid svg {
  max-width: 100%;
}
.mermaid-save-hint {
  text-align: center;
  font-size: 0.75rem;
  color: #a0aec0;
  margin-top: 4px;
}

/* ===== CSS Tree (复用树形结构：选型/分类/层级) ===== */
.tree-wrap {
  font-size: 0.9rem;
  line-height: 1.7;
  padding: 8px 0;
}
.tree-wrap ul {
  list-style: none;
  padding: 0;
  margin: 0;
}
.tree-wrap li {
  position: relative;
  padding: 3px 0 3px 28px;
  margin: 0;
}
.tree-wrap > ul > li {
  padding-left: 0;
}
.tree-wrap > ul > li > .node-root {
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #fff;
  padding: 6px 16px;
  border-radius: 8px;
  font-weight: 700;
  font-size: 1rem;
  display: inline-block;
  margin-bottom: 6px;
}
.tree-wrap ul ul {
  position: relative;
  margin-left: 14px;
  border-left: 2px solid #d0d5e0;
}
.tree-wrap ul ul li::before {
  content: '';
  position: absolute;
  left: -2px;
  top: 12px;
  width: 20px;
  height: 0;
  border-top: 2px solid #d0d5e0;
}
.tree-wrap ul ul li:last-child::after {
  content: '';
  position: absolute;
  left: -2px;
  top: 12px;
  bottom: 0;
  width: 2px;
  background: #f0f2f5;
}
.node-label {
  background: #f0f4fe;
  color: #1a5fb4;
  padding: 2px 12px;
  border-radius: 6px;
  display: inline-block;
  font-weight: 500;
  font-size: 0.88rem;
}
.node-label .arrow {
  color: #a0aec0;
  margin: 0 4px;
  font-weight: 300;
}
.node-label .tree-tag {
  font-size: 0.75rem;
  padding: 1px 8px;
  border-radius: 4px;
  margin-left: 4px;
  font-weight: 600;
}
.node-leaf {
  background: #f0fff4;
  color: #276749;
  padding: 2px 12px;
  border-radius: 6px;
  display: inline-block;
  font-weight: 500;
  font-size: 0.88rem;
}
.node-leaf .tree-tag {
  font-size: 0.75rem;
  padding: 1px 8px;
  border-radius: 4px;
  margin-left: 4px;
  font-weight: 600;
}

/* ===== 模式②③④：多列网格卡片 ===== */
.diagram-grid-3 {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 12px;
  margin-top: 8px;
}
.diagram-grid-4 {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr;
  gap: 10px;
  margin-top: 8px;
}
.diagram-grid-auto {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: 10px;
  margin-top: 8px;
}
.grid-card {
  background: #f8f9fb;
  border-radius: 12px;
  padding: 16px;
  border: 1px solid #eef0f4;
}
.grid-card-icon { text-align: center; border-width: 2px; }
.grid-card-label {
  font-size: 0.7rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #667eea;
  margin-bottom: 4px;
}
.grid-card-emoji { font-size: 1.8rem; margin: 4px 0; }
.grid-card-title { font-weight: 700; font-size: 1rem; color: #1a2332; margin: 6px 0 4px; }
.grid-card-sub { font-size: 0.8rem; color: #4a5a72; margin: 4px 0; }
.grid-card-desc { font-size: 0.85rem; color: #4a5a72; line-height: 1.6; }

/* ===== 模式④：纵向步骤卡片（带序号圆形） ===== */
.step-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 8px;
}
.step-item {
  display: flex;
  align-items: center;
  gap: 12px;
  border-radius: 12px;
  padding: 14px 18px;
  border: 1px solid;
}
.step-circle {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 0.9rem;
  flex-shrink: 0;
}
.step-content { flex: 1; }
.step-title { font-weight: 700; color: #1a2332; font-size: 0.95rem; }
.step-tag { font-size: 0.75rem; font-weight: 600; margin-left: 6px; }
.step-desc { font-size: 0.85rem; color: #4a5a72; margin-top: 2px; }

/* ===== 模式⑥：两列标签卡片 ===== */
.tag-grid-2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  margin-top: 8px;
}
.tag-card {
  background: #f8f9fb;
  border-radius: 12px;
  padding: 14px 16px;
  border: 1px solid #eef0f4;
}
.tag-card-title { font-weight: 700; font-size: 0.95rem; color: #1a2332; margin-bottom: 6px; }
.tag-group { display: flex; gap: 6px; flex-wrap: wrap; }
.tag-pill {
  display: inline-block;
  padding: 3px 10px;
  border-radius: 8px;
  font-size: 0.78rem;
  font-weight: 600;
}

/* ===== 效果/信息条 ===== */
.effect-bar {
  margin-top: 12px;
  padding: 10px 14px;
  background: #e6f7ed;
  border-radius: 10px;
  font-size: 0.85rem;
  color: #1a8c4a;
}
.info-bar {
  margin-top: 12px;
  padding: 10px 14px;
  background: #f8f9fb;
  border-radius: 10px;
  border: 1px solid #eef0f4;
  font-size: 0.85rem;
  color: #4a5a72;
}
.bar-sep { color: #d0d5dd; margin: 0 6px; }

/* ===== Diagram Cards ===== */
.diagram-card {
  border-radius: 12px;
  padding: 16px;
  transition: transform 0.2s, box-shadow 0.2s;
}
.diagram-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0,0,0,0.06);
}

/* ===== CSS Flow Nodes ===== */
.css-flow {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  margin: 16px 0;
}
.css-flow-row {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  flex-wrap: wrap;
}
.css-node {
  padding: 8px 18px;
  border-radius: 30px;
  font-size: 0.85rem;
  font-weight: 600;
  white-space: nowrap;
  box-shadow: 0 2px 6px rgba(0,0,0,0.04);
  transition: transform 0.15s;
}
.css-node:hover { transform: scale(1.03); }
.css-node.blue { background:#e8f0fe; border:2px solid #667eea; color:#1a5fb4; }
.css-node.green { background:#e6f7ed; border:2px solid #22c55e; color:#1a8c4a; }
.css-node.orange { background:#fef4e8; border:2px solid #f59e0b; color:#b45a1a; }
.css-node.purple { background:#f0ebff; border:2px solid #7c3aed; color:#6b3fa0; }
.css-node.pink { background:#fdf2f8; border:2px solid #ec4899; color:#b91c6e; }
.css-arrow { font-size:1.3rem; color:#a0aec0; font-weight:300; }

/* ===== Timeline ===== */
.timeline {
  position: relative;
  padding: 12px 0;
  margin: 12px 0;
}
.timeline::before {
  content: '';
  position: absolute;
  left: 18px;
  top: 0;
  bottom: 0;
  width: 2px;
  background: #e0e4ec;
}
.timeline-item {
  display: flex;
  gap: 16px;
  margin-bottom: 20px;
  position: relative;
}
.timeline-marker {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.8rem;
  font-weight: 700;
  color: #fff;
  flex-shrink: 0;
  z-index: 1;
}
.timeline-content {
  flex: 1;
  background: #f8f9fb;
  border-radius: 12px;
  padding: 14px 18px;
}
.timeline-content .tl-title { font-weight:600; color:#1a2332; margin-bottom:4px; }
.timeline-content .tl-desc { font-size:0.85rem; color:#4a5a72; }

/* ===== My Note Tab ===== */
.mynote-tab .card { padding:0; overflow:hidden; }
.mynote-header {
  display:flex;
  align-items:center;
  justify-content:space-between;
  padding:14px 20px;
  border-bottom:1px solid #eef0f4;
  font-size:0.85rem;
  color:#5a6a7e;
}
.mynote-header span:first-child{font-weight:600;color:#1a2332;font-size:0.95rem}
.mynote-hint{font-size:0.78rem;color:#a0aec0}
.mynote-editor{
  padding:20px 24px;
  min-height:300px;
  line-height:1.8;
  color:#1a2332;
  font-size:0.95rem;
  outline:none;
  transition:background 0.15s;
}
.mynote-editor:focus{background:#fafbfc}
.mynote-editor:empty::before{
  content:'在这里写下你的总结或想法…';
  color:#c0c8d8;
  font-style:italic;
}
.mynote-editor h1,.mynote-editor h2,.mynote-editor h3{margin:12px 0 6px;font-weight:600;color:#1a2332}
.mynote-editor h1{font-size:1.3rem}
.mynote-editor h2{font-size:1.15rem}
.mynote-editor h3{font-size:1.05rem}
.mynote-editor p{margin-bottom:6px}
.mynote-editor ul,.mynote-editor ol{padding-left:20px;margin:4px 0}
.mynote-editor code{
  background:#f0f2f5;
  padding:1px 6px;
  border-radius:4px;
  font-size:0.85em;
  font-family:monospace;
  color:#e74c3c;
}
.mynote-editor blockquote{
  border-left:3px solid #667eea;
  padding:6px 14px;
  margin:8px 0;
  background:#f8f9fb;
  border-radius:0 6px 6px 0;
  color:#4a5a72;
}

/* ===== Responsive ===== */
@media (max-width: 640px) {
  .container { padding: 12px 10px 30px; }
  .note-header { padding: 24px 18px; }
  .note-header h1 { font-size: 1.4rem; }
  .card { padding: 18px 16px; }
  .concept-grid { grid-template-columns: 1fr; }
  .tab-btn { font-size: 0.85rem; padding: 12px 10px; }
  .css-node { font-size: 0.75rem; padding: 6px 12px; white-space: normal; }
  .diagram-section { padding: 18px 16px; }
  /* Grid layouts keep columns but shrink */
  .diagram-grid-3 { gap: 6px; }
  .diagram-grid-3 .grid-card { padding: 10px; }
  .diagram-grid-3 .grid-card-emoji { font-size: 1.3rem; }
  .diagram-grid-3 .grid-card-title { font-size: 0.85rem; }
  .diagram-grid-3 .grid-card-sub { font-size: 0.72rem; }
  .diagram-grid-3 .grid-card-desc { font-size: 0.75rem; }
  .diagram-grid-4 { gap: 5px; }
  .diagram-grid-4 .grid-card { padding: 8px; }
  .diagram-grid-4 .grid-card-emoji { font-size: 1.1rem; }
  .diagram-grid-4 .grid-card-title { font-size: 0.8rem; }
  .diagram-grid-4 .grid-card-sub { font-size: 0.7rem; }
  .diagram-grid-4 .grid-card-desc { font-size: 0.7rem; }
  .diagram-grid-auto { gap: 5px; }
  .diagram-grid-auto .grid-card { padding: 8px; }
  .diagram-grid-auto .grid-card-emoji { font-size: 1.1rem; }
  .diagram-grid-auto .grid-card-title { font-size: 0.8rem; }
  .diagram-grid-auto .grid-card-desc { font-size: 0.7rem; }
  .tag-grid-2 { gap: 6px; }
  /* Mermaid diagrams scroll horizontally if too wide */
  .diagram-section .mermaid { overflow-x: auto; -webkit-overflow-scrolling: touch; }
  .diagram-section .mermaid svg { min-width: 320px; }
  /* Step items stack vertically on very narrow screens */
  .step-item { flex-direction: column; align-items: flex-start; gap: 8px; }
  /* Timeline tighter */
  .timeline-item { gap: 10px; }
  .timeline-marker { width: 30px; height: 30px; font-size: 0.7rem; }
  /* CSS flow wraps nicely */
  .css-flow-row { gap: 6px; }
}
@media (max-width: 380px) {
  .tab-btn { font-size: 0.78rem; padding: 10px 6px; }
  .tab-btn .icon { display: none; }
  .fab-copy { width: 42px; height: 42px; right: 14px; bottom: 80px; font-size: 1.1rem; }
}
`,Vm=`/* --- Warm Paper Theme Override --- */
:root { --bg:#f5f4f0; --surface:#fefdfb; --ink:#1c1917; --accent:#b7612e; --accent-glow:#f0ece8; --border:#e7e0d5; }
html, body { min-height:auto !important; }
body { background:#f5f4f0; }
.container { padding-bottom:calc(env(safe-area-inset-bottom) + 70px); }
.container { background:transparent; }
.note-header { background:linear-gradient(160deg, #2c1810 0%, #4a2c17 60%, #5a3a22 100%); }
.note-header::before { opacity:0.5; }
.note-tag { background:rgba(183,97,46,.25); color:#f0d5b8; }
h1 { color:#fffef9; }
.note-header .subtitle { color:rgba(255,255,255,.7); }
.note-source a, .note-source .source-link { color:#f0d5b8; }
.source-label { color:rgba(255,255,255,.5); }
.tab-bar-fixed { background:rgba(245,245,247,.94); border-top:1px solid #e7e0d5; }
.tab-nav { background:#fafafb; border-color:#e7e0d5; }
.tab-btn { color:#8c8580; }
.tab-btn:hover { color:#5a4030; }
.tab-btn.active { color:#b7612e; }
.tab-btn.active::after { background:linear-gradient(90deg, #b7612e, #8b5e3c); }
.fab-copy { background:linear-gradient(135deg, #b7612e 0%, #8b5e3c 100%); box-shadow:0 4px 16px rgba(183,97,46,.4); }
.fab-copy:hover { box-shadow:0 6px 24px rgba(183,97,46,.5); }
.fab-copy.success { background:linear-gradient(135deg, #5b7f5e 0%, #3d5a3e 100%); box-shadow:0 4px 16px rgba(91,127,94,.4); }
.card { background:#fafafb; border-color:#e7e0d5; }
.text-content h2 { color:#2c1f12; border-bottom-color:#e7e0d5; }
.text-content h3 { color:#3d2e1c; }
.highlight-box { border-left-color:#b7612e; background:#f4f3f4; color:#5a3a22; }
.highlight-box.highlight-blue { border-left-color:#b7612e; background:#f4f3f4; }
.highlight-box.highlight-green { border-left-color:#5b7f5e; background:#eef5ef; color:#3d5a3e; }
.highlight-box.highlight-orange { border-left-color:#d4874a; background:#f5f4f5; color:#5a3a22; }
blockquote { background:#f5f5f6; border-left-color:#d4c9b8; color:#5a4a3a; }
pre, pre code { background:#2c1f12; color:#f2e4d4; }
table th { background:#4a2c17; color:#fffef9; }
.grid-card { background:#f5f5f6; border-color:#e7e0d5; }
.grid-card-label { color:#b7612e; }
.grid-card-title { color:#2c1f12; }
.grid-card-desc { color:#5a4a3a; }
.step-item { border-color:#e7e0d5; }
.step-desc { color:#5a4a3a; }
.css-node.blue { background:#f4f4f5; border-color:#b7612e; color:#8b5e3c; }
.css-node.green { background:#eef5ef; border-color:#5b7f5e; color:#3d5a3e; }
.css-node.orange { background:#f5f4f5; border-color:#d4874a; color:#8b5a2e; }
.css-arrow { color:#b7612e; }
.tag-card { background:#f5f5f6; border-color:#e7e0d5; }
.tag-card-title { color:#2c1f12; }
.tag-pill.tag-blue, .tag-blue { background:#f4f3f4; color:#b7612e; }
.tag-pill.tag-purple, .tag-purple { background:#f3edf7; color:#8b5e3c; }
.tag-pill.tag-green, .tag-green { background:#eef5ef; color:#5b7f5e; }
.tag-pill.tag-orange, .tag-orange { background:#f5f4f5; color:#d4874a; }
.effect-bar { background:#eef5ef; color:#3d5a3e; }
.info-bar { background:#f5f5f6; border-color:#e7e0d5; color:#5a4a3a; }
.bar-sep { color:#d4c9b8; }
.node-root { background:linear-gradient(135deg, #b7612e, #8b5e3c); color:#fff; }
.node-label { background:#f4f4f5; color:#8b5e3c; }
.node-leaf { background:#eef5ef; color:#3d5a3e; }
.tree-wrap ul ul { border-left-color:#d4c9b8; }
.tree-wrap ul ul li::before { border-top-color:#d4c9b8; }
.footer-tags { border-top-color:#e7e0d5; }
.footer-tag.tag-blue { background:#f4f3f4; color:#b7612e; }
.footer-tag.tag-purple { background:#f3edf7; color:#8b5e3c; }
.footer-tag.tag-green { background:#eef5ef; color:#5b7f5e; }
.footer-tag.tag-orange { background:#f5f4f5; color:#d4874a; }
.mermaid { background:#f5f5f6; border-color:#e7e0d5; color:#5a4a3a; }
.mynote-editor { color:#2c1f12; }
a, .note-source a, .note-source a:visited { color:#b7612e; }
`;function nd(e){const t=Dt(e.title),n=Dt(e.subtitle),r=Dt(e.tag),l=e.source?`<span class="source-label">来源</span><a class="source-link" href="${Dt(e.source)}" target="_blank" rel="noopener">${Dt(e.source)}</a>`:"",o=Dt(e.userNotes||"");return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>${t} - AI 笔记</title>
<script src="https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.min.js"><\/script>
<style>
${Hm}
${Vm}
</style>
</head>
<body>
<div class="container">
  <div class="note-header">
    <span class="note-tag">${r}</span>
    <h1>${t}</h1>
    <div class="subtitle">${n}</div>
    ${l?`<div class="note-source">${l}</div>`:""}
  </div>

  <div class="tab-bar-fixed">
    <div class="tab-nav">
      <button class="tab-btn active" data-tab="text" aria-selected="true"><span class="tab-icon">📝</span>文字</button>
      <button class="tab-btn" data-tab="diagram" aria-selected="false"><span class="tab-icon">🎨</span>图解</button>
      <button class="tab-btn" data-tab="mynote" aria-selected="false"><span class="tab-icon">✏️</span>随手记</button>
    </div>
  </div>

  <div class="tab-content text-tab active" id="tab-text">
    <div class="card">
      <div class="text-content">
        ${e.textContent}
      </div>
    </div>
  </div>

  <div class="tab-content diagram-tab" id="tab-diagram">
    ${e.diagramContent}
  </div>

  <div class="tab-content mynote-tab" id="tab-mynote">
    <div class="card">
      <div class="mynote-editor" contenteditable="true" spellcheck="true">${o}</div>
    </div>
  </div>

  <button class="fab-copy" title="智能复制" onclick="smartCopy()">📋</button>
</div>
<script>
var __noteId__ = '${e.id}';

mermaid.initialize({
  startOnLoad: false,
  securityLevel: 'loose',
  theme: 'base',
  themeVariables: {
    primaryColor: '#eef2ff',
    primaryTextColor: '#1a2332',
    primaryBorderColor: '#667eea',
    lineColor: '#a0aec0',
    secondaryColor: '#f8f9fb',
    tertiaryColor: '#ffffff',
    fontSize: '14px'
  },
  flowchart: { useMaxWidth: true, htmlLabels: true, curve: 'basis' }
});

function renderDiagrams() {
  document.querySelectorAll('#tab-diagram .mermaid').forEach((el, idx) => {
    if (el.querySelector('svg')) return;
    const code = el.textContent.trim();
    el.setAttribute('data-mermaid-source', code);
    const id = 'mermaid-' + Date.now() + '-' + idx;
    const retryCount = parseInt(el.dataset.retry || '0');
    mermaid.render(id, code).then(({ svg }) => {
      el.innerHTML = svg;
      // Add save hint below Mermaid SVG
      const hint = document.createElement('div');
      hint.className = 'mermaid-save-hint';
      hint.textContent = '💡 长按图片可保存';
      el.parentNode.insertBefore(hint, el.nextSibling);
    }).catch(err => {
      console.error('Mermaid render error (attempt ' + (retryCount + 1) + '):', err);
      if (retryCount < 1) {
        // 自动重试一次（避免临时性加载失败）
        el.dataset.retry = '1';
        setTimeout(() => renderDiagrams(), 500);
      } else {
        el.innerHTML = '<div style="background:#fef2f2;border:1px solid #fecaca;border-radius:12px;padding:20px;text-align:center;color:#dc2626;font-size:0.9rem;">⚠️ 图表渲染失败</div>';
      }
    });
  });
}

// ===== Scroll-to-hide Tab Bar =====
(function(){
  const bar = document.querySelector('.tab-bar-fixed');
  if(!bar) return;
  let lastY = window.scrollY, ticking = false;
  window.addEventListener('scroll', function(){
    if(ticking) return;
    ticking = true;
    requestAnimationFrame(function(){
      const y = window.scrollY;
      if(y > lastY && y > 60) bar.classList.add('tab-hidden');
      else bar.classList.remove('tab-hidden');
      lastY = y;
      ticking = false;
    });
  }, {passive:true});
})();

// Tab switching
function updateFabIcon(){
  const fab = document.querySelector('.fab-copy');
  if(!fab) return;
  fab.textContent = '📋';
  fab.title = '复制为文字';
}

document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    document.querySelectorAll('.tab-btn').forEach(b => { b.classList.remove('active'); b.setAttribute('aria-selected','false'); });
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    this.classList.add('active');
    this.setAttribute('aria-selected','true');
    const tabId = this.getAttribute('data-tab');
    document.getElementById('tab-' + tabId).classList.add('active');

    if (tabId === 'diagram') {
      setTimeout(renderDiagrams, 150);
    }
    if (tabId === 'mynote') {
      loadMyNote();
    }
    updateFabIcon();
  });
});

// ===== Smart Copy =====
function getActiveTab(){
  const btn = document.querySelector('.tab-btn.active');
  return btn ? btn.getAttribute('data-tab') : 'text';
}

function fabSuccess(){
  const fab = document.querySelector('.fab-copy');
  if(!fab) return;
  fab.classList.add('success');
  fab.textContent = '✅';
  setTimeout(() => { fab.classList.remove('success'); updateFabIcon(); }, 1500);
}

function smartCopy(){
  const tab = getActiveTab();
  if(tab === 'diagram') return copyDiagramText();
  return copyAsMarkdown(tab);
}

function copyAsMarkdown(tab){
  const selector = tab === 'mynote' ? '#tab-mynote .mynote-editor' : '#tab-text .text-content';
  const root = document.querySelector(selector);
  if(!root) return;
  let md = '';
  for(const el of root.children){
    md += htmlToMd(el) + '\\n\\n';
  }
  md = md.trim();
  
  if(!md){
    const plain = root.innerText.trim();
    navigator.clipboard.writeText(plain).then(fabSuccess).catch(() => alert('复制失败'));
    return;
  }
  
  navigator.clipboard.writeText(md).then(fabSuccess).catch(() => {
    const plain = root.innerText.trim();
    navigator.clipboard.writeText(plain).catch(() => alert('复制失败，请手动选中文字复制'));
  });
}

function copyDiagramText(){
  const section = document.querySelector('#tab-diagram');
  if(!section) return;
  // Extract text from all diagram sections
  const parts = [];
  section.querySelectorAll('.diagram-section, .card').forEach(el => {
    const title = el.querySelector('h3');
    const desc = el.querySelector('.diagram-desc');
    if(title) parts.push('## ' + title.textContent.trim());
    if(desc) parts.push(desc.textContent.trim());
    // Extract text from grid cards, step items, tag cards, tree nodes, etc.
    el.querySelectorAll('.grid-card-title, .step-title, .tag-card-title, .node-label, .node-leaf, .tl-title, .tl-desc, .node-root').forEach(n => {
      const t = n.textContent.trim();
      if(t && !parts.includes(t)) parts.push('· ' + t);
    });
    // Mermaid diagram — add source as code block
    el.querySelectorAll('.mermaid').forEach(m => {
      const src = m.getAttribute('data-mermaid-source');
      if(src) parts.push('\`\`\`mermaid\\n' + src + '\\n\`\`\`');
    });
  });
  // If nothing structured found, fallback to innerText
  const text = parts.length > 0 ? parts.join('\\n\\n') : section.innerText.trim();
  if(!text){ alert('图解无可复制内容'); return; }
  navigator.clipboard.writeText(text).then(fabSuccess).catch(() => {
    const plain = section.innerText.trim();
    navigator.clipboard.writeText(plain).catch(() => alert('复制失败，请手动选中文字复制'));
  });
}

function htmlToMd(el){
  const tag = el.tagName.toLowerCase();
  const text = el.textContent.trim();
  if(!text) return '';

  // Headings
  if(tag === 'h2') return '## ' + text;
  if(tag === 'h3') return '### ' + text;
  if(tag === 'h4') return '#### ' + text;

  // Paragraph
  if(tag === 'p') return inlineMd(el);

  // List item — extract text content excluding nested lists
  if(tag === 'li'){
    return Array.from(el.childNodes)
      .filter(n => n.nodeType !== 1 || (n.tagName !== 'UL' && n.tagName !== 'OL'))
      .map(n => {
        if(n.nodeType === 3) return n.textContent.trim();
        if(n.nodeType === 1) return inlineMd(n);
        return '';
      })
      .join('').trim();
  }

  // Unordered list — support nested lists with indentation
  if(tag === 'ul'){
    return Array.from(el.children).map(li => {
      const liText = htmlToMd(li);
      let result = liText ? '- ' + liText : '';
      li.querySelectorAll(':scope > ul, :scope > ol').forEach(nested => {
        const nestedMd = htmlToMd(nested).split('\\n').map(l => '  ' + l).join('\\n');
        result += (result ? '\\n' : '') + nestedMd;
      });
      return result;
    }).join('\\n');
  }

  // Ordered list — support nested lists with indentation
  if(tag === 'ol'){
    return Array.from(el.children).map((li, i) => {
      const liText = htmlToMd(li);
      let result = liText ? (i+1) + '. ' + liText : (i+1) + '.';
      li.querySelectorAll(':scope > ul, :scope > ol').forEach(nested => {
        const nestedMd = htmlToMd(nested).split('\\n').map(l => '  ' + l).join('\\n');
        result += '\\n' + nestedMd;
      });
      return result;
    }).join('\\n');
  }

  // Blockquote
  if(tag === 'blockquote'){
    const inner = inlineMd(el);
    return inner.split('\\n').map(l => '> ' + l).join('\\n');
  }

  // Code block
  if(tag === 'pre'){
    const code = el.querySelector('code');
    return '\`\`\`\\n' + (code ? code.textContent : text) + '\\n\`\`\`';
  }

  // Highlight box — distinguish variants
  if(el.classList && el.classList.contains('highlight-box')){
    let prefix = '> 💡 ';
    if(el.classList.contains('warn')) prefix = '> ⚠️ ';
    if(el.classList.contains('success')) prefix = '> ✅ ';
    if(el.classList.contains('info')) prefix = '> ℹ️ ';
    return prefix + text;
  }

  // Table (direct <table> or wrapped in div)
  const tbl = tag === 'table' ? el : el.querySelector('table');
  if(tbl) return tableToMd(tbl);

  // Tag group / footer
  if(el.classList && el.classList.contains('footer-tags')){
    return Array.from(el.querySelectorAll('span'))
      .map(s => '\`' + s.textContent.trim() + '\`')
      .join(' ');
  }

  // Default: inline
  return inlineMd(el);
}

function inlineMd(el){
  let html = el.innerHTML;
  // Convert <a> to [text](url)
  html = html.replace(/<a\\s[^>]*href="([^"]*)"[^>]*>(.*?)<\\/a>/gi, '[$2]($1)');
  // Convert <strong> to **
  html = html.replace(/<strong>(.*?)<\\/strong>/gi, '**$1**');
  // Convert <em>/<i> to *
  html = html.replace(/<(em|i)>(.*?)<\\/(em|i)>/gi, '*$2*');
  // Convert <code> to \`
  html = html.replace(/<code>(.*?)<\\/code>/gi, '\`$1\`');
  // Remove <span> (keep content)
  html = html.replace(/<\\/?span[^>]*>/gi, '');
  // Convert <br> to newline
  html = html.replace(/<br\\s*\\/?>/gi, '\\n');
  // Strip remaining HTML tags
  const div = document.createElement('div');
  div.innerHTML = html;
  return div.textContent.trim();
}

function tableToMd(table){
  const rows = table.querySelectorAll('tr');
  if(!rows.length) return '';
  let md = '';
  // Header
  const headers = rows[0].querySelectorAll('th,td');
  md += '| ' + Array.from(headers).map(h => h.textContent.trim()).join(' | ') + ' |\\n';
  md += '| ' + Array.from(headers).map(() => '---').join(' | ') + ' |\\n';
  // Body
  for(let i = 1; i < rows.length; i++){
    const cells = rows[i].querySelectorAll('td');
    md += '| ' + Array.from(cells).map(c => c.textContent.trim()).join(' | ') + ' |\\n';
  }
  return md;
}

// ===== My Note (persisted to localStorage) =====
const MN_KEY='ai_note_mynote_' + encodeURIComponent('<!-- NOTE_TITLE -->');

function loadMyNote(){
  const editor=document.getElementById('mynoteEditor');
  try{
    const saved=localStorage.getItem(MN_KEY);
    if(saved) editor.innerHTML=saved;
  }catch(e){}
  // Auto-save on input
  editor._saveTimer=null;
  editor.oninput=function(){
    clearTimeout(this._saveTimer);
    this._saveTimer=setTimeout(()=>{
      try{localStorage.setItem(MN_KEY,this.innerHTML)}catch(e){}
    },300);
  };
}

<\/script>
<script>
(function() {
  function reportHeight() {
    var h = document.documentElement.scrollHeight;
    window.parent.postMessage({ type: '灵知笔记-resize', height: h }, '*');
  }
  if (window.ResizeObserver) {
    new ResizeObserver(reportHeight).observe(document.body);
  }
  reportHeight();
  setTimeout(reportHeight, 300);
  setTimeout(reportHeight, 1000);
  document.querySelectorAll('.tab-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      setTimeout(reportHeight, 200);
      setTimeout(reportHeight, 600);
    });
  });
})();
<\/script>
</body>
</html>`}function Wm(e){const t=nd(e),n=new Blob([t],{type:"text/html;charset=utf-8"}),r=URL.createObjectURL(n),l=document.createElement("a");l.href=r,l.download=`${e.title||"灵知笔记"}.html`,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(r)}function Qm({note:e}){const t=S.useRef(null),[n,r]=S.useState(0),[l,o]=S.useState(!0),i=S.useCallback(a=>{var s,u;((s=a.data)==null?void 0:s.type)==="灵知笔记-resize"&&((u=a.data)!=null&&u.height)&&(r(a.data.height),o(!1))},[]);return S.useEffect(()=>(window.addEventListener("message",i),()=>window.removeEventListener("message",i)),[i]),S.useEffect(()=>{o(!0),r(0);const a=nd(e),s=t.current;if(!s)return;const u=new Blob([a],{type:"text/html"}),m=URL.createObjectURL(u);return s.src=m,()=>{URL.revokeObjectURL(m)}},[e]),y.jsxs("div",{style:{position:"relative",minHeight:l?"400px":"0px"},children:[l&&y.jsx("div",{style:{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",background:"#f5f5f7",zIndex:1},children:y.jsx("span",{style:{fontSize:"0.875rem",color:"var(--ink-muted, #78716c)",opacity:.5},children:"排版中…"})}),y.jsx("iframe",{ref:t,style:{width:"100%",height:n?`${n}px`:"0px",border:"none",overflow:"hidden",opacity:l?0:1,transition:"opacity 0.2s"},title:e.title,sandbox:"allow-scripts allow-same-origin",scrolling:"no"})]})}function Km(){const{id:e}=dm(),t=jl(),[n,r]=S.useState(null),[l,o]=S.useState(!1),i=S.useCallback(()=>{if(!e)return;const m=Jc(e);m&&r(m)},[e]);S.useEffect(()=>{i()},[i]);const a=()=>{n&&Wm(n)},s=()=>o(!0),u=()=>{n&&(qc(n.id),o(!1),t("/notes",{replace:!0}))};return n?y.jsxs("div",{className:"note-page",children:[y.jsxs("div",{className:"top-bar",children:[y.jsx("button",{className:"top-bar-back",onClick:()=>t(-1),children:"← 返回"}),y.jsxs("div",{className:"top-bar-actions",children:[y.jsx("button",{onClick:a,children:"导出"}),y.jsx("button",{className:"danger",onClick:s,children:"删除"})]})]}),y.jsx(Qm,{note:n}),l&&y.jsx("div",{className:"modal-overlay",onClick:()=>o(!1),children:y.jsxs("div",{className:"modal",onClick:m=>m.stopPropagation(),children:[y.jsx("div",{className:"modal-title",children:"删除笔记"}),y.jsx("div",{className:"modal-message",children:"确定要删除这条笔记吗？删除后无法恢复。"}),y.jsxs("div",{className:"modal-actions",children:[y.jsx("button",{className:"btn-cancel",onClick:()=>o(!1),children:"取消"}),y.jsx("button",{className:"btn-confirm",onClick:u,children:"删除"})]})]})})]}):y.jsx("div",{className:"note-page",children:y.jsxs("div",{className:"empty-state",children:[y.jsx("div",{className:"empty-icon",children:"—"}),y.jsx("div",{className:"empty-text",children:"笔记未找到"}),y.jsx("div",{className:"empty-hint",children:"请从笔记列表重新打开"}),y.jsx("button",{className:"btn-primary",onClick:()=>t("/notes"),children:"返回列表"})]})})}function Ym(){const e=jl(),[t,n]=S.useState([]),[r,l]=S.useState(""),o=S.useCallback(()=>{const a=sr();n(a)},[]);S.useEffect(()=>{o()},[o]);const i=t.filter(a=>a.title.includes(r)||a.tag.includes(r));return y.jsxs("div",{className:"notes-page",children:[y.jsxs("div",{className:"top-bar",children:[y.jsx("button",{className:"top-bar-back",onClick:()=>e("/"),children:"← 首页"}),y.jsx("h1",{className:"page-title",children:"我的笔记"}),y.jsx("div",{style:{width:60}})]}),y.jsxs("div",{className:"notes-body",children:[y.jsx("div",{className:"search-bar",children:y.jsx("input",{className:"search-input",placeholder:"搜索笔记...",value:r,onChange:a=>l(a.target.value)})}),i.length===0?y.jsxs("div",{className:"empty-state",children:[y.jsx("div",{className:"empty-icon",children:"—"}),y.jsx("div",{className:"empty-text",children:"还没有笔记"}),y.jsx("div",{className:"empty-hint",children:"去首页创建第一篇 AI 笔记"}),y.jsx("button",{className:"btn-primary",onClick:()=>e("/"),children:"去创建"})]}):y.jsx("div",{className:"note-list",children:i.map(a=>y.jsxs("div",{className:"note-card",onClick:()=>e(`/note/${a.id}`),children:[y.jsxs("div",{className:"card-content",children:[y.jsx("span",{className:"card-tag",children:a.tag}),y.jsx("div",{className:"card-title",children:a.title}),y.jsx("div",{className:"card-date",children:a.createdAt.substring(0,10)})]}),y.jsx("div",{className:"card-arrow",children:"→"})]},a.id))})]})]})}function Xm(){const e=jl(),[t,n]=S.useState(""),[r,l]=S.useState(""),[o,i]=S.useState(""),[a,s]=S.useState(""),[u,m]=S.useState(!1),[f,h]=S.useState(0);S.useEffect(()=>{const v=ta();n(v.url),l(v.key),i(v.model),s(Zc());const E=sr();h(E.length)},[]);const g=()=>{Mm({url:t,key:r,model:o}),Om(a),m(!0),setTimeout(()=>m(!1),2e3)},w=()=>{if(f===0){alert("没有笔记可删除");return}window.confirm("确定要删除所有笔记吗？此操作不可恢复。")&&(Im().forEach(E=>qc(E.id)),h(0))};return y.jsxs("div",{className:"settings-page",children:[y.jsxs("div",{className:"top-bar",children:[y.jsx("button",{className:"top-bar-back",onClick:()=>e("/"),children:"← 返回"}),y.jsx("h1",{className:"page-title",children:"设置"}),y.jsx("div",{style:{width:60}})]}),y.jsxs("div",{className:"settings-body",children:[y.jsxs("div",{className:"settings-section",children:[y.jsx("h2",{children:"API 配置"}),y.jsx("p",{className:"section-desc",children:"兼容 DeepSeek / OpenAI 接口格式，配置后启用真实 AI 生成"}),y.jsx("label",{className:"field-label",children:"接口地址"}),y.jsx("input",{className:"field-input",value:t,onChange:v=>n(v.target.value),placeholder:"https://api.deepseek.com"}),y.jsx("label",{className:"field-label",children:"API Key"}),y.jsx("input",{className:"field-input",type:"password",value:r,onChange:v=>l(v.target.value),placeholder:"sk-..."}),y.jsx("label",{className:"field-label",children:"模型名称"}),y.jsx("input",{className:"field-input",value:o,onChange:v=>i(v.target.value),placeholder:"deepseek-chat"}),y.jsx("label",{className:"field-label",children:"抓取代理地址"}),y.jsx("input",{className:"field-input",value:a,onChange:v=>s(v.target.value),placeholder:"http://127.0.0.1:8765"}),y.jsx("p",{className:"field-hint",children:"部署到 Cloudflare Worker 后替换为 Worker 地址"}),y.jsx("button",{className:"btn-save",onClick:g,children:u?"已保存":"保存配置"})]}),y.jsxs("div",{className:"settings-section",children:[y.jsx("h2",{children:"数据管理"}),y.jsxs("p",{className:"section-desc",children:["当前共 ",f," 条笔记，数据存储在浏览器本地"]}),y.jsx("button",{className:"btn-danger",onClick:w,children:"清除所有笔记"})]})]})]})}function Gm(){return y.jsx(Lm,{children:y.jsxs(Tm,{children:[y.jsx(zn,{path:"/",element:y.jsx(Bm,{})}),y.jsx(zn,{path:"/note/:id",element:y.jsx(Km,{})}),y.jsx(zn,{path:"/notes",element:y.jsx(Ym,{})}),y.jsx(zn,{path:"/settings",element:y.jsx(Xm,{})})]})})}so.createRoot(document.getElementById("root")).render(y.jsx(bs.StrictMode,{children:y.jsx(Gm,{})}));
